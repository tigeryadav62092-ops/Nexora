import { ShieldAlert, ShieldCheck, ShieldQuestion, type LucideIcon } from 'lucide-react'
import { verdictColor, verdictLabel } from '../data/appData'

export function ScanResultCard({
  verdict,
  summary,
  details,
}: {
  verdict: 'safe' | 'suspicious' | 'dangerous'
  summary: string
  details?: string[]
}) {
  const color = verdictColor(verdict)
  const label = verdictLabel(verdict)
  const Icon: LucideIcon =
    verdict === 'safe' ? ShieldCheck : verdict === 'suspicious' ? ShieldQuestion : ShieldAlert

  return (
    <div className="result-card">
      <div className="result-verdict">
        <div style={{ width: 40, height: 40, borderRadius: 12, background: `${color}22`, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
          <Icon size={22} color={color} />
        </div>
        <div>
          <div style={{ fontSize: 18, fontWeight: 700, color }}>{label}</div>
          <div style={{ fontSize: 13, color: 'var(--text-2)' }}>Analysis complete</div>
        </div>
      </div>
      <p style={{ fontSize: 15, lineHeight: 1.6, color: 'var(--text)', marginBottom: details?.length ? 14 : 0 }}>
        {summary}
      </p>
      {details?.length ? (
        <ul style={{ listStyle: 'none', display: 'flex', flexDirection: 'column', gap: 8 }}>
          {details.map((d, i) => (
            <li key={i} style={{ display: 'flex', gap: 8, fontSize: 14, color: 'var(--text-2)', lineHeight: 1.5 }}>
              <span style={{ color: 'var(--blue-light)', marginTop: 2 }}>•</span>
              {d}
            </li>
          ))}
        </ul>
      ) : null}
    </div>
  )
}
