import { ShieldCheck } from 'lucide-react'

export function Logo({ size = 56, animated = false }: { size?: number; animated?: boolean }) {
  return (
    <div
      className="logo-mark"
      style={{
        width: size,
        height: size,
        borderRadius: size * 0.28,
        animation: animated ? 'scaleIn 600ms cubic-bezier(0.4,0,0.2,1) both' : undefined,
      }}
    >
      <ShieldCheck size={size * 0.55} strokeWidth={2.2} />
    </div>
  )
}

export function LogoWordmark({ animated = false }: { animated?: boolean }) {
  return (
    <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
      <Logo size={40} animated={animated} />
      <span
        style={{
          fontSize: 22,
          fontWeight: 800,
          letterSpacing: -0.5,
          animation: animated ? 'fadeIn 600ms 100ms both' : undefined,
        }}
      >
        Nexora
      </span>
    </div>
  )
}

export function LogoFull({ animated = false }: { animated?: boolean }) {
  return (
    <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 16 }}>
      <Logo size={72} animated={animated} />
      <div style={{ textAlign: 'center', animation: animated ? 'fadeInUp 500ms 150ms both' : undefined }}>
        <div style={{ fontSize: 28, fontWeight: 800, letterSpacing: -0.5 }}>Nexora</div>
        <div style={{ fontSize: 14, color: 'var(--text-2)', marginTop: 4 }}>AI-Powered Digital Safety</div>
      </div>
    </div>
  )
}

export { ShieldCheck }
