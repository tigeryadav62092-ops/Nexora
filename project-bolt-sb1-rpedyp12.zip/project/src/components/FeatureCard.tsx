import { useNavigate } from 'react-router-dom'
import { ArrowRight } from 'lucide-react'
import { type FeatureAccent } from '../data/appData'
import { Icon } from './Icon'

const routes: Record<string, string> = {
  link: '/scanner/link',
  news: '/scanner/news',
  image: '/scanner/image',
  video: '/scanner/video',
  camera: '/scanner/camera',
  pdf: '/scanner/pdf',
  apk: '/scanner/apk',
  file: '/scanner/file',
  screenshot: '/scanner/screenshot',
  scam: '/scanner/scam',
  email: '/scanner/email',
  sms: '/scanner/sms',
  ai: '/scanner/ai',
  qr: '/scanner/qr',
  password: '/scanner/password',
  darkweb: '/scanner/darkweb',
  sos: '/scanner/sos',
}

export function FeatureCard({ feature, index }: { feature: FeatureAccent; index: number }) {
  const navigate = useNavigate()

  return (
    <div
      className="feature-card fade-in-up"
      style={{ animationDelay: `${100 + index * 40}ms` }}
      onClick={() => navigate(routes[feature.id])}
    >
      <div style={{ display: 'flex', alignItems: 'flex-start', justifyContent: 'space-between' }}>
        <div
          className="feature-icon"
          style={{ background: `linear-gradient(135deg, ${feature.start}, ${feature.end})` }}
        >
          <Icon name={feature.icon} size={24} />
        </div>
        {feature.badge && <span className="badge-new">{feature.badge}</span>}
      </div>
      <div className="feature-name">{feature.name}</div>
      <div className="feature-desc">{feature.description}</div>
      <div className="feature-open" style={{ color: feature.start }}>
        Open
        <ArrowRight size={16} />
      </div>
    </div>
  )
}

export { features } from '../data/appData'
