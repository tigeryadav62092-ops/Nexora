import {
  Link2, Newspaper, Image, Video, Mail, Bot, QrCode, KeyRound,
  Camera, FileText, Smartphone, MessageSquare, ShieldOff,
  FileScan, ScanLine, AlertTriangle, Siren,
  type LucideIcon,
} from 'lucide-react'

const icons: Record<string, LucideIcon> = {
  link: Link2,
  newspaper: Newspaper,
  image: Image,
  video: Video,
  mail: Mail,
  bot: Bot,
  qr: QrCode,
  key: KeyRound,
  camera: Camera,
  pdf: FileText,
  apk: Smartphone,
  sms: MessageSquare,
  darkweb: ShieldOff,
  file: FileScan,
  screenshot: ScanLine,
  scam: AlertTriangle,
  sos: Siren,
}

export function Icon({ name, size = 24 }: { name: string; size?: number }) {
  const Cmp = icons[name] ?? Link2
  return <Cmp size={size} strokeWidth={2} />
}
