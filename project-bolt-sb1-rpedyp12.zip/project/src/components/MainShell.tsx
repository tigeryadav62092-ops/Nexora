import { useLocation, useNavigate } from 'react-router-dom'
import { Home, History, QrCode, Shield, User } from 'lucide-react'
import { GradientBackground } from './GradientBackground'

const navItems = [
  { path: '/', label: 'Home', icon: Home },
  { path: '/history', label: 'History', icon: History },
  { path: '/scanner', label: 'Scanner', icon: QrCode },
  { path: '/dashboard', label: 'Score', icon: Shield },
  { path: '/profile', label: 'Profile', icon: User },
]

export default function MainShell({ children }: { children: React.ReactNode }) {
  const location = useLocation()
  const navigate = useNavigate()

  return (
    <GradientBackground>
      <div className="page">{children}</div>
      <nav className="nav-bar">
        {navItems.map((item) => {
          const active = location.pathname === item.path
          return (
            <button
              key={item.path}
              className={`nav-item ${active ? 'active' : ''}`}
              onClick={() => navigate(item.path)}
            >
              <item.icon size={22} strokeWidth={active ? 2.4 : 2} />
              {item.label}
            </button>
          )
        })}
      </nav>
    </GradientBackground>
  )
}
