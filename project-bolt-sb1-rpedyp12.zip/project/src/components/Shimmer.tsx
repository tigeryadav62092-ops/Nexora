export function ShimmerBlock({ height = 14, width = '100%', radius = 6 }: { height?: number; width?: string | number; radius?: number }) {
  return (
    <div
      className="shimmer"
      style={{ height, width, borderRadius: radius, marginBottom: 8 }}
    />
  )
}

export function ScanResultSkeleton() {
  return (
    <div className="glass" style={{ padding: 20 }}>
      <div style={{ display: 'flex', gap: 10, marginBottom: 14 }}>
        <ShimmerBlock height={40} width={40} radius={12} />
        <div>
          <ShimmerBlock height={18} width={120} />
          <ShimmerBlock height={13} width={100} />
        </div>
      </div>
      <ShimmerBlock height={14} />
      <ShimmerBlock height={14} width="70%" />
    </div>
  )
}
