import { ArrowLeft } from 'lucide-react'
import { useNavigate } from 'react-router-dom'
import { type FeatureAccent } from '../data/appData'
import { Icon } from './Icon'

export function ScannerHero({ feature }: { feature: FeatureAccent }) {
  const navigate = useNavigate()
  return (
    <div className="fade-in" style={{ marginBottom: 24 }}>
      <button onClick={() => navigate(-1)} style={{ display: 'flex', alignItems: 'center', gap: 6, color: 'var(--text-2)', fontSize: 14, marginBottom: 16 }}>
        <ArrowLeft size={18} /> Back
      </button>
      <div style={{ display: 'flex', alignItems: 'center', gap: 14 }}>
        <div
          style={{
            width: 56, height: 56, borderRadius: 16,
            background: `linear-gradient(135deg, ${feature.start}, ${feature.end})`,
            display: 'flex', alignItems: 'center', justifyContent: 'center',
            color: 'white', boxShadow: `0 4px 20px ${feature.start}44`,
          }}
        >
          <Icon name={feature.icon} size={28} />
        </div>
        <div>
          <h1 style={{ fontSize: 22, fontWeight: 800, letterSpacing: '-0.3px' }}>{feature.name}</h1>
          <p style={{ fontSize: 14, color: 'var(--text-2)', marginTop: 2 }}>{feature.description}</p>
        </div>
      </div>
    </div>
  )
}
