import { useEffect } from 'react'

export function GradientBackground({ children }: { children: React.ReactNode }) {
  useEffect(() => {
    const saved = localStorage.getItem('nexora-theme')
    if (saved === 'light' || saved === 'dark') {
      document.documentElement.setAttribute('data-theme', saved)
    } else {
      document.documentElement.setAttribute('data-theme', 'dark')
    }
  }, [])

  return <div className="app-bg">{children}</div>
}
