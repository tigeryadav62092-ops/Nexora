export const colors = {
  primaryBlue: '#3B82F6',
  primaryBlueLight: '#60A5FA',
  primaryPurple: '#8B5CF6',
  primaryPurpleLight: '#A78BFA',
  accent: '#22D3EE',
  success: '#34D399',
  warning: '#FBBF24',
  error: '#F87171',

  dark: {
    background: '#0A0E1A',
    surface: '#121829',
    surfaceVariant: '#1A2238',
    outline: '#2A3450',
    textPrimary: '#F8FAFC',
    textSecondary: '#94A3B8',
  },
  light: {
    background: '#F5F7FB',
    surface: '#FFFFFF',
    surfaceVariant: '#EEF2F8',
    outline: '#D6DEEA',
    textPrimary: '#0F172A',
    textSecondary: '#64748B',
  },
} as const

export type ThemeColors = typeof colors.dark

export type FeatureCategory = 'scanner' | 'checker' | 'assistant' | 'emergency'

export interface FeatureAccent {
  id: string
  name: string
  description: string
  start: string
  end: string
  icon: string
  category: FeatureCategory
  badge?: string
}

export const features: FeatureAccent[] = [
  { id: 'link', name: 'Website Trust Score', description: 'Live trust score 0–100 with risk breakdown.', start: '#3B82F6', end: '#1D4ED8', icon: 'link', category: 'scanner' },
  { id: 'qr', name: 'QR Safety Scanner', description: 'Scan QR codes and warn before opening links.', start: '#6366F1', end: '#4338CA', icon: 'qr', category: 'scanner' },
  { id: 'image', name: 'Image Scanner', description: 'Spot deepfakes and manipulated media.', start: '#22D3EE', end: '#0891B2', icon: 'image', category: 'scanner' },
  { id: 'video', name: 'Video Scanner', description: 'Analyze videos for synthetic content.', start: '#F472B6', end: '#DB2777', icon: 'video', category: 'scanner' },
  { id: 'camera', name: 'Camera Scanner', description: 'Live camera threat detection scan.', start: '#0EA5E9', end: '#0369A1', icon: 'camera', category: 'scanner' },
  { id: 'file', name: 'File Scanner', description: 'Scan PDF, APK, ZIP, DOCX and images.', start: '#A855F7', end: '#7E22CE', icon: 'file', category: 'scanner', badge: 'NEW' },
  { id: 'screenshot', name: 'Screenshot Analyzer', description: 'AI detects fake payments, job offers & scam chats.', start: '#EC4899', end: '#BE185D', icon: 'screenshot', category: 'scanner', badge: 'NEW' },
  { id: 'scam', name: 'AI Scam Detector', description: 'Detect scam messages, emails and fake offers.', start: '#F43F5E', end: '#9F1239', icon: 'scam', category: 'checker', badge: 'NEW' },
  { id: 'email', name: 'Email Scanner', description: 'Uncover phishing and spoofing attempts.', start: '#34D399', end: '#059669', icon: 'mail', category: 'checker' },
  { id: 'sms', name: 'SMS Scam Detector', description: 'Check text messages for scam and phishing.', start: '#F59E0B', end: '#B45309', icon: 'sms', category: 'checker' },
  { id: 'news', name: 'Fake News Check', description: 'Detect misinformation with AI verification.', start: '#8B5CF6', end: '#6D28D9', icon: 'newspaper', category: 'checker' },
  { id: 'password', name: 'Password Leak Checker', description: 'Check if your password has been leaked.', start: '#10B981', end: '#047857', icon: 'key', category: 'checker' },
  { id: 'darkweb', name: 'Dark Web Breach', description: 'Check if your email was found in a breach.', start: '#EF4444', end: '#991B1B', icon: 'darkweb', category: 'checker' },
  { id: 'ai', name: 'AI Cyber Assistant', description: 'Ask anything about your digital safety.', start: '#FBBF24', end: '#D97706', icon: 'bot', category: 'assistant' },
  { id: 'sos', name: 'Emergency SOS', description: 'One-tap cyber help guide and contacts.', start: '#DC2626', end: '#991B1B', icon: 'sos', category: 'emergency', badge: 'NEW' },
]

export interface ScanRecord {
  id: string
  type: string
  input: string
  verdict: 'safe' | 'suspicious' | 'dangerous'
  summary: string
  date: string
  confidence?: number
  details?: string[]
}

export const mockHistory: ScanRecord[] = [
  { id: '1', type: 'link', input: 'https://secure-paypal-login.com', verdict: 'dangerous', summary: 'Phishing domain impersonating PayPal. Registered 3 days ago.', date: '2h ago', confidence: 94 },
  { id: '2', type: 'news', input: 'Breaking: New study claims coffee cures cancer', verdict: 'suspicious', summary: 'Source unreliable. No peer-reviewed evidence found.', date: '5h ago', confidence: 71 },
  { id: '3', type: 'password', input: 'Tr0ub4dor&3', verdict: 'suspicious', summary: 'Moderate strength. Vulnerable to dictionary attacks.', date: '1d ago', confidence: 65 },
  { id: '4', type: 'link', input: 'https://github.com', verdict: 'safe', summary: 'Legitimate domain. No threats detected.', date: '2d ago', confidence: 98 },
  { id: '5', type: 'email', input: 'support@amaz0n.com', verdict: 'dangerous', summary: 'Spoofed sender domain. Uses zero instead of letter O.', date: '3d ago', confidence: 89 },
]

export const verdictColor = (v: string) =>
  v === 'safe' ? colors.success : v === 'suspicious' ? colors.warning : colors.error

export const verdictLabel = (v: string) =>
  v === 'safe' ? 'Safe' : v === 'suspicious' ? 'Suspicious' : 'Dangerous'

export const scanTypeLabels: Record<string, string> = {
  link: 'Link Check',
  qr: 'QR Scan',
  image: 'Image Scan',
  video: 'Video Scan',
  camera: 'Camera Scan',
  pdf: 'PDF Scan',
  apk: 'APK Scan',
  file: 'File Scan',
  screenshot: 'Screenshot',
  scam: 'Scam Check',
  email: 'Email Scan',
  sms: 'SMS Scan',
  news: 'Fake News',
  password: 'Password Check',
  darkweb: 'Dark Web Breach',
  ai: 'AI Assistant',
  sos: 'Emergency SOS',
}
