import { lazy, Suspense } from 'react'
import { Routes, Route, useLocation } from 'react-router-dom'
import MainShell from './components/MainShell'
import HomePage from './pages/HomePage'
import HistoryPage from './pages/HistoryPage'
import ScannerHubPage from './pages/ScannerHubPage'
import ProfilePage from './pages/ProfilePage'
import SettingsPage from './pages/SettingsPage'
import NotificationsPage from './pages/NotificationsPage'
import SecurityDashboardPage from './pages/SecurityDashboardPage'
import LoginPage from './pages/LoginPage'
import RegisterPage from './pages/RegisterPage'

const LinkCheckerPage = lazy(() => import('./pages/scanners/LinkCheckerPage'))
const FakeNewsPage = lazy(() => import('./pages/scanners/FakeNewsPage'))
const ImageScannerPage = lazy(() => import('./pages/scanners/ImageScannerPage'))
const VideoScannerPage = lazy(() => import('./pages/scanners/VideoScannerPage'))
const EmailScannerPage = lazy(() => import('./pages/scanners/EmailScannerPage'))
const AIAssistantPage = lazy(() => import('./pages/scanners/AIAssistantPage'))
const QRScannerPage = lazy(() => import('./pages/scanners/QRScannerPage'))
const PasswordCheckerPage = lazy(() => import('./pages/scanners/PasswordCheckerPage'))
const CameraScannerPage = lazy(() => import('./pages/scanners/CameraScannerPage'))
const PDFScannerPage = lazy(() => import('./pages/scanners/PDFScannerPage'))
const APKScannerPage = lazy(() => import('./pages/scanners/APKScannerPage'))
const FileScannerPage = lazy(() => import('./pages/scanners/FileScannerPage'))
const SMSScannerPage = lazy(() => import('./pages/scanners/SMSScannerPage'))
const DarkWebPage = lazy(() => import('./pages/scanners/DarkWebPage'))
const ScamDetectorPage = lazy(() => import('./pages/scanners/ScamDetectorPage'))
const ScreenshotAnalyzerPage = lazy(() => import('./pages/scanners/ScreenshotAnalyzerPage'))
const EmergencySOSPage = lazy(() => import('./pages/scanners/EmergencySOSPage'))

function ScannerFallback() {
  return (
    <div style={{ display: 'flex', justifyContent: 'center', alignItems: 'center', paddingTop: 120 }}>
      <div style={{ width: 32, height: 32, borderRadius: '50%', border: '3px solid var(--outline)', borderTopColor: 'var(--blue)', animation: 'spin 0.8s linear infinite' }} />
    </div>
  )
}

export default function App() {
  const location = useLocation()
  const isAuth = location.pathname.startsWith('/auth')

  if (isAuth) {
    return (
      <Routes>
        <Route path="/auth/login" element={<LoginPage />} />
        <Route path="/auth/register" element={<RegisterPage />} />
      </Routes>
    )
  }

  return (
    <MainShell>
      <Suspense fallback={<ScannerFallback />}>
        <Routes>
          <Route path="/" element={<HomePage />} />
          <Route path="/history" element={<HistoryPage />} />
          <Route path="/scanner" element={<ScannerHubPage />} />
          <Route path="/dashboard" element={<SecurityDashboardPage />} />
          <Route path="/profile" element={<ProfilePage />} />
          <Route path="/settings" element={<SettingsPage />} />
          <Route path="/notifications" element={<NotificationsPage />} />
          <Route path="/scanner/link" element={<LinkCheckerPage />} />
          <Route path="/scanner/news" element={<FakeNewsPage />} />
          <Route path="/scanner/image" element={<ImageScannerPage />} />
          <Route path="/scanner/video" element={<VideoScannerPage />} />
          <Route path="/scanner/camera" element={<CameraScannerPage />} />
          <Route path="/scanner/pdf" element={<PDFScannerPage />} />
          <Route path="/scanner/apk" element={<APKScannerPage />} />
          <Route path="/scanner/file" element={<FileScannerPage />} />
          <Route path="/scanner/screenshot" element={<ScreenshotAnalyzerPage />} />
          <Route path="/scanner/scam" element={<ScamDetectorPage />} />
          <Route path="/scanner/email" element={<EmailScannerPage />} />
          <Route path="/scanner/sms" element={<SMSScannerPage />} />
          <Route path="/scanner/ai" element={<AIAssistantPage />} />
          <Route path="/scanner/qr" element={<QRScannerPage />} />
          <Route path="/scanner/password" element={<PasswordCheckerPage />} />
          <Route path="/scanner/darkweb" element={<DarkWebPage />} />
          <Route path="/scanner/sos" element={<EmergencySOSPage />} />
        </Routes>
      </Suspense>
    </MainShell>
  )
}
