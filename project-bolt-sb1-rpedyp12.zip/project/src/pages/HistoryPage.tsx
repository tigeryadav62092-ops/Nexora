import { useState, useEffect } from 'react'
import { ShieldAlert, ShieldCheck, ShieldQuestion, ChevronRight, X, Clock } from 'lucide-react'
import { verdictColor, verdictLabel, scanTypeLabels } from '../data/appData'
import { fetchScans, type ScanRow } from '../lib/scanApi'

const verdictIcon = (v: string) =>
  v === 'safe' ? ShieldCheck : v === 'suspicious' ? ShieldQuestion : ShieldAlert

function timeAgo(iso: string): string {
  const diff = Date.now() - new Date(iso).getTime()
  const mins = Math.floor(diff / 60000)
  if (mins < 1) return 'just now'
  if (mins < 60) return `${mins}m ago`
  const hrs = Math.floor(mins / 60)
  if (hrs < 24) return `${hrs}h ago`
  const days = Math.floor(hrs / 24)
  if (days < 30) return `${days}d ago`
  return new Date(iso).toLocaleDateString()
}

export default function HistoryPage() {
  const [filter, setFilter] = useState<string>('all')
  const [scans, setScans] = useState<ScanRow[]>([])
  const [loading, setLoading] = useState(true)
  const [selected, setSelected] = useState<ScanRow | null>(null)

  useEffect(() => {
    (async () => {
      const data = await fetchScans()
      setScans(data)
      setLoading(false)
    })()
  }, [])

  const filtered = filter === 'all' ? scans : scans.filter((s) => s.verdict === filter)

  return (
    <>
      <h1 className="page-title">History</h1>
      <p className="page-subtitle">Your recent scans and results.</p>

      <div style={{ display: 'flex', gap: 8, marginBottom: 16, overflowX: 'auto' }} className="fade-in">
        {['all', 'safe', 'suspicious', 'dangerous'].map((f) => (
          <button
            key={f}
            onClick={() => setFilter(f)}
            className="badge"
            style={{
              background: filter === f ? 'rgba(59,130,246,0.15)' : 'var(--surface)',
              border: `1px solid ${filter === f ? 'var(--blue)' : 'var(--outline)'}`,
              color: filter === f ? 'var(--blue-light)' : 'var(--text-2)',
              textTransform: 'capitalize',
              whiteSpace: 'nowrap',
            }}
          >
            {f === 'all' ? 'All' : verdictLabel(f)}
          </button>
        ))}
      </div>

      {loading && (
        <div className="empty-state">
          <Clock size={32} color="var(--text-2)" style={{ marginBottom: 12 }} />
          <div>Loading scan history…</div>
        </div>
      )}

      {!loading && filtered.length === 0 && (
        <div className="empty-state">
          <ShieldCheck size={32} color="var(--text-2)" style={{ marginBottom: 12 }} />
          <div>No scans yet. Run a scan to see it here.</div>
        </div>
      )}

      {filtered.map((scan, i) => {
        const VIcon = verdictIcon(scan.verdict)
        const color = verdictColor(scan.verdict)
        return (
          <div
            key={scan.id}
            className="glass fade-in-up"
            style={{ padding: 16, marginBottom: 10, display: 'flex', gap: 12, animationDelay: `${i * 40}ms`, cursor: 'pointer' }}
            onClick={() => setSelected(scan)}
          >
            <div style={{ width: 40, height: 40, borderRadius: 12, background: `${color}22`, display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0 }}>
              <VIcon size={20} color={color} />
            </div>
            <div style={{ flex: 1, minWidth: 0 }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 4 }}>
                <span className="badge" style={{ background: `${color}22`, color }}>{verdictLabel(scan.verdict)}</span>
                <span style={{ fontSize: 12, color: 'var(--text-2)' }}>{timeAgo(scan.created_at)}</span>
              </div>
              <div style={{ fontSize: 14, fontWeight: 600, whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis', marginBottom: 2 }}>{scan.input}</div>
              <div style={{ fontSize: 13, color: 'var(--text-2)', lineHeight: 1.4 }}>{scan.summary || 'No summary available'}</div>
              <div style={{ display: 'flex', alignItems: 'center', gap: 4, marginTop: 6, fontSize: 12, color: 'var(--text-2)' }}>
                {scanTypeLabels[scan.scan_type] || scan.scan_type}
                <ChevronRight size={14} />
              </div>
            </div>
          </div>
        )
      })}

      {/* Detail modal */}
      {selected && (
        <div
          style={{ position: 'fixed', inset: 0, background: 'rgba(0,0,0,0.6)', backdropFilter: 'blur(8px)', zIndex: 200, display: 'flex', alignItems: 'flex-end', justifyContent: 'center' }}
          onClick={() => setSelected(null)}
        >
          <div
            className="glass slide-in-right"
            style={{ width: '100%', maxWidth: 480, borderRadius: '24px 24px 0 0', padding: 24, maxHeight: '80vh', overflowY: 'auto', animation: 'fadeInUp 400ms cubic-bezier(0.4,0,0.2,1) both' }}
            onClick={(e) => e.stopPropagation()}
          >
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 16 }}>
              <h2 style={{ fontSize: 20, fontWeight: 800 }}>Scan Details</h2>
              <button onClick={() => setSelected(null)} style={{ width: 32, height: 32, borderRadius: 10, background: 'var(--surface-2)', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                <X size={18} color="var(--text-2)" />
              </button>
            </div>

            {(() => {
              const VIcon = verdictIcon(selected.verdict)
              const color = verdictColor(selected.verdict)
              return (
                <>
                  <div style={{ display: 'flex', alignItems: 'center', gap: 12, marginBottom: 20 }}>
                    <div style={{ width: 48, height: 48, borderRadius: 14, background: `${color}22`, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                      <VIcon size={24} color={color} />
                    </div>
                    <div>
                      <div style={{ fontSize: 18, fontWeight: 700, color }}>{verdictLabel(selected.verdict)}</div>
                      <div style={{ fontSize: 13, color: 'var(--text-2)' }}>{scanTypeLabels[selected.scan_type] || selected.scan_type}</div>
                    </div>
                  </div>

                  <div className="settings-group">
                    <div className="history-detail-row">
                      <span style={{ color: 'var(--text-2)' }}>Input</span>
                      <span style={{ fontWeight: 600, maxWidth: 200, whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>{selected.input}</span>
                    </div>
                    <div className="history-detail-row">
                      <span style={{ color: 'var(--text-2)' }}>Confidence</span>
                      <span style={{ fontWeight: 600 }}>{selected.confidence}%</span>
                    </div>
                    <div className="history-detail-row">
                      <span style={{ color: 'var(--text-2)' }}>Date</span>
                      <span style={{ fontWeight: 600 }}>{new Date(selected.created_at).toLocaleString()}</span>
                    </div>
                  </div>

                  {selected.summary && (
                    <div style={{ marginTop: 16, marginBottom: 16 }}>
                      <div style={{ fontSize: 13, fontWeight: 600, color: 'var(--text-2)', marginBottom: 8 }}>Summary</div>
                      <div style={{ fontSize: 15, lineHeight: 1.6, color: 'var(--text)' }}>{selected.summary}</div>
                    </div>
                  )}

                  {selected.details && selected.details.length > 0 && (
                    <div>
                      <div style={{ fontSize: 13, fontWeight: 600, color: 'var(--text-2)', marginBottom: 8 }}>Details</div>
                      {selected.details.map((d: string, i: number) => (
                        <div key={i} style={{ display: 'flex', gap: 8, fontSize: 14, color: 'var(--text)', marginBottom: 8, lineHeight: 1.5 }}>
                          <span style={{ color: 'var(--blue-light)', marginTop: 2 }}>•</span>
                          {d}
                        </div>
                      ))}
                    </div>
                  )}
                </>
              )
            })()}
          </div>
        </div>
      )}
    </>
  )
}
