import { useNavigate } from 'react-router-dom'
import { ChevronRight, ShieldCheck, Siren } from 'lucide-react'
import { features } from '../data/appData'
import { Icon } from '../components/Icon'

const routes: Record<string, string> = {
  link: '/scanner/link', news: '/scanner/news', image: '/scanner/image',
  video: '/scanner/video', camera: '/scanner/camera', pdf: '/scanner/pdf',
  apk: '/scanner/apk', file: '/scanner/file', screenshot: '/scanner/screenshot',
  scam: '/scanner/scam', email: '/scanner/email', sms: '/scanner/sms',
  ai: '/scanner/ai', qr: '/scanner/qr', password: '/scanner/password',
  darkweb: '/scanner/darkweb', sos: '/scanner/sos',
}

export default function ScannerHubPage() {
  const navigate = useNavigate()

  const scanners = features.filter(f => f.category === 'scanner')
  const checkers = features.filter(f => f.category === 'checker')
  const assistants = features.filter(f => f.category === 'assistant')
  const emergency = features.filter(f => f.category === 'emergency')

  const renderTile = (f: typeof features[0], i: number) => (
    <div
      key={f.id}
      className="scan-tile fade-in-up"
      style={{ animationDelay: `${i * 40}ms` }}
      onClick={() => navigate(routes[f.id])}
    >
      <div className="scan-tile-icon" style={{ background: `linear-gradient(135deg, ${f.start}, ${f.end})` }}>
        <Icon name={f.icon} size={22} />
      </div>
      <div style={{ flex: 1, minWidth: 0 }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
          <span style={{ fontWeight: 600, fontSize: 16 }}>{f.name}</span>
          {f.badge && <span className="badge-new">{f.badge}</span>}
        </div>
        <div style={{ fontSize: 13, color: 'var(--text-2)', whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>{f.description}</div>
      </div>
      <ChevronRight size={20} color="var(--text-2)" />
    </div>
  )

  return (
    <>
      <h1 className="page-title">Scanner</h1>
      <p className="page-subtitle">Pick a tool to start a scan.</p>

      {/* Security Dashboard quick access */}
      <div
        className="glass fade-in-up pulse-glow"
        style={{ padding: 16, marginBottom: 20, display: 'flex', alignItems: 'center', gap: 14, cursor: 'pointer', animationDelay: '0ms' }}
        onClick={() => navigate('/dashboard')}
      >
        <div style={{ width: 48, height: 48, borderRadius: 14, background: 'linear-gradient(135deg, var(--blue), var(--purple))', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
          <ShieldCheck size={24} color="white" />
        </div>
        <div style={{ flex: 1 }}>
          <div style={{ fontWeight: 700, fontSize: 16 }}>Security Dashboard</div>
          <div style={{ fontSize: 13, color: 'var(--text-2)' }}>Overall score, weekly report & threat stats</div>
        </div>
        <ChevronRight size={20} color="var(--text-2)" />
      </div>

      {/* Emergency SOS quick access */}
      <div
        className="glass fade-in-up"
        style={{ padding: 16, marginBottom: 20, display: 'flex', alignItems: 'center', gap: 14, cursor: 'pointer', animationDelay: '50ms', border: '1px solid rgba(220,38,38,0.3)' }}
        onClick={() => navigate('/scanner/sos')}
      >
        <div style={{ width: 48, height: 48, borderRadius: 14, background: 'linear-gradient(135deg, #DC2626, #991B1B)', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
          <Siren size={24} color="white" />
        </div>
        <div style={{ flex: 1 }}>
          <div style={{ fontWeight: 700, fontSize: 16 }}>Emergency SOS</div>
          <div style={{ fontSize: 13, color: 'var(--text-2)' }}>One-tap cyber help guide & contacts</div>
        </div>
        <ChevronRight size={20} color="var(--text-2)" />
      </div>

      <div className="scan-category-label">Scanners</div>
      {scanners.map((f, i) => renderTile(f, i))}

      <div className="scan-category-label">Checkers</div>
      {checkers.map((f, i) => renderTile(f, i + scanners.length))}

      <div className="scan-category-label">Assistant</div>
      {assistants.map((f, i) => renderTile(f, i + scanners.length + checkers.length))}

      {emergency.length > 0 && (
        <>
          <div className="scan-category-label">Emergency</div>
          {emergency.map((f, i) => renderTile(f, i + scanners.length + checkers.length + assistants.length))}
        </>
      )}
    </>
  )
}
