import { useNavigate } from 'react-router-dom'
import { ChevronRight, LogOut, Shield, Bell, Globe, HelpCircle, Settings } from 'lucide-react'
import { LogoFull } from '../components/Logo'

export default function ProfilePage() {
  const navigate = useNavigate()
  const stats = [
    { label: 'Scans', value: '147' },
    { label: 'Threats', value: '23' },
    { label: 'Streak', value: '12d' },
  ]
  const rows = [
    { icon: Shield, label: 'Security Dashboard', route: '/dashboard' },
    { icon: Bell, label: 'Notifications', route: '/notifications' },
    { icon: Globe, label: 'Language', route: '/settings' },
    { icon: HelpCircle, label: 'Help & Support', route: '/settings' },
    { icon: Settings, label: 'Settings', route: '/settings' },
  ]

  return (
    <>
      <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', paddingTop: 20, paddingBottom: 24 }} className="fade-in">
        <LogoFull animated />
      </div>

      <div style={{ display: 'flex', gap: 10, marginBottom: 28 }}>
        {stats.map((s, i) => (
          <div key={s.label} className="profile-stat" style={{ animationDelay: `${200 + i * 80}ms` }}>
            <div style={{ fontSize: 22, fontWeight: 800 }}>{s.value}</div>
            <div style={{ fontSize: 12, color: 'var(--text-2)', marginTop: 2 }}>{s.label}</div>
          </div>
        ))}
      </div>

      <div className="settings-group fade-in-up" style={{ animationDelay: '400ms' }}>
        {rows.map((r) => (
          <div key={r.label} className="settings-row" onClick={() => navigate(r.route)} style={{ cursor: 'pointer' }}>
            <div className="settings-row-icon"><r.icon size={18} /></div>
            <span style={{ flex: 1, fontSize: 15, fontWeight: 500 }}>{r.label}</span>
            <ChevronRight size={18} color="var(--text-2)" />
          </div>
        ))}
      </div>

      <button className="btn-outlined fade-in-up" style={{ animationDelay: '500ms', color: 'var(--error)', borderColor: 'rgba(248,113,113,0.3)' }} onClick={() => navigate('/auth/login')}>
        <LogOut size={18} /> Sign Out
      </button>
    </>
  )
}
