import { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { Mail, Lock, Eye, EyeOff } from 'lucide-react'
import { LogoFull } from '../components/Logo'
import { GradientBackground } from '../components/GradientBackground'

export default function LoginPage() {
  const navigate = useNavigate()
  const [showPw, setShowPw] = useState(false)

  return (
    <GradientBackground>
      <div className="page" style={{ display: 'flex', flexDirection: 'column', justifyContent: 'center', minHeight: '100vh', paddingBottom: 40 }}>
        <div style={{ marginBottom: 40 }} className="fade-in">
          <LogoFull animated />
        </div>

        <div className="fade-in-up" style={{ animationDelay: '200ms' }}>
          <h1 style={{ fontSize: 24, fontWeight: 700, marginBottom: 4 }}>Welcome back</h1>
          <p style={{ color: 'var(--text-2)', fontSize: 15, marginBottom: 28 }}>Sign in to continue protecting your digital life.</p>

          <div style={{ position: 'relative', marginBottom: 14 }}>
            <Mail size={20} color="var(--text-2)" style={{ position: 'absolute', left: 16, top: 18 }} />
            <input className="input-field" style={{ paddingLeft: 46 }} placeholder="Email address" type="email" />
          </div>

          <div style={{ position: 'relative', marginBottom: 14 }}>
            <Lock size={20} color="var(--text-2)" style={{ position: 'absolute', left: 16, top: 18 }} />
            <input className="input-field" style={{ paddingLeft: 46, paddingRight: 46 }} placeholder="Password" type={showPw ? 'text' : 'password'} />
            <button onClick={() => setShowPw(!showPw)} style={{ position: 'absolute', right: 14, top: 16 }}>
              {showPw ? <EyeOff size={20} color="var(--text-2)" /> : <Eye size={20} color="var(--text-2)" />}
            </button>
          </div>

          <div style={{ textAlign: 'right', marginBottom: 24 }}>
            <span style={{ fontSize: 14, color: 'var(--blue-light)', cursor: 'pointer' }}>Forgot password?</span>
          </div>

          <button className="btn-primary" onClick={() => navigate('/')}>Sign In</button>

          <div style={{ textAlign: 'center', marginTop: 24, fontSize: 14, color: 'var(--text-2)' }}>
            Don't have an account?{' '}
            <span style={{ color: 'var(--blue-light)', cursor: 'pointer', fontWeight: 600 }} onClick={() => navigate('/auth/register')}>
              Sign up
            </span>
          </div>
        </div>
      </div>
    </GradientBackground>
  )
}
