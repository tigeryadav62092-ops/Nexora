import { ShieldAlert, ShieldCheck, Info, Bell } from 'lucide-react'

const notifications = [
  { id: 1, type: 'danger', title: 'Phishing link detected', body: 'A link you scanned was flagged as dangerous.', time: '2h ago', unread: true, icon: ShieldAlert },
  { id: 2, type: 'safe', title: 'Scan complete', body: 'Your image scan completed — no threats found.', time: '5h ago', unread: true, icon: ShieldCheck },
  { id: 3, type: 'info', title: 'New feature available', body: 'Video Scanner is now available. Try it out!', time: '1d ago', unread: false, icon: Info },
  { id: 4, type: 'info', title: 'Weekly report', body: 'You scanned 12 items this week. Tap to view details.', time: '2d ago', unread: false, icon: Bell },
]

const typeColor = (t: string) => t === 'danger' ? 'var(--error)' : t === 'safe' ? 'var(--success)' : 'var(--blue-light)'

export default function NotificationsPage() {
  return (
    <>
      <h1 className="page-title">Notifications</h1>
      <p className="page-subtitle">Stay updated on your scans and security.</p>

      {notifications.map((n, i) => (
        <div
          key={n.id}
          className={`notif-item fade-in-up ${n.unread ? 'unread' : ''}`}
          style={{ animationDelay: `${i * 50}ms` }}
        >
          <div style={{ width: 40, height: 40, borderRadius: 12, background: `${typeColor(n.type)}22`, display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0 }}>
            <n.icon size={20} color={typeColor(n.type)} />
          </div>
          <div style={{ flex: 1, minWidth: 0 }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 2 }}>
              <span style={{ fontSize: 15, fontWeight: 600 }}>{n.title}</span>
              <span style={{ fontSize: 12, color: 'var(--text-2)' }}>{n.time}</span>
            </div>
            <div style={{ fontSize: 13, color: 'var(--text-2)', lineHeight: 1.4 }}>{n.body}</div>
          </div>
        </div>
      ))}
    </>
  )
}
