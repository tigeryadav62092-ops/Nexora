import { useState } from 'react'
import { Moon, Sun, Globe, Bell, Shield, Info, ChevronRight } from 'lucide-react'
import { useTheme } from '../lib/useTheme'

function Toggle({ on, onClick }: { on: boolean; onClick: () => void }) {
  return (
    <button
      onClick={onClick}
      style={{
        width: 44, height: 26, borderRadius: 13,
        background: on ? 'var(--blue)' : 'var(--surface-2)',
        position: 'relative', transition: 'background 280ms',
        flexShrink: 0,
      }}
    >
      <span style={{
        position: 'absolute', top: 3, left: on ? 21 : 3,
        width: 20, height: 20, borderRadius: '50%',
        background: 'white', transition: 'left 280ms cubic-bezier(0.4,0,0.2,1)',
      }} />
    </button>
  )
}

export default function SettingsPage() {
  const { theme, toggleTheme } = useTheme()
  const [notifications, setNotifications] = useState(true)
  const [autoScan, setAutoScan] = useState(false)
  const isDark = theme === 'dark'

  return (
    <>
      <h1 className="page-title">Settings</h1>
      <p className="page-subtitle">Customize your Nexora experience.</p>

      <div className="section-label">Appearance</div>
      <div className="settings-group">
        <div className="settings-row">
          <div className="settings-row-icon">
            {isDark ? <Moon size={18} /> : <Sun size={18} />}
          </div>
          <span style={{ flex: 1, fontSize: 15, fontWeight: 500 }}>Dark Mode</span>
          <Toggle on={isDark} onClick={toggleTheme} />
        </div>
        <div className="settings-row" style={{ cursor: 'pointer' }}>
          <div className="settings-row-icon"><Globe size={18} /></div>
          <span style={{ flex: 1, fontSize: 15, fontWeight: 500 }}>Language</span>
          <span style={{ fontSize: 14, color: 'var(--text-2)' }}>English</span>
          <ChevronRight size={18} color="var(--text-2)" style={{ marginLeft: 8 }} />
        </div>
      </div>

      <div className="section-label">Security</div>
      <div className="settings-group">
        <div className="settings-row">
          <div className="settings-row-icon"><Shield size={18} /></div>
          <span style={{ flex: 1, fontSize: 15, fontWeight: 500 }}>Auto-scan links</span>
          <Toggle on={autoScan} onClick={() => setAutoScan(!autoScan)} />
        </div>
      </div>

      <div className="section-label">Notifications</div>
      <div className="settings-group">
        <div className="settings-row">
          <div className="settings-row-icon"><Bell size={18} /></div>
          <span style={{ flex: 1, fontSize: 15, fontWeight: 500 }}>Push notifications</span>
          <Toggle on={notifications} onClick={() => setNotifications(!notifications)} />
        </div>
      </div>

      <div className="section-label">About</div>
      <div className="settings-group">
        <div className="settings-row">
          <div className="settings-row-icon"><Info size={18} /></div>
          <span style={{ flex: 1, fontSize: 15, fontWeight: 500 }}>Version</span>
          <span style={{ fontSize: 14, color: 'var(--text-2)' }}>3.0.0</span>
        </div>
      </div>
    </>
  )
}
