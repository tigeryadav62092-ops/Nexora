import { useState, useEffect } from 'react'
import { Shield, KeyRound, Mail, Globe, User, Smartphone, TrendingUp, Lock, AlertTriangle, ShieldCheck, ShieldAlert, Calendar, ChevronRight } from 'lucide-react'
import { fetchSecurityScore, updateSecurityScore, fetchScans, type SecurityScoreRow, type ScanRow } from '../lib/scanApi'
import { verdictColor, verdictLabel, scanTypeLabels } from '../data/appData'

export default function SecurityDashboardPage() {
  const [score, setScore] = useState<SecurityScoreRow | null>(null)
  const [scans, setScans] = useState<ScanRow[]>([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    (async () => {
      const s = await fetchSecurityScore()
      if (s) setScore(s)
      const sc = await fetchScans()
      setScans(sc)
      setLoading(false)
    })()
  }, [])

  const refreshScore = async () => {
    setLoading(true)
    const updated = await updateSecurityScore()
    if (updated) setScore(updated)
    const sc = await fetchScans()
    setScans(sc)
    setLoading(false)
  }

  const overall = score?.overall_score ?? 0
  const ringColor = overall >= 75 ? '#34D399' : overall >= 50 ? '#FBBF24' : '#F87171'
  const circumference = 2 * Math.PI * 52
  const offset = circumference - (overall / 100) * circumference

  const categories = [
    { label: 'Password Security', value: score?.password_score ?? 50, icon: KeyRound, color: '#10B981' },
    { label: 'Email Safety', value: score?.email_score ?? 50, icon: Mail, color: '#34D399' },
    { label: 'Browsing Safety', value: score?.browsing_score ?? 50, icon: Globe, color: '#3B82F6' },
    { label: 'Identity Protection', value: score?.identity_score ?? 50, icon: User, color: '#8B5CF6' },
    { label: 'Device Security', value: score?.device_score ?? 50, icon: Smartphone, color: '#F59E0B' },
  ]

  const scoreLabel = overall >= 80 ? 'Excellent' : overall >= 60 ? 'Good' : overall >= 40 ? 'Fair' : 'At Risk'
  const scoreColor = overall >= 80 ? '#34D399' : overall >= 60 ? '#60A5FA' : overall >= 40 ? '#FBBF24' : '#F87171'

  // Threat statistics
  const safeCount = scans.filter(s => s.verdict === 'safe').length
  const suspiciousCount = scans.filter(s => s.verdict === 'suspicious').length
  const dangerousCount = scans.filter(s => s.verdict === 'dangerous').length
  const totalScans = scans.length || (score?.scans_run ?? 0)

  // Weekly bar chart data (last 7 days)
  const weeklyData = (() => {
    const days: { label: string; safe: number; threat: number }[] = []
    const now = new Date()
    for (let i = 6; i >= 0; i--) {
      const day = new Date(now)
      day.setDate(now.getDate() - i)
      const dayStart = new Date(day.getFullYear(), day.getMonth(), day.getDate())
      const dayEnd = new Date(day.getFullYear(), day.getMonth(), day.getDate() + 1)
      const dayScans = scans.filter(s => {
        const d = new Date(s.created_at)
        return d >= dayStart && d < dayEnd
      })
      days.push({
        label: day.toLocaleDateString('en', { weekday: 'short' }).charAt(0),
        safe: dayScans.filter(s => s.verdict === 'safe').length,
        threat: dayScans.filter(s => s.verdict !== 'safe').length,
      })
    }
    return days
  })()

  const maxWeekly = Math.max(1, ...weeklyData.map(d => d.safe + d.threat))

  // Recent scans (top 5)
  const recentScans = scans.slice(0, 5)

  return (
    <>
      <h1 className="page-title">Security Dashboard</h1>
      <p className="page-subtitle">Your overall cybersecurity health.</p>

      {/* Overall score ring */}
      <div className="glass fade-in-up" style={{ padding: 28, textAlign: 'center', marginBottom: 20 }}>
        <div className="score-ring" style={{ margin: '0 auto 16px', width: 130, height: 130 }}>
          <svg width="130" height="130" viewBox="0 0 130 130">
            <circle className="score-ring-bg" cx="65" cy="65" r="52" />
            <circle
              className="score-ring-fill"
              cx="65" cy="65" r="52"
              stroke={ringColor}
              strokeDasharray={circumference}
              strokeDashoffset={loading ? circumference : offset}
            />
          </svg>
          <div style={{ position: 'absolute', display: 'flex', flexDirection: 'column', alignItems: 'center' }}>
            <span className="count-up" style={{ fontSize: 36, fontWeight: 800, color: scoreColor }}>
              {loading ? '--' : overall}
            </span>
            <span style={{ fontSize: 12, color: 'var(--text-2)', fontWeight: 600 }}>{loading ? 'Loading' : scoreLabel}</span>
          </div>
        </div>
        <div style={{ display: 'flex', justifyContent: 'center', gap: 24, marginTop: 8 }}>
          <div style={{ textAlign: 'center' }}>
            <div style={{ fontSize: 22, fontWeight: 800 }}>{totalScans}</div>
            <div style={{ fontSize: 11, color: 'var(--text-2)' }}>Scans Run</div>
          </div>
          <div style={{ textAlign: 'center' }}>
            <div style={{ fontSize: 22, fontWeight: 800, color: 'var(--error)' }}>{dangerousCount}</div>
            <div style={{ fontSize: 11, color: 'var(--text-2)' }}>Threats Found</div>
          </div>
        </div>
        <button className="btn-outlined" style={{ marginTop: 16, height: 44, fontSize: 14 }} onClick={refreshScore} disabled={loading}>
          <TrendingUp size={16} /> Recalculate Score
        </button>
      </div>

      {/* Threat Statistics */}
      <div className="section-label">Threat Statistics</div>
      <div style={{ display: 'flex', gap: 10, marginBottom: 20 }} className="fade-in-up">
        <div className="stat-card">
          <ShieldCheck size={20} color="#34D399" style={{ margin: '0 auto 4px' }} />
          <div className="stat-card-value" style={{ color: '#34D399' }}>{safeCount}</div>
          <div className="stat-card-label">Safe</div>
        </div>
        <div className="stat-card">
          <ShieldAlert size={20} color="#FBBF24" style={{ margin: '0 auto 4px' }} />
          <div className="stat-card-value" style={{ color: '#FBBF24' }}>{suspiciousCount}</div>
          <div className="stat-card-label">Suspicious</div>
        </div>
        <div className="stat-card">
          <AlertTriangle size={20} color="#F87171" style={{ margin: '0 auto 4px' }} />
          <div className="stat-card-value" style={{ color: '#F87171' }}>{dangerousCount}</div>
          <div className="stat-card-label">Dangerous</div>
        </div>
      </div>

      {/* Weekly Report */}
      <div className="section-label">Weekly Report</div>
      <div className="glass fade-in-up" style={{ marginBottom: 20, animationDelay: '100ms' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 8, padding: '16px 16px 0' }}>
          <Calendar size={16} color="var(--blue-light)" />
          <span style={{ fontSize: 14, fontWeight: 600 }}>Last 7 Days</span>
        </div>
        <div className="weekly-bar-chart">
          {weeklyData.map((d, i) => {
            const total = d.safe + d.threat
            const totalH = (total / maxWeekly) * 80
            const threatH = total > 0 ? (d.threat / total) * totalH : 0
            const safeH = total > 0 ? (d.safe / total) * totalH : 0
            return (
              <div key={i} className="weekly-bar-col">
                <div style={{ display: 'flex', flexDirection: 'column', justifyContent: 'flex-end', height: 80 }}>
                  {d.threat > 0 && (
                    <div className="weekly-bar" style={{ height: `${threatH}px`, background: '#F87171' }} />
                  )}
                  {d.safe > 0 && (
                    <div className="weekly-bar" style={{ height: `${safeH}px`, background: '#34D399' }} />
                  )}
                  {total === 0 && (
                    <div className="weekly-bar" style={{ height: '4px', background: 'var(--surface-2)' }} />
                  )}
                </div>
                <div className="weekly-bar-label">{d.label}</div>
              </div>
            )
          })}
        </div>
        <div style={{ display: 'flex', justifyContent: 'center', gap: 16, padding: '0 16px 16px' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 6, fontSize: 12, color: 'var(--text-2)' }}>
            <div style={{ width: 10, height: 10, borderRadius: 3, background: '#34D399' }} /> Safe
          </div>
          <div style={{ display: 'flex', alignItems: 'center', gap: 6, fontSize: 12, color: 'var(--text-2)' }}>
            <div style={{ width: 10, height: 10, borderRadius: 3, background: '#F87171' }} /> Threats
          </div>
        </div>
      </div>

      {/* Category scores */}
      <div className="section-label">Category Breakdown</div>
      {categories.map((cat, i) => {
        const color = cat.value >= 75 ? '#34D399' : cat.value >= 50 ? '#FBBF24' : '#F87171'
        return (
          <div key={cat.label} className="score-category fade-in-up" style={{ animationDelay: `${i * 60}ms` }}>
            <div className="score-category-icon" style={{ background: `${cat.color}22` }}>
              <cat.icon size={20} color={cat.color} />
            </div>
            <div style={{ flex: 1 }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 6 }}>
                <span style={{ fontSize: 14, fontWeight: 600 }}>{cat.label}</span>
                <span style={{ fontSize: 14, fontWeight: 700, color }}>{cat.value}/100</span>
              </div>
              <div className="score-bar-track">
                <div className="score-bar-fill" style={{ width: `${cat.value}%`, background: color }} />
              </div>
            </div>
          </div>
        )
      })}

      {/* Recent Scans */}
      <div className="section-label">Recent Scans</div>
      {recentScans.length === 0 ? (
        <div className="empty-state">
          <ShieldCheck size={32} color="var(--text-2)" style={{ marginBottom: 12 }} />
          <div>No scans yet. Run a scan to see it here.</div>
        </div>
      ) : (
        recentScans.map((scan, i) => {
          const color = verdictColor(scan.verdict)
          return (
            <div key={scan.id} className="glass fade-in-up" style={{ padding: 14, marginBottom: 8, display: 'flex', alignItems: 'center', gap: 12, animationDelay: `${i * 40}ms` }}>
              <div style={{ width: 36, height: 36, borderRadius: 10, background: `${color}22`, display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0 }}>
                {scan.verdict === 'safe' ? <ShieldCheck size={18} color={color} /> : <AlertTriangle size={18} color={color} />}
              </div>
              <div style={{ flex: 1, minWidth: 0 }}>
                <div style={{ fontSize: 14, fontWeight: 600, whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>{scan.input}</div>
                <div style={{ fontSize: 12, color: 'var(--text-2)' }}>{scanTypeLabels[scan.scan_type] || scan.scan_type}</div>
              </div>
              <span className="badge" style={{ background: `${color}22`, color }}>{verdictLabel(scan.verdict)}</span>
            </div>
          )
        })
      )}

      {/* Recommendations */}
      <div className="section-label">Recommendations</div>
      <div className="glass fade-in-up" style={{ padding: 16, animationDelay: '300ms' }}>
        {overall < 80 && (
          <div style={{ display: 'flex', gap: 10, marginBottom: 12, fontSize: 14, color: 'var(--text)', lineHeight: 1.5 }}>
            <Lock size={18} color="var(--warning)" style={{ flexShrink: 0, marginTop: 1 }} />
            <span>Enable two-factor authentication on your key accounts.</span>
          </div>
        )}
        {(score?.password_score ?? 50) < 75 && (
          <div style={{ display: 'flex', gap: 10, marginBottom: 12, fontSize: 14, color: 'var(--text)', lineHeight: 1.5 }}>
            <KeyRound size={18} color="var(--warning)" style={{ flexShrink: 0, marginTop: 1 }} />
            <span>Use a password manager to generate and store strong, unique passwords.</span>
          </div>
        )}
        {(score?.email_score ?? 50) < 75 && (
          <div style={{ display: 'flex', gap: 10, marginBottom: 12, fontSize: 14, color: 'var(--text)', lineHeight: 1.5 }}>
            <Mail size={18} color="var(--warning)" style={{ flexShrink: 0, marginTop: 1 }} />
            <span>Check your email for data breaches and update compromised passwords.</span>
          </div>
        )}
        <div style={{ display: 'flex', gap: 10, fontSize: 14, color: 'var(--text)', lineHeight: 1.5 }}>
          <Shield size={18} color="var(--blue-light)" style={{ flexShrink: 0, marginTop: 1 }} />
          <span>Run regular scans across all tools to keep your security score up to date.</span>
        </div>
      </div>
    </>
  )
}
