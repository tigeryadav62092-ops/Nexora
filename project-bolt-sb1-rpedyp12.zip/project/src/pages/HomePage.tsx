import { useNavigate } from 'react-router-dom'
import { Search, Bell, ShieldCheck, ChevronRight, Siren } from 'lucide-react'
import { LogoWordmark } from '../components/Logo'
import { FeatureCard } from '../components/FeatureCard'
import { features } from '../data/appData'

export default function HomePage() {
  const navigate = useNavigate()

  const scanners = features.filter(f => f.category === 'scanner')
  const checkers = features.filter(f => f.category === 'checker')
  const assistants = features.filter(f => f.category === 'assistant')
  const emergency = features.filter(f => f.category === 'emergency')

  return (
    <>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 24 }} className="fade-in">
        <LogoWordmark />
        <button
          onClick={() => navigate('/notifications')}
          style={{ position: 'relative', width: 44, height: 44, borderRadius: 12, background: 'var(--surface)', border: '1px solid var(--outline)', display: 'flex', alignItems: 'center', justifyContent: 'center' }}
        >
          <Bell size={20} color="var(--text-2)" />
          <span style={{ position: 'absolute', top: 8, right: 8, width: 8, height: 8, borderRadius: '50%', background: 'var(--error)', border: '2px solid var(--surface)' }} />
        </button>
      </div>

      <div className="fade-in-up" style={{ animationDelay: '50ms' }}>
        <h1 style={{ fontSize: 28, fontWeight: 800, letterSpacing: '-0.5px' }}>
          Stay safe, <span className="text-gradient">stay ahead.</span>
        </h1>
        <p style={{ color: 'var(--text-2)', fontSize: 15, marginTop: 4, marginBottom: 20, lineHeight: 1.5 }}>
          AI-powered cybersecurity: scan links, files, screenshots, and messages.
        </p>
      </div>

      {/* Security Dashboard card */}
      <div
        className="fade-in-up glass pulse-glow"
        style={{ animationDelay: '80ms', display: 'flex', alignItems: 'center', gap: 14, padding: '16px 18px', borderRadius: 16, marginBottom: 12, cursor: 'pointer' }}
        onClick={() => navigate('/dashboard')}
      >
        <div style={{ width: 48, height: 48, borderRadius: 14, background: 'linear-gradient(135deg, var(--blue), var(--purple))', display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0 }}>
          <ShieldCheck size={24} color="white" />
        </div>
        <div style={{ flex: 1 }}>
          <div style={{ fontSize: 16, fontWeight: 700 }}>Security Dashboard</div>
          <div style={{ fontSize: 13, color: 'var(--text-2)' }}>Score, weekly report & threat statistics</div>
        </div>
        <ChevronRight size={20} color="var(--text-2)" />
      </div>

      {/* Emergency SOS card */}
      <div
        className="fade-in-up glass"
        style={{ animationDelay: '100ms', display: 'flex', alignItems: 'center', gap: 14, padding: '16px 18px', borderRadius: 16, marginBottom: 20, cursor: 'pointer', border: '1px solid rgba(220,38,38,0.3)' }}
        onClick={() => navigate('/scanner/sos')}
      >
        <div style={{ width: 48, height: 48, borderRadius: 14, background: 'linear-gradient(135deg, #DC2626, #991B1B)', display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0 }}>
          <Siren size={24} color="white" />
        </div>
        <div style={{ flex: 1 }}>
          <div style={{ fontSize: 16, fontWeight: 700 }}>Emergency SOS</div>
          <div style={{ fontSize: 13, color: 'var(--text-2)' }}>One-tap cyber help guide & contacts</div>
        </div>
        <ChevronRight size={20} color="var(--text-2)" />
      </div>

      <div
        className="fade-in-up glass"
        style={{ animationDelay: '120ms', display: 'flex', alignItems: 'center', gap: 12, padding: '14px 16px', borderRadius: 12, marginBottom: 24, cursor: 'pointer' }}
        onClick={() => navigate('/scanner')}
      >
        <Search size={20} color="var(--text-2)" />
        <span style={{ color: 'var(--text-2)', fontSize: 15 }}>What would you like to scan?</span>
      </div>

      <div className="section-label fade-in-up" style={{ animationDelay: '150ms' }}>Scanners</div>
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12 }}>
        {scanners.map((f, i) => (
          <FeatureCard key={f.id} feature={f} index={i} />
        ))}
      </div>

      <div className="section-label fade-in-up" style={{ animationDelay: '200ms' }}>Checkers</div>
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12 }}>
        {checkers.map((f, i) => (
          <FeatureCard key={f.id} feature={f} index={i + scanners.length} />
        ))}
      </div>

      <div className="section-label fade-in-up" style={{ animationDelay: '250ms' }}>Assistant</div>
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12 }}>
        {assistants.map((f, i) => (
          <FeatureCard key={f.id} feature={f} index={i + scanners.length + checkers.length} />
        ))}
      </div>

      {emergency.length > 0 && (
        <>
          <div className="section-label fade-in-up" style={{ animationDelay: '300ms' }}>Emergency</div>
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12 }}>
            {emergency.map((f, i) => (
              <FeatureCard key={f.id} feature={f} index={i + scanners.length + checkers.length + assistants.length} />
            ))}
          </div>
        </>
      )}
    </>
  )
}
