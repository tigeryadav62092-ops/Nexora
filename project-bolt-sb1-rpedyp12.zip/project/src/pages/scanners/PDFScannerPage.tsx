import { useState, useRef } from 'react'
import { FileText, Scan, X, Upload, AlertCircle } from 'lucide-react'
import { features } from '../../data/appData'
import { ScannerHero } from '../../components/ScannerHero'
import { ScanResultCard } from '../../components/ScanResultCard'
import { ScanResultSkeleton } from '../../components/Shimmer'
import { saveScan, type ScanResult } from '../../lib/scanApi'

const feature = features.find(f => f.id === 'pdf')!

const ACCEPTED = 'application/pdf'
const MAX_SIZE = 20 * 1024 * 1024

export default function PDFScannerPage() {
  const [loading, setLoading] = useState(false)
  const [result, setResult] = useState<ScanResult | null>(null)
  const [fileName, setFileName] = useState<string | null>(null)
  const [error, setError] = useState<string | null>(null)
  const fileInputRef = useRef<HTMLInputElement>(null)

  const onFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (!file) return
    const isPdf = file.type === 'application/pdf' || file.name.toLowerCase().endsWith('.pdf')
    if (!isPdf) {
      setError('Unsupported format. Please select a PDF file.')
      return
    }
    if (file.size > MAX_SIZE) {
      setError('File is too large. Maximum size is 20MB.')
      return
    }
    setError(null)
    setFileName(file.name)
    setResult(null)
  }

  const clearFile = () => {
    setFileName(null)
    setResult(null)
    setError(null)
    if (fileInputRef.current) fileInputRef.current.value = ''
  }

  const scan = async () => {
    if (!fileName) {
      setError('Please select a PDF file first.')
      return
    }
    setLoading(true)
    setResult(null)
    await new Promise(r => setTimeout(r, 2200))

    const dangerousKeywords = ['javascript', 'embedded', 'openaction', 'launch', 'uri']
    const suspicious = fileName.toLowerCase().includes('invoice') || fileName.toLowerCase().includes('payment')
    const res: ScanResult = suspicious
      ? {
          verdict: 'dangerous',
          summary: 'This PDF contains potentially malicious embedded content. Do not open it on an untrusted device.',
          details: [
            'Embedded JavaScript detected',
            'OpenAction trigger found',
            'Suspicious URI redirect to external domain',
            'File size anomaly: metadata mismatch',
            'Confidence: 91%',
          ],
          confidence: 91,
        }
      : {
          verdict: 'safe',
          summary: 'No malicious content detected in this PDF. It appears safe to open.',
          details: [
            'No embedded JavaScript found',
            'No OpenAction triggers detected',
            'No suspicious external links',
            'Metadata is consistent',
            'Confidence: 95%',
          ],
          confidence: 95,
        }
    setResult(res)
    setLoading(false)
    saveScan({ scanType: 'pdf', input: fileName, ...res })
  }

  return (
    <>
      <ScannerHero feature={feature} />
      <div className="fade-in-up" style={{ animationDelay: '100ms' }}>
        <input
          ref={fileInputRef}
          type="file"
          accept={ACCEPTED}
          onChange={onFileChange}
          style={{ position: 'absolute', width: 1, height: 1, opacity: 0, left: -9999, top: -9999 }}
        />

        {!fileName && (
          <div className="upload-zone" onClick={() => fileInputRef.current?.click()}>
            <Upload size={32} color="var(--text-2)" />
            <div style={{ marginTop: 12, fontSize: 15, fontWeight: 600 }}>Tap to upload a PDF</div>
            <div style={{ fontSize: 13, color: 'var(--text-2)', marginTop: 4 }}>PDF files up to 20MB</div>
          </div>
        )}

        {fileName && (
          <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginTop: 4, padding: '14px 16px', background: 'var(--surface)', borderRadius: 12, border: '1px solid var(--outline)' }} className="fade-in">
            <FileText size={22} color="#F97316" />
            <span style={{ fontSize: 14, flex: 1, whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>{fileName}</span>
            <button onClick={clearFile} style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', width: 28, height: 28, borderRadius: 8, background: 'var(--surface-2)' }}>
              <X size={16} color="var(--text-2)" />
            </button>
          </div>
        )}

        {error && (
          <div className="fade-in" style={{ marginTop: 10, fontSize: 13, color: 'var(--error)', padding: '8px 12px', background: 'rgba(248,113,113,0.1)', borderRadius: 8, display: 'flex', gap: 8, alignItems: 'center' }}>
            <AlertCircle size={16} /> {error}
          </div>
        )}

        {fileName && (
          <button className="btn-primary" style={{ marginTop: 14 }} onClick={scan} disabled={loading}>
            <Scan size={18} /> {loading ? 'Analyzing…' : 'Scan PDF'}
          </button>
        )}
      </div>
      <div style={{ marginTop: 24 }}>
        {loading && <ScanResultSkeleton />}
        {result && <ScanResultCard verdict={result.verdict} summary={result.summary} details={result.details} />}
      </div>
    </>
  )
}
