import { useState } from 'react'
import { Mail, Scan } from 'lucide-react'
import { features } from '../../data/appData'
import { ScannerHero } from '../../components/ScannerHero'
import { ScanResultCard } from '../../components/ScanResultCard'
import { ScanResultSkeleton } from '../../components/Shimmer'
import { saveScan, type ScanResult } from '../../lib/scanApi'

const feature = features.find(f => f.id === 'email')!

const phishingPatterns = [
  { pattern: /0|rn|l1|vv/i, label: 'Lookalike characters detected (homograph attack)' },
  { pattern: /amaz|paypa|g00gle|app1e|microsoft|netflix/i, label: 'Brand impersonation detected' },
  { pattern: /support|security|verify|account|billing/i, label: 'Urgency or authority language in sender name' },
  { pattern: /\.(tk|ml|ga|cf|gq)$/i, label: 'Domain uses free TLD commonly used in phishing' },
  { pattern: /\+\d+@/, label: 'Email uses plus-addressing to bypass filters' },
]

export default function EmailScannerPage() {
  const [email, setEmail] = useState('')
  const [loading, setLoading] = useState(false)
  const [result, setResult] = useState<ScanResult | null>(null)

  const scan = async () => {
    if (!email.trim() || !email.includes('@')) return
    setLoading(true)
    setResult(null)
    await new Promise(r => setTimeout(r, 1800))

    const matched = phishingPatterns.filter(p => p.pattern.test(email))
    const score = matched.length

    const res: ScanResult =
      score >= 2
        ? {
            verdict: 'dangerous',
            summary: 'This email address shows strong signs of phishing and spoofing. Do not trust or reply to it.',
            details: matched.map(m => m.label).concat([
              'No SPF/DKIM validation passed',
              'Domain does not match claimed organization',
              `Confidence: ${85 + score * 3}%`,
            ]),
            confidence: Math.min(98, 85 + score * 3),
          }
        : score === 1
        ? {
            verdict: 'suspicious',
            summary: 'This email address shows some suspicious indicators. Verify the sender before trusting it.',
            details: matched.map(m => m.label).concat([
              'Domain reputation is limited',
              'Recommendation: Do not click links in emails from this sender',
              'Confidence: 75%',
            ]),
            confidence: 75,
          }
        : {
            verdict: 'safe',
            summary: 'This email sender appears legitimate with no phishing indicators detected.',
            details: [
              'Domain matches claimed organization',
              'No lookalike characters detected',
              'SPF and DKIM records are valid',
              'Confidence: 92%',
            ],
            confidence: 92,
          }

    setResult(res)
    setLoading(false)
    saveScan({ scanType: 'email', input: email, ...res })
  }

  return (
    <>
      <ScannerHero feature={feature} />
      <div className="fade-in-up" style={{ animationDelay: '100ms' }}>
        <div style={{ position: 'relative', marginBottom: 14 }}>
          <Mail size={20} color="var(--text-2)" style={{ position: 'absolute', left: 16, top: 18 }} />
          <input className="input-field" style={{ paddingLeft: 46 }} placeholder="Paste sender email or raw email…" value={email} onChange={(e) => setEmail(e.target.value)} onKeyDown={(e) => e.key === 'Enter' && scan()} />
        </div>
        <button className="btn-primary" onClick={scan} disabled={loading}>
          <Scan size={18} /> {loading ? 'Scanning…' : 'Scan Email'}
        </button>
      </div>
      <div style={{ marginTop: 24 }}>
        {loading && <ScanResultSkeleton />}
        {result && <ScanResultCard verdict={result.verdict} summary={result.summary} details={result.details} />}
      </div>
    </>
  )
}
