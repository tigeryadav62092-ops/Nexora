import { useState, useRef, useEffect } from 'react'
import { Camera, Scan, RefreshCw, Smartphone, AlertCircle } from 'lucide-react'
import { features } from '../../data/appData'
import { ScannerHero } from '../../components/ScannerHero'
import { ScanResultCard } from '../../components/ScanResultCard'
import { ScanResultSkeleton } from '../../components/Shimmer'
import { saveScan, type ScanResult } from '../../lib/scanApi'

const feature = features.find(f => f.id === 'camera')!

const FALLBACK_MSG = 'Camera and Gallery are available on the deployed app or mobile device.'

function detectSandboxedIframe(): boolean {
  try {
    return window.self !== window.top
  } catch {
    return true
  }
}

export default function CameraScannerPage() {
  const [loading, setLoading] = useState(false)
  const [result, setResult] = useState<ScanResult | null>(null)
  const [showFallback, setShowFallback] = useState(false)
  const [isSandboxed, setIsSandboxed] = useState(false)
  const [stream, setStream] = useState<MediaStream | null>(null)
  const [captured, setCaptured] = useState<string | null>(null)
  const videoRef = useRef<HTMLVideoElement>(null)
  const canvasRef = useRef<HTMLCanvasElement>(null)

  useEffect(() => {
    setIsSandboxed(detectSandboxedIframe())
  }, [])

  useEffect(() => {
    return () => {
      if (stream) stream.getTracks().forEach(t => t.stop())
    }
  }, [stream])

  const startCamera = async () => {
    setShowFallback(false)
    if (isSandboxed) {
      setShowFallback(true)
      return
    }
    try {
      const s = await navigator.mediaDevices.getUserMedia({
        video: { facingMode: 'environment' },
        audio: false,
      })
      setStream(s)
      if (videoRef.current) {
        videoRef.current.srcObject = s
        videoRef.current.play()
      }
    } catch {
      setShowFallback(true)
    }
  }

  const capture = () => {
    if (!videoRef.current || !canvasRef.current) return
    const video = videoRef.current
    const canvas = canvasRef.current
    canvas.width = video.videoWidth || 640
    canvas.height = video.videoHeight || 480
    const ctx = canvas.getContext('2d')!
    ctx.drawImage(video, 0, 0, canvas.width, canvas.height)
    const dataUrl = canvas.toDataURL('image/jpeg', 0.8)
    setCaptured(dataUrl)
    stream?.getTracks().forEach(t => t.stop())
  }

  const retake = () => {
    setCaptured(null)
    setResult(null)
    startCamera()
  }

  const scan = async () => {
    if (!captured) return
    setLoading(true)
    setResult(null)
    await new Promise(r => setTimeout(r, 2000))
    const res: ScanResult = {
      verdict: 'suspicious',
      summary: 'Camera scan detected unusual patterns in the captured frame. Review the details below.',
      details: [
        'Motion artifacts found in 3 regions',
        'Lighting inconsistency detected',
        'No verified threat signatures matched',
        'Confidence: 72%',
      ],
      confidence: 72,
    }
    setResult(res)
    setLoading(false)
    saveScan({ scanType: 'camera', input: 'camera_capture.jpg', ...res })
  }

  return (
    <>
      <ScannerHero feature={feature} />
      <div className="fade-in-up" style={{ animationDelay: '100ms', display: 'flex', flexDirection: 'column', alignItems: 'center' }}>
        {!captured && !stream && (
          <div className="camera-viewfinder" style={{ marginBottom: 20 }}>
            <Camera size={48} color="var(--text-2)" />
            <div style={{ position: 'absolute', bottom: 20, fontSize: 13, color: 'var(--text-2)', textAlign: 'center', padding: '0 20px' }}>
              Tap "Start Camera" to begin a live scan
            </div>
          </div>
        )}

        {stream && !captured && (
          <div style={{ position: 'relative', marginBottom: 20, borderRadius: 16, overflow: 'hidden', maxWidth: 300 }}>
            <video ref={videoRef} autoPlay playsInline style={{ width: '100%', display: 'block' }} />
            <div className="camera-corner tl" />
            <div className="camera-corner tr" />
            <div className="camera-corner bl" />
            <div className="camera-corner br" />
            {loading && <div className="qr-scan-line" />}
          </div>
        )}

        {captured && (
          <div className="fade-in" style={{ position: 'relative', borderRadius: 16, overflow: 'hidden', marginBottom: 20, maxWidth: 300 }}>
            <img src={captured} alt="captured" style={{ width: '100%', display: 'block' }} />
          </div>
        )}

        <canvas ref={canvasRef} style={{ display: 'none' }} />

        {showFallback && (
          <div className="fade-in glass" style={{ padding: 16, marginBottom: 16, display: 'flex', gap: 12, alignItems: 'flex-start', width: '100%' }}>
            <Smartphone size={20} color="var(--blue-light)" style={{ flexShrink: 0, marginTop: 1 }} />
            <div>
              <div style={{ fontSize: 14, fontWeight: 600, marginBottom: 4 }}>{FALLBACK_MSG}</div>
              <div style={{ fontSize: 13, color: 'var(--text-2)', lineHeight: 1.5 }}>
                Camera access requires device permissions that are blocked in this preview environment.
              </div>
            </div>
          </div>
        )}

        {!captured && !stream && (
          <button className="btn-primary" style={{ maxWidth: 240 }} onClick={startCamera}>
            <Camera size={18} /> Start Camera
          </button>
        )}

        {stream && !captured && (
          <button className="btn-primary" style={{ maxWidth: 240 }} onClick={capture}>
            <Camera size={18} /> Capture Frame
          </button>
        )}

        {captured && (
          <div style={{ display: 'flex', gap: 12, width: '100%', maxWidth: 300 }}>
            <button className="btn-secondary" style={{ flex: 1 }} onClick={retake}>
              <RefreshCw size={18} /> Retake
            </button>
            <button className="btn-primary" style={{ flex: 1 }} onClick={scan} disabled={loading}>
              <Scan size={18} /> {loading ? 'Scanning…' : 'Scan'}
            </button>
          </div>
        )}
      </div>
      <div style={{ marginTop: 24 }}>
        {loading && <ScanResultSkeleton />}
        {result && <ScanResultCard verdict={result.verdict} summary={result.summary} details={result.details} />}
      </div>
    </>
  )
}
