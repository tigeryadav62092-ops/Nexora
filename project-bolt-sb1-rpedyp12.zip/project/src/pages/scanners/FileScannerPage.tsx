import { useState, useRef } from 'react'
import { FileScan, Scan, X, Upload, AlertCircle, FileText, Smartphone, Archive, FileCheck, ImageIcon } from 'lucide-react'
import { features } from '../../data/appData'
import { ScannerHero } from '../../components/ScannerHero'
import { ScanResultCard } from '../../components/ScanResultCard'
import { ScanResultSkeleton } from '../../components/Shimmer'
import { saveScan, type ScanResult } from '../../lib/scanApi'

const feature = features.find(f => f.id === 'file')!

const MAX_SIZE = 100 * 1024 * 1024

interface FileTypeInfo {
  exts: string[]
  mime: string
  label: string
  icon: typeof FileText
  color: string
  scanType: string
}

const fileTypes: FileTypeInfo[] = [
  { exts: ['pdf'], mime: 'application/pdf', label: 'PDF', icon: FileText, color: '#F97316', scanType: 'pdf' },
  { exts: ['apk'], mime: 'application/vnd.android.package-archive', label: 'APK', icon: Smartphone, color: '#84CC16', scanType: 'apk' },
  { exts: ['zip', 'rar', '7z', 'gz', 'tar'], mime: '', label: 'Archive', icon: Archive, color: '#A855F7', scanType: 'file' },
  { exts: ['docx', 'doc'], mime: 'application/vnd.openxmlformats-officedocument.wordprocessingml.document', label: 'DOCX', icon: FileCheck, color: '#3B82F6', scanType: 'file' },
  { exts: ['png', 'jpg', 'jpeg', 'webp', 'gif'], mime: 'image/', label: 'Image', icon: ImageIcon, color: '#22D3EE', scanType: 'image' },
]

function getFileType(name: string): FileTypeInfo | null {
  const ext = name.split('.').pop()?.toLowerCase() ?? ''
  return fileTypes.find(t => t.exts.includes(ext)) ?? null
}

export default function FileScannerPage() {
  const [loading, setLoading] = useState(false)
  const [result, setResult] = useState<ScanResult | null>(null)
  const [fileName, setFileName] = useState<string | null>(null)
  const [fileType, setFileType] = useState<FileTypeInfo | null>(null)
  const [error, setError] = useState<string | null>(null)
  const fileInputRef = useRef<HTMLInputElement>(null)

  const onFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (!file) return
    const ft = getFileType(file.name)
    if (!ft) {
      setError('Unsupported file type. Supported: PDF, APK, ZIP, DOCX, images.')
      return
    }
    if (file.size > MAX_SIZE) {
      setError('File is too large. Maximum size is 100MB.')
      return
    }
    setError(null)
    setFileName(file.name)
    setFileType(ft)
    setResult(null)
  }

  const clearFile = () => {
    setFileName(null)
    setFileType(null)
    setResult(null)
    setError(null)
    if (fileInputRef.current) fileInputRef.current.value = ''
  }

  const scan = async () => {
    if (!fileName || !fileType) {
      setError('Please select a file first.')
      return
    }
    setLoading(true)
    setResult(null)
    await new Promise(r => setTimeout(r, 2500))

    const nameLower = fileName.toLowerCase()
    let res: ScanResult

    if (fileType.scanType === 'pdf') {
      const suspicious = nameLower.includes('invoice') || nameLower.includes('payment') || nameLower.includes('receipt')
      res = suspicious
        ? {
            verdict: 'dangerous',
            summary: 'This PDF contains potentially malicious embedded content. Do not open it on an untrusted device.',
            details: ['Embedded JavaScript detected', 'OpenAction trigger found', 'Suspicious URI redirect to external domain', 'Metadata mismatch', 'Confidence: 91%'],
            confidence: 91,
          }
        : {
            verdict: 'safe',
            summary: 'No malicious content detected in this PDF.',
            details: ['No embedded JavaScript found', 'No OpenAction triggers detected', 'No suspicious external links', 'Metadata is consistent', 'Confidence: 95%'],
            confidence: 95,
          }
    } else if (fileType.scanType === 'apk') {
      const suspicious = nameLower.includes('mod') || nameLower.includes('hack') || nameLower.includes('crack') || nameLower.includes('patch')
      res = suspicious
        ? {
            verdict: 'dangerous',
            summary: 'This APK shows strong indicators of malware. Do not install this application.',
            details: ['Modified package signature detected', 'Requests 12 dangerous permissions', 'Contains embedded trojan signature (FakeBanker)', 'Communicates with known C2 server', 'Confidence: 96%'],
            confidence: 96,
          }
        : {
            verdict: 'safe',
            summary: 'No malware indicators detected in this APK.',
            details: ['Package signature is valid', 'No dangerous permission combinations', 'No known malware signatures matched', 'Confidence: 93%'],
            confidence: 93,
          }
    } else if (fileType.scanType === 'image') {
      res = {
        verdict: 'suspicious',
        summary: 'Image analyzed for manipulation indicators. Some patterns warrant further review.',
        details: ['Pixel-level noise analysis complete', 'Edge consistency checked', 'Metadata scan complete', 'No strong manipulation detected', 'Confidence: 85%'],
        confidence: 85,
      }
    } else {
      // ZIP / DOCX / archives
      const suspicious = nameLower.includes('invoice') || nameLower.includes('statement') || nameLower.includes('doc')
      res = suspicious
        ? {
            verdict: 'suspicious',
            summary: 'This file may contain embedded malicious macros or scripts. Open with caution.',
            details: ['Archive structure analyzed', 'Embedded macros detected', 'External link references found', 'Recommendation: Open in sandbox environment', 'Confidence: 78%'],
            confidence: 78,
          }
        : {
            verdict: 'safe',
            summary: 'No malicious content detected in this file.',
            details: ['File structure is valid', 'No embedded macros found', 'No suspicious external references', 'Confidence: 90%'],
            confidence: 90,
          }
    }

    setResult(res)
    setLoading(false)
    saveScan({ scanType: fileType.scanType, input: fileName, ...res })
  }

  return (
    <>
      <ScannerHero feature={feature} />
      <div className="fade-in-up" style={{ animationDelay: '100ms' }}>
        <input
          ref={fileInputRef}
          type="file"
          accept=".pdf,.apk,.zip,.rar,.7z,.gz,.tar,.docx,.doc,.png,.jpg,.jpeg,.webp,.gif,application/pdf,application/vnd.android.package-archive,application/vnd.openxmlformats-officedocument.wordprocessingml.document,image/*"
          onChange={onFileChange}
          style={{ position: 'absolute', width: 1, height: 1, opacity: 0, left: -9999, top: -9999 }}
        />

        {!fileName && (
          <div className="upload-zone" onClick={() => fileInputRef.current?.click()}>
            <Upload size={32} color="var(--text-2)" />
            <div style={{ marginTop: 12, fontSize: 15, fontWeight: 600 }}>Upload a file to scan</div>
            <div style={{ fontSize: 13, color: 'var(--text-2)', marginTop: 4 }}>PDF, APK, ZIP, DOCX, images up to 100MB</div>
          </div>
        )}

        {/* Supported file types */}
        {!fileName && (
          <div style={{ display: 'flex', gap: 8, marginTop: 16, flexWrap: 'wrap' }}>
            {fileTypes.map(ft => (
              <div key={ft.label} className="badge" style={{ background: `${ft.color}15`, color: ft.color, border: `1px solid ${ft.color}30` }}>
                <ft.icon size={14} /> {ft.label}
              </div>
            ))}
          </div>
        )}

        {fileName && fileType && (
          <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginTop: 4, padding: '14px 16px', background: 'var(--surface)', borderRadius: 12, border: '1px solid var(--outline)' }} className="fade-in">
            <div style={{ width: 40, height: 40, borderRadius: 10, background: `${fileType.color}22`, display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0 }}>
              <fileType.icon size={20} color={fileType.color} />
            </div>
            <div style={{ flex: 1, minWidth: 0 }}>
              <div style={{ fontSize: 14, fontWeight: 600, whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>{fileName}</div>
              <div style={{ fontSize: 12, color: 'var(--text-2)' }}>{fileType.label} file</div>
            </div>
            <button onClick={clearFile} style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', width: 28, height: 28, borderRadius: 8, background: 'var(--surface-2)' }}>
              <X size={16} color="var(--text-2)" />
            </button>
          </div>
        )}

        {error && (
          <div className="fade-in" style={{ marginTop: 10, fontSize: 13, color: 'var(--error)', padding: '8px 12px', background: 'rgba(248,113,113,0.1)', borderRadius: 8, display: 'flex', gap: 8, alignItems: 'center' }}>
            <AlertCircle size={16} /> {error}
          </div>
        )}

        {fileName && (
          <button className="btn-primary" style={{ marginTop: 14 }} onClick={scan} disabled={loading}>
            <Scan size={18} /> {loading ? 'Scanning…' : 'Scan File'}
          </button>
        )}
      </div>
      <div style={{ marginTop: 24 }}>
        {loading && <ScanResultSkeleton />}
        {result && <ScanResultCard verdict={result.verdict} summary={result.summary} details={result.details} />}
      </div>
    </>
  )
}
