import { useState } from 'react'
import { Siren, Phone, Mail, Shield, AlertTriangle, Globe, CreditCard, Lock, ChevronRight, X } from 'lucide-react'
import { features } from '../../data/appData'
import { ScannerHero } from '../../components/ScannerHero'
import { saveScan } from '../../lib/scanApi'

const feature = features.find(f => f.id === 'sos')!

const guides = [
  {
    icon: CreditCard,
    color: '#F87171',
    title: 'I was scammed / lost money',
    steps: [
      'Contact your bank immediately — request a transaction reversal',
      'Report to your card provider (Visa/Mastercard) within 24 hours',
      'File a police report with transaction details',
      'Change passwords for any accounts involved',
    ],
  },
  {
    icon: Lock,
    color: '#FBBF24',
    title: 'My account was hacked',
    steps: [
      'Change the password immediately from a trusted device',
      'Enable two-factor authentication',
      'Log out of all sessions / revoke active tokens',
      'Check for unauthorized transactions or changes',
      'Contact the platform\'s support team',
    ],
  },
  {
    icon: Mail,
    color: '#34D399',
    title: 'I clicked a phishing link',
    steps: [
      'Do NOT enter any information on the page',
      'Clear your browser cache and cookies',
      'Run a malware scan on your device',
      'Change passwords for any account you may have entered',
      'Monitor for suspicious activity over the next 48 hours',
    ],
  },
  {
    icon: AlertTriangle,
    color: '#A855F7',
    title: 'I shared personal info',
    steps: [
      'Place a fraud alert with credit bureaus (Equifax, Experian, TransUnion)',
      'Monitor your credit report for new accounts',
      'Change security questions on affected accounts',
      'Consider freezing your credit if identity theft is likely',
    ],
  },
  {
    icon: Globe,
    color: '#3B82F6',
    title: 'Ransomware / device locked',
    steps: [
      'Disconnect from the internet immediately',
      'Do NOT pay the ransom — no guarantee of recovery',
      'Boot into Safe Mode and run antivirus software',
      'Restore from backup if available',
      'Report to local cybercrime authorities',
    ],
  },
  {
    icon: Shield,
    color: '#22D3EE',
    title: 'Identity theft suspected',
    steps: [
      'Contact your bank and freeze affected accounts',
      'File a report with the FTC (identitytheft.gov)',
      'Place a fraud alert on your credit file',
      'Change all passwords and security questions',
      'Document everything for authorities',
    ],
  },
]

const contacts = [
  { icon: Phone, label: 'Cyber Crime Helpline', value: '1930', color: '#DC2626', action: 'tel:1930' },
  { icon: Mail, label: 'Report Phishing', value: 'report@phishing.gov', color: '#3B82F6', action: 'mailto:report@phishing.gov' },
  { icon: Globe, label: 'FTC Identity Theft', value: 'identitytheft.gov', color: '#8B5CF6', action: 'https://identitytheft.gov' },
  { icon: Phone, label: 'Emergency Services', value: '911 / 112', color: '#F87171', action: 'tel:911' },
]

export default function EmergencySOSPage() {
  const [selected, setSelected] = useState<typeof guides[0] | null>(null)

  const handleSOS = () => {
    saveScan({
      scanType: 'sos',
      input: 'Emergency SOS accessed',
      verdict: 'safe',
      summary: 'Cyber emergency help guide opened',
      details: ['User accessed SOS guide'],
      confidence: 100,
    })
  }

  return (
    <>
      <ScannerHero feature={feature} />

      {/* Big SOS button */}
      <div className="fade-in-up" style={{ animationDelay: '100ms', display: 'flex', flexDirection: 'column', alignItems: 'center', marginBottom: 28 }}>
        <button className="sos-button" onClick={handleSOS}>
          <Siren size={36} />
          SOS
        </button>
        <div style={{ marginTop: 12, fontSize: 14, color: 'var(--text-2)', textAlign: 'center', lineHeight: 1.5 }}>
          Tap for instant cyber emergency help
        </div>
      </div>

      {/* Quick contacts */}
      <div className="section-label">Emergency Contacts</div>
      {contacts.map((c, i) => (
        <a
          key={c.label}
          href={c.action}
          className="sos-contact fade-in-up"
          style={{ animationDelay: `${150 + i * 50}ms`, textDecoration: 'none', color: 'inherit' }}
        >
          <div className="sos-contact-icon" style={{ background: `${c.color}22` }}>
            <c.icon size={20} color={c.color} />
          </div>
          <div style={{ flex: 1 }}>
            <div style={{ fontSize: 14, fontWeight: 600 }}>{c.label}</div>
            <div style={{ fontSize: 13, color: 'var(--text-2)' }}>{c.value}</div>
          </div>
          <ChevronRight size={18} color="var(--text-2)" />
        </a>
      ))}

      {/* Help guides */}
      <div className="section-label">What happened?</div>
      {guides.map((g, i) => (
        <div
          key={g.title}
          className="glass fade-in-up"
          style={{ padding: 16, marginBottom: 10, display: 'flex', alignItems: 'center', gap: 14, cursor: 'pointer', animationDelay: `${300 + i * 50}ms` }}
          onClick={() => setSelected(g)}
        >
          <div style={{ width: 44, height: 44, borderRadius: 12, background: `${g.color}22`, display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0 }}>
            <g.icon size={22} color={g.color} />
          </div>
          <div style={{ flex: 1, fontSize: 15, fontWeight: 600 }}>{g.title}</div>
          <ChevronRight size={18} color="var(--text-2)" />
        </div>
      ))}

      {/* Guide detail modal */}
      {selected && (
        <div
          style={{ position: 'fixed', inset: 0, background: 'rgba(0,0,0,0.6)', backdropFilter: 'blur(8px)', zIndex: 200, display: 'flex', alignItems: 'flex-end', justifyContent: 'center' }}
          onClick={() => setSelected(null)}
        >
          <div
            className="glass"
            style={{ width: '100%', maxWidth: 480, borderRadius: '24px 24px 0 0', padding: 24, maxHeight: '80vh', overflowY: 'auto', animation: 'fadeInUp 400ms cubic-bezier(0.4,0,0.2,1) both' }}
            onClick={(e) => e.stopPropagation()}
          >
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 16 }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
                <div style={{ width: 40, height: 40, borderRadius: 12, background: `${selected.color}22`, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                  <selected.icon size={20} color={selected.color} />
                </div>
                <h2 style={{ fontSize: 18, fontWeight: 800 }}>{selected.title}</h2>
              </div>
              <button onClick={() => setSelected(null)} style={{ width: 32, height: 32, borderRadius: 10, background: 'var(--surface-2)', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                <X size={18} color="var(--text-2)" />
              </button>
            </div>
            <div style={{ fontSize: 14, fontWeight: 600, color: 'var(--text-2)', marginBottom: 12 }}>Follow these steps:</div>
            {selected.steps.map((step, i) => (
              <div key={i} style={{ display: 'flex', gap: 12, marginBottom: 14, fontSize: 15, lineHeight: 1.5, color: 'var(--text)' }}>
                <span style={{ width: 28, height: 28, borderRadius: 8, background: `${selected.color}22`, color: selected.color, display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 14, fontWeight: 700, flexShrink: 0 }}>
                  {i + 1}
                </span>
                {step}
              </div>
            ))}
          </div>
        </div>
      )}
    </>
  )
}
