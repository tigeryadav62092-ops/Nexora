import { useState } from 'react'
import { AlertTriangle, Scan, MessageSquare } from 'lucide-react'
import { features } from '../../data/appData'
import { ScannerHero } from '../../components/ScannerHero'
import { ScanResultCard } from '../../components/ScanResultCard'
import { ScanResultSkeleton } from '../../components/Shimmer'
import { saveScan, type ScanResult } from '../../lib/scanApi'

const feature = features.find(f => f.id === 'scam')!

interface ScamSignal {
  pattern: RegExp
  label: string
  weight: number
}

const scamSignals: ScamSignal[] = [
  { pattern: /urgent|immediately|act now|expires today|final notice|last chance/i, label: 'Urgency pressure — tries to make you act before thinking', weight: 2 },
  { pattern: /won|winner|prize|lottery|claim|reward|congratulations/i, label: 'Fake prize or lottery offer', weight: 3 },
  { pattern: /bank account|verify your account|suspended|locked|frozen/i, label: 'Impersonates a bank or service to harvest credentials', weight: 3 },
  { pattern: /bitcoin|crypto|investment|double your|guaranteed return/i, label: 'Cryptocurrency / investment fraud pitch', weight: 3 },
  { pattern: /wire transfer|gift card|paypal.*friend|western union|moneygram/i, label: 'Requests untraceable payment method', weight: 3 },
  { pattern: /bit\.ly|tinyurl|t\.co|shorturl|is\.gd/i, label: 'Uses a shortened URL to hide the real destination', weight: 2 },
  { pattern: /click here|tap link|follow this link|open this/i, label: 'Pushes you to click a link without context', weight: 1 },
  { pattern: /delivery|package|customs|clearance fee|shipping update/i, label: 'Fake delivery / customs fee scam', weight: 2 },
  { pattern: /otp|verification code|pin|password.*share|send.*code/i, label: 'Tries to steal a verification code or password', weight: 3 },
  { pattern: /job offer|work from home|earn \$|per week|hiring now|easy money/i, label: 'Fake job offer or money-making scheme', weight: 2 },
  { pattern: /dear customer|dear user|valued customer|dear sir/i, label: 'Generic greeting — real companies use your name', weight: 1 },
  { pattern: /\+\d{6,}|00\d{6,}/i, label: 'Directs to an international premium-rate number', weight: 2 },
]

export default function ScamDetectorPage() {
  const [text, setText] = useState('')
  const [loading, setLoading] = useState(false)
  const [result, setResult] = useState<ScanResult | null>(null)

  const scan = async () => {
    if (!text.trim()) return
    setLoading(true)
    setResult(null)
    await new Promise(r => setTimeout(r, 2000))

    const matched = scamSignals.filter(s => s.pattern.test(text))
    const score = matched.reduce((sum, s) => sum + s.weight, 0)

    const res: ScanResult =
      score >= 8
        ? {
            verdict: 'dangerous',
            summary: 'This is almost certainly a scam. Do not respond, click any links, or send any money or information.',
            details: [
              ...matched.map(s => `• ${s.label}`),
              '',
              `Risk score: ${score} / 24 — very high`,
              'Recommendation: Block the sender and report as spam',
              `Confidence: ${Math.min(98, 80 + score)}%`,
            ],
            confidence: Math.min(98, 80 + score),
          }
        : score >= 3
        ? {
            verdict: 'suspicious',
            summary: 'This message has several scam indicators. Be cautious — do not share personal info or click links.',
            details: [
              ...matched.map(s => `• ${s.label}`),
              '',
              `Risk score: ${score} / 24 — moderate`,
              'Recommendation: Verify through official channels before acting',
              `Confidence: ${70 + score}%`,
            ],
            confidence: 70 + score,
          }
        : {
            verdict: 'safe',
            summary: 'No significant scam indicators detected. This message appears legitimate.',
            details: [
              'No urgency tactics found',
              'No fake prize or payment requests',
              'No suspicious shortened links',
              `Confidence: 90%`,
            ],
            confidence: 90,
          }

    setResult(res)
    setLoading(false)
    saveScan({ scanType: 'scam', input: text.slice(0, 200), ...res })
  }

  return (
    <>
      <ScannerHero feature={feature} />
      <div className="fade-in-up" style={{ animationDelay: '100ms' }}>
        <div style={{ position: 'relative', marginBottom: 14 }}>
          <MessageSquare size={20} color="var(--text-2)" style={{ position: 'absolute', left: 16, top: 18 }} />
          <textarea
            className="input-field"
            style={{ paddingLeft: 46, minHeight: 160 }}
            placeholder="Paste any message, email, or offer to check for scams…"
            value={text}
            onChange={(e) => setText(e.target.value)}
          />
        </div>
        <button className="btn-primary" onClick={scan} disabled={loading}>
          <Scan size={18} /> {loading ? 'Analyzing…' : 'Detect Scam'}
        </button>
      </div>
      <div style={{ marginTop: 24 }}>
        {loading && <ScanResultSkeleton />}
        {result && <ScanResultCard verdict={result.verdict} summary={result.summary} details={result.details} />}
      </div>
    </>
  )
}
