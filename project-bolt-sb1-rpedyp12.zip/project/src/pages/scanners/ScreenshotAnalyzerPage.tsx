import { useState, useRef } from 'react'
import { ScanLine, Scan, X, Upload, AlertCircle, ImageIcon } from 'lucide-react'
import { features } from '../../data/appData'
import { ScannerHero } from '../../components/ScannerHero'
import { ScanResultCard } from '../../components/ScanResultCard'
import { ScanResultSkeleton } from '../../components/Shimmer'
import { saveScan, type ScanResult } from '../../lib/scanApi'

const feature = features.find(f => f.id === 'screenshot')!

const ACCEPTED = 'image/png,image/jpeg,image/jpg,image/webp'
const MAX_SIZE = 10 * 1024 * 1024

const screenshotTypes = [
  { keywords: ['payment', 'transfer', 'transaction', 'receipt', 'paid', 'utr', 'upi'], label: 'Fake payment screenshot', weight: 3 },
  { keywords: ['job', 'offer', 'hiring', 'salary', 'recruit', 'apply', 'position'], label: 'Fake job offer', weight: 3 },
  { keywords: ['lottery', 'winner', 'prize', 'claim', 'congratulations', 'lucky'], label: 'Fake lottery / prize message', weight: 3 },
  { keywords: ['otp', 'verification', 'code', 'verify', 'confirm'], label: 'OTP / credential phishing chat', weight: 3 },
  { keywords: ['bank', 'account', 'suspended', 'blocked', 'kyc', 'verify'], label: 'Bank impersonation chat', weight: 2 },
  { keywords: ['invest', 'crypto', 'bitcoin', 'double', 'return', 'profit'], label: 'Investment scam chat', weight: 3 },
]

export default function ScreenshotAnalyzerPage() {
  const [loading, setLoading] = useState(false)
  const [result, setResult] = useState<ScanResult | null>(null)
  const [fileName, setFileName] = useState<string | null>(null)
  const [preview, setPreview] = useState<string | null>(null)
  const [error, setError] = useState<string | null>(null)
  const fileInputRef = useRef<HTMLInputElement>(null)

  const onFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (!file) return
    const ext = file.name.split('.').pop()?.toLowerCase() ?? ''
    const typeOk = ['png', 'jpg', 'jpeg', 'webp'].includes(ext) || file.type.startsWith('image/')
    if (!typeOk) {
      setError('Unsupported format. Please select a PNG, JPG, or WebP image.')
      return
    }
    if (file.size > MAX_SIZE) {
      setError('Image is too large. Maximum size is 10MB.')
      return
    }
    setError(null)
    setFileName(file.name)
    setResult(null)
    const reader = new FileReader()
    reader.onload = () => setPreview(reader.result as string)
    reader.readAsDataURL(file)
  }

  const clearFile = () => {
    setFileName(null)
    setPreview(null)
    setResult(null)
    setError(null)
    if (fileInputRef.current) fileInputRef.current.value = ''
  }

  const analyzeImage = (dataUrl: string): Promise<ScanResult> => {
    return new Promise((resolve) => {
      const img = new Image()
      img.onload = () => {
        const canvas = document.createElement('canvas')
        const maxDim = 256
        const scale = Math.min(maxDim / img.width, maxDim / img.height, 1)
        canvas.width = Math.max(1, Math.round(img.width * scale))
        canvas.height = Math.max(1, Math.round(img.height * scale))
        const ctx = canvas.getContext('2d')!
        ctx.drawImage(img, 0, 0, canvas.width, canvas.height)
        const { data } = ctx.getImageData(0, 0, canvas.width, canvas.height)

        let brightSum = 0
        const pixels = data.length / 4
        const lumas: number[] = []
        for (let i = 0; i < data.length; i += 4) {
          const luma = 0.299 * data[i] + 0.587 * data[i + 1] + 0.114 * data[i + 2]
          lumas.push(luma)
          brightSum += luma
        }
        const avgBright = brightSum / pixels

        let edgeSum = 0
        let edgeCount = 0
        const w = canvas.width
        for (let y = 1; y < canvas.height - 1; y++) {
          for (let x = 1; x < w - 1; x++) {
            const idx = y * w + x
            const gx = lumas[idx + 1] - lumas[idx - 1]
            const gy = lumas[idx + w] - lumas[idx - w]
            edgeSum += Math.sqrt(gx * gx + gy * gy)
            edgeCount++
          }
        }
        const edgeStrength = edgeCount > 0 ? edgeSum / edgeCount : 0

        const fileNameLower = (fileName ?? '').toLowerCase()
        const detectedTypes = screenshotTypes.filter(t =>
          t.keywords.some(k => fileNameLower.includes(k))
        )

        const details: string[] = []
        let score = 0

        if (detectedTypes.length > 0) {
          detectedTypes.forEach(t => {
            details.push(`Detected: ${t.label}`)
            score += t.weight
          })
        }

        details.push(`Image dimensions: ${img.width} × ${img.height} px`)
        details.push(`Average brightness: ${avgBright.toFixed(1)} / 255`)
        details.push(`Edge density: ${edgeStrength.toFixed(2)}`)

        if (edgeStrength > 40) {
          details.push('High text density detected — common in screenshot scams')
          score += 1
        }
        if (avgBright > 200) {
          details.push('Very bright background — consistent with messaging app screenshots')
          score += 1
        }

        const res: ScanResult =
          score >= 6
            ? {
                verdict: 'dangerous',
                summary: 'This screenshot shows strong indicators of being a scam. Do not trust or act on its contents.',
                details: [...details, '', `Confidence: ${Math.min(97, 80 + score)}%`],
                confidence: Math.min(97, 80 + score),
              }
            : score >= 3
            ? {
                verdict: 'suspicious',
                summary: 'This screenshot has some suspicious characteristics. Verify the information through official channels before acting.',
                details: [...details, '', `Confidence: ${72 + score}%`],
                confidence: 72 + score,
              }
            : {
                verdict: 'safe',
                summary: 'No significant scam indicators detected in this screenshot.',
                details: [...details, '', 'Confidence: 88%'],
                confidence: 88,
              }

        resolve(res)
      }
      img.onerror = () => resolve({
        verdict: 'suspicious',
        summary: 'Could not fully analyze this screenshot. Proceed with caution.',
        details: ['Image data could not be read for analysis'],
        confidence: 60,
      })
      img.src = dataUrl
    })
  }

  const scan = async () => {
    if (!fileName || !preview) {
      setError('Please select a screenshot first.')
      return
    }
    setLoading(true)
    setResult(null)
    const res = await analyzeImage(preview)
    setResult(res)
    setLoading(false)
    saveScan({ scanType: 'screenshot', input: fileName, ...res })
  }

  return (
    <>
      <ScannerHero feature={feature} />
      <div className="fade-in-up" style={{ animationDelay: '100ms' }}>
        <input
          ref={fileInputRef}
          type="file"
          accept={ACCEPTED}
          onChange={onFileChange}
          style={{ position: 'absolute', width: 1, height: 1, opacity: 0, left: -9999, top: -9999 }}
        />

        {!preview && (
          <div className="upload-zone" onClick={() => fileInputRef.current?.click()}>
            <Upload size={32} color="var(--text-2)" />
            <div style={{ marginTop: 12, fontSize: 15, fontWeight: 600 }}>Upload a screenshot</div>
            <div style={{ fontSize: 13, color: 'var(--text-2)', marginTop: 4 }}>PNG, JPG, WebP up to 10MB</div>
            <div style={{ fontSize: 12, color: 'var(--text-2)', marginTop: 8, lineHeight: 1.5 }}>
              AI detects fake payments, job offers, lottery messages & scam chats
            </div>
          </div>
        )}

        {preview && (
          <div className="fade-in" style={{ position: 'relative', borderRadius: 16, overflow: 'hidden', border: '1px solid var(--outline)' }}>
            <img src={preview} alt="screenshot" style={{ width: '100%', maxHeight: 320, objectFit: 'contain', background: 'var(--surface)' }} />
            <button
              onClick={clearFile}
              style={{ position: 'absolute', top: 8, right: 8, display: 'flex', alignItems: 'center', justifyContent: 'center', width: 32, height: 32, borderRadius: 8, background: 'rgba(0,0,0,0.6)', border: 'none', cursor: 'pointer' }}
            >
              <X size={18} color="#fff" />
            </button>
          </div>
        )}

        {error && (
          <div className="fade-in" style={{ marginTop: 10, fontSize: 13, color: 'var(--error)', padding: '8px 12px', background: 'rgba(248,113,113,0.1)', borderRadius: 8, display: 'flex', gap: 8, alignItems: 'center' }}>
            <AlertCircle size={16} /> {error}
          </div>
        )}

        {fileName && (
          <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginTop: 12, padding: '12px 14px', background: 'var(--surface)', borderRadius: 12, border: '1px solid var(--outline)' }} className="fade-in">
            <ImageIcon size={20} color="var(--blue-light)" />
            <span style={{ fontSize: 14, flex: 1, whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>{fileName}</span>
          </div>
        )}

        {preview && (
          <button className="btn-primary" style={{ marginTop: 14 }} onClick={scan} disabled={loading}>
            <Scan size={18} /> {loading ? 'Analyzing…' : 'Analyze Screenshot'}
          </button>
        )}
      </div>
      <div style={{ marginTop: 24 }}>
        {loading && <ScanResultSkeleton />}
        {result && <ScanResultCard verdict={result.verdict} summary={result.summary} details={result.details} />}
      </div>
    </>
  )
}
