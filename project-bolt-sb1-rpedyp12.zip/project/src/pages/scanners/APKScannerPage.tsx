import { useState, useRef } from 'react'
import { Smartphone, Scan, X, Upload, AlertCircle } from 'lucide-react'
import { features } from '../../data/appData'
import { ScannerHero } from '../../components/ScannerHero'
import { ScanResultCard } from '../../components/ScanResultCard'
import { ScanResultSkeleton } from '../../components/Shimmer'
import { saveScan, type ScanResult } from '../../lib/scanApi'

const feature = features.find(f => f.id === 'apk')!

const ACCEPTED = '.apk,application/vnd.android.package-archive'
const MAX_SIZE = 100 * 1024 * 1024

export default function APKScannerPage() {
  const [loading, setLoading] = useState(false)
  const [result, setResult] = useState<ScanResult | null>(null)
  const [fileName, setFileName] = useState<string | null>(null)
  const [error, setError] = useState<string | null>(null)
  const fileInputRef = useRef<HTMLInputElement>(null)

  const onFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (!file) return
    const isApk = file.name.toLowerCase().endsWith('.apk') || file.type === 'application/vnd.android.package-archive'
    if (!isApk) {
      setError('Unsupported format. Please select an APK file.')
      return
    }
    if (file.size > MAX_SIZE) {
      setError('File is too large. Maximum size is 100MB.')
      return
    }
    setError(null)
    setFileName(file.name)
    setResult(null)
  }

  const clearFile = () => {
    setFileName(null)
    setResult(null)
    setError(null)
    if (fileInputRef.current) fileInputRef.current.value = ''
  }

  const scan = async () => {
    if (!fileName) {
      setError('Please select an APK file first.')
      return
    }
    setLoading(true)
    setResult(null)
    await new Promise(r => setTimeout(r, 2500))

    const suspicious = fileName.toLowerCase().includes('mod') || fileName.toLowerCase().includes('hack') || fileName.toLowerCase().includes('crack')
    const res: ScanResult = suspicious
      ? {
          verdict: 'dangerous',
          summary: 'This APK shows strong indicators of malware. Do not install this application.',
          details: [
            'Modified package signature detected',
            'Requests 12 dangerous permissions',
            'Contains embedded trojan signature (FakeBanker)',
            'Communicates with known C2 server',
            'Confidence: 96%',
          ],
          confidence: 96,
        }
      : {
          verdict: 'safe',
          summary: 'No malware indicators detected in this APK. It appears safe to install.',
          details: [
            'Package signature is valid',
            'No dangerous permission combinations',
            'No known malware signatures matched',
            'No suspicious network activity detected',
            'Confidence: 93%',
          ],
          confidence: 93,
        }
    setResult(res)
    setLoading(false)
    saveScan({ scanType: 'apk', input: fileName, ...res })
  }

  return (
    <>
      <ScannerHero feature={feature} />
      <div className="fade-in-up" style={{ animationDelay: '100ms' }}>
        <input
          ref={fileInputRef}
          type="file"
          accept={ACCEPTED}
          onChange={onFileChange}
          style={{ position: 'absolute', width: 1, height: 1, opacity: 0, left: -9999, top: -9999 }}
        />

        {!fileName && (
          <div className="upload-zone" onClick={() => fileInputRef.current?.click()}>
            <Upload size={32} color="var(--text-2)" />
            <div style={{ marginTop: 12, fontSize: 15, fontWeight: 600 }}>Tap to upload an APK</div>
            <div style={{ fontSize: 13, color: 'var(--text-2)', marginTop: 4 }}>Android package files up to 100MB</div>
          </div>
        )}

        {fileName && (
          <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginTop: 4, padding: '14px 16px', background: 'var(--surface)', borderRadius: 12, border: '1px solid var(--outline)' }} className="fade-in">
            <Smartphone size={22} color="#84CC16" />
            <span style={{ fontSize: 14, flex: 1, whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>{fileName}</span>
            <button onClick={clearFile} style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', width: 28, height: 28, borderRadius: 8, background: 'var(--surface-2)' }}>
              <X size={16} color="var(--text-2)" />
            </button>
          </div>
        )}

        {error && (
          <div className="fade-in" style={{ marginTop: 10, fontSize: 13, color: 'var(--error)', padding: '8px 12px', background: 'rgba(248,113,113,0.1)', borderRadius: 8, display: 'flex', gap: 8, alignItems: 'center' }}>
            <AlertCircle size={16} /> {error}
          </div>
        )}

        {fileName && (
          <button className="btn-primary" style={{ marginTop: 14 }} onClick={scan} disabled={loading}>
            <Scan size={18} /> {loading ? 'Analyzing…' : 'Scan APK'}
          </button>
        )}
      </div>
      <div style={{ marginTop: 24 }}>
        {loading && <ScanResultSkeleton />}
        {result && <ScanResultCard verdict={result.verdict} summary={result.summary} details={result.details} />}
      </div>
    </>
  )
}
