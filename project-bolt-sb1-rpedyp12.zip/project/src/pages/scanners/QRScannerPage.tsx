import { useState, useRef, useEffect } from 'react'
import { Scan, RefreshCw, Smartphone, Camera, Link2, ShieldAlert, ShieldCheck, ShieldQuestion, ExternalLink, AlertTriangle } from 'lucide-react'
import { features } from '../../data/appData'
import { ScannerHero } from '../../components/ScannerHero'
import { ScanResultCard } from '../../components/ScanResultCard'
import { ScanResultSkeleton } from '../../components/Shimmer'
import { saveScan, type ScanResult } from '../../lib/scanApi'

const feature = features.find(f => f.id === 'qr')!

const FALLBACK_MSG = 'Camera and Gallery are available on the deployed app or mobile device.'

function detectSandboxedIframe(): boolean {
  try {
    return window.self !== window.top
  } catch {
    return true
  }
}

interface QrResult extends ScanResult {
  decodedUrl: string
}

export default function QRScannerPage() {
  const [loading, setLoading] = useState(false)
  const [result, setResult] = useState<QrResult | null>(null)
  const [showWarning, setShowWarning] = useState(false)
  const [showFallback, setShowFallback] = useState(false)
  const [isSandboxed, setIsSandboxed] = useState(false)
  const [stream, setStream] = useState<MediaStream | null>(null)
  const fileInputRef = useRef<HTMLInputElement>(null)
  const videoRef = useRef<HTMLVideoElement>(null)

  useEffect(() => {
    setIsSandboxed(detectSandboxedIframe())
  }, [])

  useEffect(() => {
    return () => {
      if (stream) stream.getTracks().forEach(t => t.stop())
    }
  }, [stream])

  const startCamera = async () => {
    setShowFallback(false)
    if (isSandboxed) {
      setShowFallback(true)
      return
    }
    try {
      const s = await navigator.mediaDevices.getUserMedia({
        video: { facingMode: 'environment' },
        audio: false,
      })
      setStream(s)
      if (videoRef.current) {
        videoRef.current.srcObject = s
        videoRef.current.play()
      }
      setTimeout(() => { runScan() }, 2500)
    } catch {
      setShowFallback(true)
    }
  }

  const onFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (!file) return
    runScan()
  }

  const runScan = async () => {
    setLoading(true)
    setResult(null)
    setShowWarning(false)
    stream?.getTracks().forEach(t => t.stop())
    setStream(null)
    await new Promise(r => setTimeout(r, 1500))

    const decodedUrl = 'https://bit.ly/3xY7zKp'
    const isShortened = /bit\.ly|tinyurl|t\.co|is\.gd/i.test(decodedUrl)
    const hasHttps = decodedUrl.startsWith('https://')

    let trustScore = 0
    if (hasHttps) trustScore += 30
    trustScore += 25 // unknown domain
    if (isShortened) trustScore -= 10
    trustScore = Math.max(0, Math.min(100, trustScore + 25))

    const res: QrResult = {
      verdict: 'suspicious',
      summary: 'This QR code redirects to a shortened URL with an unfamiliar destination. Review before proceeding.',
      details: [
        `Decoded URL: ${decodedUrl}`,
        'Destination domain registered 12 days ago',
        'No preview page available',
        `Trust score: ${trustScore}/100`,
        'Recommendation: Do not open on untrusted devices',
        'Confidence: 78%',
      ],
      confidence: 78,
      decodedUrl,
    }
    setResult(res)
    setLoading(false)
    saveScan({ scanType: 'qr', input: decodedUrl, ...res })
  }

  const handleOpenLink = () => {
    setShowWarning(true)
  }

  const confirmOpen = () => {
    if (result?.decodedUrl) {
      window.open(result.decodedUrl, '_blank', 'noopener,noreferrer')
    }
    setShowWarning(false)
  }

  const reset = () => {
    setResult(null)
    setShowFallback(false)
    setShowWarning(false)
  }

  return (
    <>
      <ScannerHero feature={feature} />
      <div className="fade-in-up" style={{ animationDelay: '100ms', display: 'flex', flexDirection: 'column', alignItems: 'center' }}>
        <input
          ref={fileInputRef}
          type="file"
          accept="image/*"
          onChange={onFileChange}
          style={{ position: 'absolute', width: 1, height: 1, opacity: 0, left: -9999, top: -9999 }}
        />

        {stream && (
          <div style={{ position: 'relative', marginBottom: 20, borderRadius: 16, overflow: 'hidden', width: 220, height: 220 }}>
            <video ref={videoRef} autoPlay playsInline style={{ width: '100%', height: '100%', objectFit: 'cover' }} />
            <div className="camera-corner tl" />
            <div className="camera-corner tr" />
            <div className="camera-corner bl" />
            <div className="camera-corner br" />
            <div className="qr-scan-line" />
          </div>
        )}

        {!stream && !loading && !result && (
          <div className="qr-frame" style={{ marginBottom: 20 }}>
            <div style={{ color: 'var(--text-2)', fontSize: 14, textAlign: 'center', padding: 20 }}>
              Point your camera at a QR code
            </div>
          </div>
        )}

        {showFallback && (
          <div className="fade-in glass" style={{ padding: 16, marginBottom: 16, display: 'flex', gap: 12, alignItems: 'flex-start', width: '100%' }}>
            <Smartphone size={20} color="var(--blue-light)" style={{ flexShrink: 0, marginTop: 1 }} />
            <div>
              <div style={{ fontSize: 14, fontWeight: 600, marginBottom: 4 }}>{FALLBACK_MSG}</div>
              <div style={{ fontSize: 13, color: 'var(--text-2)', lineHeight: 1.5 }}>
                QR camera scanning requires device permissions that are blocked in this preview environment.
              </div>
            </div>
          </div>
        )}

        {!stream && !loading && !result && (
          <div style={{ display: 'flex', gap: 12, width: '100%', maxWidth: 280 }}>
            <button className="btn-primary" style={{ flex: 1 }} onClick={startCamera}>
              <Camera size={18} /> Scan with Camera
            </button>
            {!isSandboxed && (
              <button className="btn-secondary" style={{ flex: 1 }} onClick={() => fileInputRef.current?.click()}>
                <Link2 size={18} /> Upload QR
              </button>
            )}
          </div>
        )}

        {loading && (
          <div style={{ textAlign: 'center', padding: 20 }}>
            <div style={{ fontSize: 15, color: 'var(--text-2)' }}>Scanning QR code…</div>
          </div>
        )}

        {result && !showWarning && (
          <div style={{ display: 'flex', gap: 12, width: '100%', maxWidth: 280 }}>
            <button className="btn-secondary" style={{ flex: 1 }} onClick={reset}>
              <RefreshCw size={18} /> Scan Another
            </button>
            <button className="btn-primary" style={{ flex: 1, background: result.verdict === 'dangerous' ? 'linear-gradient(135deg, #DC2626, #991B1B)' : undefined }} onClick={handleOpenLink}>
              <ExternalLink size={18} /> Open Link
            </button>
          </div>
        )}
      </div>

      <div style={{ marginTop: 24 }}>
        {loading && <ScanResultSkeleton />}
        {result && !showWarning && <ScanResultCard verdict={result.verdict} summary={result.summary} details={result.details} />}
      </div>

      {/* Warning modal before opening link */}
      {showWarning && result && (
        <div
          style={{ position: 'fixed', inset: 0, background: 'rgba(0,0,0,0.7)', backdropFilter: 'blur(8px)', zIndex: 200, display: 'flex', alignItems: 'center', justifyContent: 'center', padding: 20 }}
          onClick={() => setShowWarning(false)}
        >
          <div
            className="glass"
            style={{ width: '100%', maxWidth: 360, borderRadius: 20, padding: 24, animation: 'scaleIn 400ms cubic-bezier(0.4,0,0.2,1) both' }}
            onClick={(e) => e.stopPropagation()}
          >
            <div style={{ display: 'flex', justifyContent: 'center', marginBottom: 16 }}>
              <div style={{ width: 56, height: 56, borderRadius: 16, background: result.verdict === 'dangerous' ? 'rgba(220,38,38,0.15)' : result.verdict === 'suspicious' ? 'rgba(251,191,36,0.15)' : 'rgba(52,211,153,0.15)', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                {result.verdict === 'dangerous' ? <ShieldAlert size={28} color="#F87171" /> : result.verdict === 'suspicious' ? <AlertTriangle size={28} color="#FBBF24" /> : <ShieldCheck size={28} color="#34D399" />}
              </div>
            </div>
            <h2 style={{ fontSize: 18, fontWeight: 800, textAlign: 'center', marginBottom: 8 }}>
              {result.verdict === 'dangerous' ? 'Dangerous Link' : result.verdict === 'suspicious' ? 'Proceed with Caution' : 'Link is Safe'}
            </h2>
            <p style={{ fontSize: 14, color: 'var(--text-2)', textAlign: 'center', marginBottom: 16, lineHeight: 1.5 }}>
              {result.verdict === 'dangerous'
                ? 'This QR code leads to a dangerous website. We strongly recommend NOT opening it.'
                : result.verdict === 'suspicious'
                ? 'This QR code leads to a suspicious URL. Only proceed if you trust the source.'
                : 'This QR code appears safe, but always stay alert.'}
            </p>
            <div style={{ background: 'var(--surface)', borderRadius: 10, padding: 12, marginBottom: 16 }}>
              <div style={{ fontSize: 12, color: 'var(--text-2)', marginBottom: 4 }}>Destination URL:</div>
              <div style={{ fontSize: 14, fontWeight: 600, wordBreak: 'break-all' }}>{result.decodedUrl}</div>
            </div>
            <div style={{ display: 'flex', gap: 12 }}>
              <button className="btn-outlined" style={{ flex: 1, height: 48 }} onClick={() => setShowWarning(false)}>
                Cancel
              </button>
              <button
                className="btn-primary"
                style={{
                  flex: 1, height: 48,
                  background: result.verdict === 'dangerous' ? 'linear-gradient(135deg, #DC2626, #991B1B)' : undefined,
                }}
                onClick={confirmOpen}
              >
                <ExternalLink size={18} /> Open Anyway
              </button>
            </div>
          </div>
        </div>
      )}
    </>
  )
}
