import { useState } from 'react'
import { Link2, Scan, ShieldCheck, ShieldAlert, ShieldQuestion, Globe, Lock, AlertTriangle, CheckCircle2 } from 'lucide-react'
import { features } from '../../data/appData'
import { ScannerHero } from '../../components/ScannerHero'
import { ScanResultCard } from '../../components/ScanResultCard'
import { ScanResultSkeleton } from '../../components/Shimmer'
import { saveScan, type ScanResult } from '../../lib/scanApi'

const feature = features.find(f => f.id === 'link')!

interface TrustFactor {
  label: string
  passed: boolean
  weight: number
  explanation: string
}

function analyzeUrl(url: string): { score: number; factors: TrustFactor[]; verdict: 'safe' | 'suspicious' | 'dangerous'; summary: string } {
  let urlLower = url.toLowerCase().trim()
  if (!urlLower.startsWith('http')) urlLower = 'https://' + urlLower

  const factors: TrustFactor[] = []

  // HTTPS check
  const hasHttps = urlLower.startsWith('https://')
  factors.push({
    label: 'HTTPS encryption',
    passed: hasHttps,
    weight: 15,
    explanation: hasHttps ? 'The site uses encrypted HTTPS connection.' : 'No HTTPS — your data could be intercepted. Avoid entering personal info.',
  })

  // Known safe domains
  const safeDomains = /github\.com|google\.com|wikipedia\.org|apple\.com|microsoft\.com|amazon\.com|youtube\.com/i.test(urlLower)
  factors.push({
    label: 'Domain reputation',
    passed: safeDomains,
    weight: 25,
    explanation: safeDomains ? 'This is a well-known, established domain.' : 'This domain is not in the trusted registry — limited reputation data.',
  })

  // Phishing keywords
  const phishingKeywords = /secure|login|verify|account|update|confirm|amaz0n|paypa|g00gle|app1e/i.test(urlLower)
  factors.push({
    label: 'Phishing indicators',
    passed: !phishingKeywords,
    weight: 25,
    explanation: phishingKeywords ? 'URL contains common phishing keywords and impersonation patterns.' : 'No phishing keywords or brand impersonation detected.',
  })

  // Lookalike characters
  const lookalike = /0|1|rn|vv|l1/i.test(urlLower.split('//')[1] ?? '')
  factors.push({
    label: 'Domain authenticity',
    passed: !lookalike,
    weight: 15,
    explanation: lookalike ? 'Domain may use lookalike characters to impersonate a real brand.' : 'Domain appears to use authentic characters.',
  })

  // Shortened URL
  const shortened = /bit\.ly|tinyurl|t\.co|is\.gd|shorturl|buff\.ly|rebrand\.ly/i.test(urlLower)
  factors.push({
    label: 'URL transparency',
    passed: !shortened,
    weight: 10,
    explanation: shortened ? 'This is a shortened URL — the real destination is hidden. Expand before clicking.' : 'URL is not shortened — destination is visible.',
  })

  // IP address instead of domain
  const isIp = /\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}/.test(urlLower)
  factors.push({
    label: 'Domain format',
    passed: !isIp,
    weight: 10,
    explanation: isIp ? 'Uses a raw IP address instead of a domain name — common in phishing.' : 'Uses a proper domain name.',
  })

  const score = factors.reduce((sum, f) => sum + (f.passed ? f.weight : 0), 0)

  let verdict: 'safe' | 'suspicious' | 'dangerous'
  let summary: string
  if (score >= 75) {
    verdict = 'safe'
    summary = `Trust Score: ${score}/100. This website appears legitimate and safe to visit.`
  } else if (score >= 45) {
    verdict = 'suspicious'
    summary = `Trust Score: ${score}/100. This website has some risk indicators. Proceed with caution.`
  } else {
    verdict = 'dangerous'
    summary = `Trust Score: ${score}/100. This website is high-risk. Do not enter personal information or click links.`
  }

  return { score, factors, verdict, summary }
}

export default function LinkCheckerPage() {
  const [url, setUrl] = useState('')
  const [loading, setLoading] = useState(false)
  const [result, setResult] = useState<ScanResult | null>(null)
  const [trustScore, setTrustScore] = useState<number | null>(null)
  const [factors, setFactors] = useState<TrustFactor[]>([])

  const scan = async () => {
    if (!url.trim()) return
    setLoading(true)
    setResult(null)
    setTrustScore(null)
    setFactors([])
    await new Promise(r => setTimeout(r, 1800))

    const analysis = analyzeUrl(url)
    setTrustScore(analysis.score)
    setFactors(analysis.factors)

    const res: ScanResult = {
      verdict: analysis.verdict,
      summary: analysis.summary,
      details: analysis.factors.map(f => `${f.passed ? '✓' : '✗'} ${f.label}: ${f.explanation}`).concat([`Confidence: ${analysis.score}%`]),
      confidence: analysis.score,
    }
    setResult(res)
    setLoading(false)
    saveScan({ scanType: 'link', input: url, ...res })
  }

  const scoreColor = trustScore === null ? 'var(--text-2)' : trustScore >= 75 ? '#34D399' : trustScore >= 45 ? '#FBBF24' : '#F87171'
  const scoreLabel = trustScore === null ? '' : trustScore >= 75 ? 'Safe' : trustScore >= 45 ? 'Caution' : 'Dangerous'
  const ScoreIcon = trustScore === null ? null : trustScore >= 75 ? ShieldCheck : trustScore >= 45 ? ShieldQuestion : ShieldAlert

  return (
    <>
      <ScannerHero feature={feature} />
      <div className="fade-in-up" style={{ animationDelay: '100ms' }}>
        <div style={{ position: 'relative', marginBottom: 14 }}>
          <Link2 size={20} color="var(--text-2)" style={{ position: 'absolute', left: 16, top: 18 }} />
          <input className="input-field" style={{ paddingLeft: 46 }} placeholder="Paste a URL to check…" value={url} onChange={(e) => setUrl(e.target.value)} onKeyDown={(e) => e.key === 'Enter' && scan()} />
        </div>
        <button className="btn-primary" onClick={scan} disabled={loading}>
          <Scan size={18} /> {loading ? 'Analyzing…' : 'Check Trust Score'}
        </button>
      </div>

      {/* Trust Score Gauge */}
      {trustScore !== null && (
        <div className="glass fade-in-up trust-score-card" style={{ marginTop: 20, animationDelay: '100ms' }}>
          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 8, marginBottom: 8 }}>
            {ScoreIcon && <ScoreIcon size={28} color={scoreColor} />}
            <span className="trust-score-num count-up" style={{ color: scoreColor }}>{trustScore}</span>
            <span style={{ fontSize: 18, color: 'var(--text-2)', fontWeight: 600 }}>/ 100</span>
          </div>
          <div className="trust-score-label" style={{ color: scoreColor }}>{scoreLabel}</div>
          <div className="trust-bar-track">
            <div className="trust-bar-fill" style={{ width: `${trustScore}%`, background: scoreColor }} />
          </div>
        </div>
      )}

      {/* Risk Factors */}
      {factors.length > 0 && (
        <div style={{ marginTop: 16 }}>
          <div className="section-label">Risk Breakdown</div>
          {factors.map((f, i) => (
            <div key={i} className="glass fade-in-up" style={{ padding: 14, marginBottom: 8, display: 'flex', gap: 12, alignItems: 'flex-start', animationDelay: `${i * 50}ms` }}>
              {f.passed ? (
                <CheckCircle2 size={20} color="#34D399" style={{ flexShrink: 0, marginTop: 1 }} />
              ) : (
                <AlertTriangle size={20} color="#F87171" style={{ flexShrink: 0, marginTop: 1 }} />
              )}
              <div>
                <div style={{ fontSize: 14, fontWeight: 600, marginBottom: 2 }}>{f.label}</div>
                <div style={{ fontSize: 13, color: 'var(--text-2)', lineHeight: 1.5 }}>{f.explanation}</div>
              </div>
            </div>
          ))}
        </div>
      )}

      <div style={{ marginTop: 24 }}>
        {loading && <ScanResultSkeleton />}
        {result && <ScanResultCard verdict={result.verdict} summary={result.summary} details={result.details} />}
      </div>
    </>
  )
}
