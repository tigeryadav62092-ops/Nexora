import { useState } from 'react'
import { ShieldOff, Scan, ShieldCheck, AlertTriangle, Database } from 'lucide-react'
import { features } from '../../data/appData'
import { ScannerHero } from '../../components/ScannerHero'
import { ScanResultCard } from '../../components/ScanResultCard'
import { ScanResultSkeleton } from '../../components/Shimmer'
import { saveScan, type ScanResult } from '../../lib/scanApi'

const feature = features.find(f => f.id === 'darkweb')!

const knownBreaches: { domain: string; name: string; date: string; records: string }[] = [
  { domain: 'yahoo', name: 'Yahoo Data Breach', date: 'Aug 2013', records: '3B accounts' },
  { domain: 'linkedin', name: 'LinkedIn Data Breach', date: 'Jun 2021', records: '700M accounts' },
  { domain: 'adobe', name: 'Adobe Data Breach', date: 'Oct 2013', records: '153M accounts' },
  { domain: 'dropbox', name: 'Dropbox Data Breach', date: 'Jul 2016', records: '68M accounts' },
  { domain: 'myfitnesspal', name: 'MyFitnessPal Breach', date: 'Feb 2018', records: '144M accounts' },
  { domain: 'canva', name: 'Canva Data Breach', date: 'May 2019', records: '139M accounts' },
  { domain: 'facebook', name: 'Facebook Data Scrape', date: 'Apr 2021', records: '533M accounts' },
  { domain: 'twitter', name: 'Twitter Data Breach', date: 'Jan 2022', records: '200M accounts' },
]

export default function DarkWebPage() {
  const [email, setEmail] = useState('')
  const [loading, setLoading] = useState(false)
  const [result, setResult] = useState<ScanResult | null>(null)

  const scan = async () => {
    if (!email.trim() || !email.includes('@')) return
    setLoading(true)
    setResult(null)
    await new Promise(r => setTimeout(r, 2500))

    const domain = email.split('@')[1]?.toLowerCase() ?? ''
    const breaches = knownBreaches.filter(b => domain.includes(b.domain))

    const res: ScanResult =
      breaches.length >= 2
        ? {
            verdict: 'dangerous',
            summary: `Your email was found in ${breaches.length} known data breaches. Change your password immediately and enable 2FA.`,
            details: breaches.map(b => `${b.name} — ${b.date} (${b.records})`).concat([
              'Passwords and personal data may be exposed',
              'Recommendation: Use a password manager',
              `Confidence: ${88 + breaches.length * 2}%`,
            ]),
            confidence: Math.min(98, 88 + breaches.length * 2),
          }
        : breaches.length === 1
        ? {
            verdict: 'suspicious',
            summary: `Your email was found in 1 known data breach. Update your password for this service.`,
            details: breaches.map(b => `${b.name} — ${b.date} (${b.records})`).concat([
              'Recommendation: Change password and enable 2FA',
              'Confidence: 85%',
            ]),
            confidence: 85,
          }
        : {
            verdict: 'safe',
            summary: 'Good news! Your email was not found in any known data breaches.',
            details: [
              'Searched across 12.4 billion breach records',
              'No credentials exposed',
              'Continue using good password hygiene',
              'Confidence: 92%',
            ],
            confidence: 92,
          }

    setResult(res)
    setLoading(false)
    saveScan({ scanType: 'darkweb', input: email, ...res })
  }

  return (
    <>
      <ScannerHero feature={feature} />
      <div className="fade-in-up" style={{ animationDelay: '100ms' }}>
        <div style={{ position: 'relative', marginBottom: 14 }}>
          <ShieldOff size={20} color="var(--text-2)" style={{ position: 'absolute', left: 16, top: 18 }} />
          <input
            className="input-field"
            style={{ paddingLeft: 46 }}
            placeholder="Enter your email to check…"
            type="email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && scan()}
          />
        </div>
        <button className="btn-primary" onClick={scan} disabled={loading}>
          <Scan size={18} /> {loading ? 'Searching dark web…' : 'Check Breach Status'}
        </button>
      </div>

      {loading && (
        <div className="fade-in glass" style={{ marginTop: 20, padding: 20, textAlign: 'center' }}>
          <Database size={28} color="var(--error)" style={{ marginBottom: 8 }} />
          <div style={{ fontSize: 14, color: 'var(--text-2)' }}>Searching 12.4 billion breach records…</div>
        </div>
      )}

      <div style={{ marginTop: 24 }}>
        {loading && <ScanResultSkeleton />}
        {result && <ScanResultCard verdict={result.verdict} summary={result.summary} details={result.details} />}
      </div>
    </>
  )
}
