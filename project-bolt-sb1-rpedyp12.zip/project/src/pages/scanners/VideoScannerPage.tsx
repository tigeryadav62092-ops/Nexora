import { useState, useRef } from 'react'
import { Upload, Scan, Video, X, AlertCircle } from 'lucide-react'
import { features } from '../../data/appData'
import { ScannerHero } from '../../components/ScannerHero'
import { ScanResultCard } from '../../components/ScanResultCard'
import { ScanResultSkeleton } from '../../components/Shimmer'
import { saveScan, type ScanResult } from '../../lib/scanApi'

const feature = features.find(f => f.id === 'video')!

const ACCEPTED = 'video/mp4,video/quicktime,video/webm'
const MAX_SIZE = 50 * 1024 * 1024

export default function VideoScannerPage() {
  const [loading, setLoading] = useState(false)
  const [result, setResult] = useState<ScanResult | null>(null)
  const [fileName, setFileName] = useState<string | null>(null)
  const [preview, setPreview] = useState<string | null>(null)
  const [error, setError] = useState<string | null>(null)
  const fileInputRef = useRef<HTMLInputElement>(null)
  const objectUrlRef = useRef<string | null>(null)

  const pickFile = () => {
    setError(null)
    fileInputRef.current?.click()
  }

  const onFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (!file) return
    if (!['video/mp4', 'video/quicktime', 'video/webm'].includes(file.type)) {
      setError('Unsupported format. Please select an MP4, MOV, or WebM video.')
      return
    }
    if (file.size > MAX_SIZE) {
      setError('Video is too large. Maximum size is 50MB.')
      return
    }
    setError(null)
    setFileName(file.name)
    setResult(null)
    if (objectUrlRef.current) URL.revokeObjectURL(objectUrlRef.current)
    const url = URL.createObjectURL(file)
    objectUrlRef.current = url
    setPreview(url)
  }

  const clearFile = () => {
    setFileName(null)
    setPreview(null)
    setResult(null)
    setError(null)
    if (objectUrlRef.current) { URL.revokeObjectURL(objectUrlRef.current); objectUrlRef.current = null }
    if (fileInputRef.current) fileInputRef.current.value = ''
  }

  const scan = async () => {
    if (!fileName) {
      setError('Please select a video first.')
      return
    }
    setLoading(true)
    setResult(null)
    await new Promise(r => setTimeout(r, 2200))
    const res: ScanResult = {
      verdict: 'dangerous',
      summary: 'Deepfake indicators found. This video likely contains synthetic content.',
      details: ['Face swap artifacts at 0:12 and 0:34', 'Audio-visual sync mismatch detected', 'Frame interpolation inconsistencies', 'Confidence: 87%'],
      confidence: 87,
    }
    setResult(res)
    setLoading(false)
    saveScan({ scanType: 'video', input: fileName, ...res })
  }

  return (
    <>
      <ScannerHero feature={feature} />
      <div className="fade-in-up" style={{ animationDelay: '100ms' }}>
        <input
          ref={fileInputRef}
          type="file"
          accept={ACCEPTED}
          onChange={onFileChange}
          style={{ position: 'absolute', width: 1, height: 1, opacity: 0, left: -9999, top: -9999 }}
        />
        <div className="upload-zone" onClick={pickFile}>
          {preview ? (
            <video src={preview} controls style={{ maxWidth: '100%', maxHeight: 220, borderRadius: 12 }} />
          ) : (
            <>
              <Upload size={32} color="var(--text-2)" />
              <div style={{ marginTop: 12, fontSize: 15, fontWeight: 600 }}>Tap to upload a video</div>
              <div style={{ fontSize: 13, color: 'var(--text-2)', marginTop: 4 }}>MP4, MOV, WebM up to 50MB</div>
            </>
          )}
        </div>
        {error && (
          <div className="fade-in" style={{ marginTop: 10, fontSize: 13, color: 'var(--error)', padding: '8px 12px', background: 'rgba(248,113,113,0.1)', borderRadius: 8, display: 'flex', gap: 8, alignItems: 'center' }}>
            <AlertCircle size={16} /> {error}
          </div>
        )}
        {fileName && (
          <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginTop: 12, padding: '12px 14px', background: 'var(--surface)', borderRadius: 12, border: '1px solid var(--outline)' }} className="fade-in">
            <Video size={20} color="var(--blue-light)" />
            <span style={{ fontSize: 14, flex: 1, whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>{fileName}</span>
            <button onClick={clearFile} style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', width: 28, height: 28, borderRadius: 8, background: 'var(--surface-2)' }}>
              <X size={16} color="var(--text-2)" />
            </button>
          </div>
        )}
        {fileName && (
          <button className="btn-primary" style={{ marginTop: 14 }} onClick={scan} disabled={loading}>
            <Scan size={18} /> {loading ? 'Analyzing…' : 'Scan Video'}
          </button>
        )}
      </div>
      <div style={{ marginTop: 24 }}>
        {loading && <ScanResultSkeleton />}
        {result && <ScanResultCard verdict={result.verdict} summary={result.summary} details={result.details} />}
      </div>
    </>
  )
}
