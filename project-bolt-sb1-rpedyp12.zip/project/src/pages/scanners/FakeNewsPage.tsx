import { useState } from 'react'
import { Scan } from 'lucide-react'
import { features } from '../../data/appData'
import { ScannerHero } from '../../components/ScannerHero'
import { ScanResultCard } from '../../components/ScanResultCard'
import { ScanResultSkeleton } from '../../components/Shimmer'
import { saveScan, type ScanResult } from '../../lib/scanApi'

const feature = features.find(f => f.id === 'news')!

export default function FakeNewsPage() {
  const [text, setText] = useState('')
  const [loading, setLoading] = useState(false)
  const [result, setResult] = useState<ScanResult | null>(null)

  const scan = async () => {
    if (!text.trim()) return
    setLoading(true)
    setResult(null)
    await new Promise(r => setTimeout(r, 1800))
    const suspicious = /cures|miracle|breaking|shocking|they don't want you/i.test(text)
    const res: ScanResult = suspicious
      ? { verdict: 'suspicious', summary: 'This content shows signs of misinformation or sensationalism.', details: ['Uses emotionally charged language', 'No credible sources cited', 'Claims lack peer-reviewed evidence', 'Confidence: 75%'], confidence: 75 }
      : { verdict: 'safe', summary: 'This content appears factual and well-sourced.', details: ['Neutral tone detected', 'Consistent with established sources', 'Confidence: 88%'], confidence: 88 }
    setResult(res)
    setLoading(false)
    saveScan({ scanType: 'news', input: text.slice(0, 200), ...res })
  }

  return (
    <>
      <ScannerHero feature={feature} />
      <div className="fade-in-up" style={{ animationDelay: '100ms' }}>
        <textarea className="input-field" placeholder="Paste a headline or article text to verify…" value={text} onChange={(e) => setText(e.target.value)} />
        <button className="btn-primary" style={{ marginTop: 14 }} onClick={scan} disabled={loading}>
          <Scan size={18} /> {loading ? 'Analyzing…' : 'Verify Content'}
        </button>
      </div>
      <div style={{ marginTop: 24 }}>
        {loading && <ScanResultSkeleton />}
        {result && <ScanResultCard verdict={result.verdict} summary={result.summary} details={result.details} />}
      </div>
    </>
  )
}
