import { useState, useRef, useEffect } from 'react'
import { Camera, Image as GalleryIcon, Scan, ImageIcon, X, AlertCircle, Smartphone } from 'lucide-react'
import { features } from '../../data/appData'
import { ScannerHero } from '../../components/ScannerHero'
import { ScanResultCard } from '../../components/ScanResultCard'
import { ScanResultSkeleton } from '../../components/Shimmer'
import { saveScan, type ScanResult } from '../../lib/scanApi'

const feature = features.find(f => f.id === 'image')!

const ACCEPTED = 'image/jpeg,image/jpg,image/png,image/webp'
const MAX_SIZE = 10 * 1024 * 1024
const VALID_EXTS = ['jpg', 'jpeg', 'png', 'webp']
const FALLBACK_MSG = 'Camera and Gallery are available on the deployed app or mobile device.'

function detectSandboxedIframe(): boolean {
  try {
    // In a cross-origin or sandboxed iframe (Bolt Preview), accessing
    // window.top throws or self !== top.
    return window.self !== window.top
  } catch {
    return true
  }
}

export default function ImageScannerPage() {
  const [loading, setLoading] = useState(false)
  const [result, setResult] = useState<ScanResult | null>(null)
  const [fileName, setFileName] = useState<string | null>(null)
  const [preview, setPreview] = useState<string | null>(null)
  const [error, setError] = useState<string | null>(null)
  const [showFallback, setShowFallback] = useState(false)
  const [isSandboxed, setIsSandboxed] = useState(false)

  const cameraInputRef = useRef<HTMLInputElement>(null)
  const galleryInputRef = useRef<HTMLInputElement>(null)

  useEffect(() => {
    setIsSandboxed(detectSandboxedIframe())
  }, [])

  const handleFile = (file: File) => {
    const ext = file.name.split('.').pop()?.toLowerCase() ?? ''
    const typeOk = VALID_EXTS.includes(ext) || file.type === 'image/jpeg' || file.type === 'image/png' || file.type === 'image/webp'
    if (!typeOk) {
      setError('Unsupported format. Please select a JPG, JPEG, PNG, or WebP image.')
      return
    }
    if (file.size > MAX_SIZE) {
      setError('Image is too large. Maximum size is 10MB.')
      return
    }
    setError(null)
    setShowFallback(false)
    setFileName(file.name)
    setResult(null)
    const reader = new FileReader()
    reader.onload = () => setPreview(reader.result as string)
    reader.readAsDataURL(file)
  }

  const onFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (file) handleFile(file)
    e.target.value = ''
  }

  const openCamera = () => {
    setError(null)
    if (isSandboxed) {
      setShowFallback(true)
      return
    }
    cameraInputRef.current?.click()
  }

  const openGallery = () => {
    setError(null)
    if (isSandboxed) {
      setShowFallback(true)
      return
    }
    galleryInputRef.current?.click()
  }

  const clearFile = () => {
    setFileName(null)
    setPreview(null)
    setResult(null)
    setError(null)
    setShowFallback(false)
    if (cameraInputRef.current) cameraInputRef.current.value = ''
    if (galleryInputRef.current) galleryInputRef.current.value = ''
  }

  const analyzeImage = (dataUrl: string): Promise<ScanResult> => {
    return new Promise((resolve) => {
      const img = new Image()
      img.onload = () => {
        const canvas = document.createElement('canvas')
        const maxDim = 256
        const scale = Math.min(maxDim / img.width, maxDim / img.height, 1)
        canvas.width = Math.max(1, Math.round(img.width * scale))
        canvas.height = Math.max(1, Math.round(img.height * scale))
        const ctx = canvas.getContext('2d')!
        ctx.drawImage(img, 0, 0, canvas.width, canvas.height)
        const { data } = ctx.getImageData(0, 0, canvas.width, canvas.height)

        let rSum = 0, gSum = 0, bSum = 0, brightSum = 0, brightSqSum = 0
        const lumas: number[] = []
        const pixels = data.length / 4
        for (let i = 0; i < data.length; i += 4) {
          const r = data[i], g = data[i + 1], b = data[i + 2]
          rSum += r; gSum += g; bSum += b
          const luma = 0.299 * r + 0.587 * g + 0.114 * b
          lumas.push(luma)
          brightSum += luma
          brightSqSum += luma * luma
        }
        const avgBright = brightSum / pixels
        const variance = brightSqSum / pixels - avgBright * avgBright
        const contrast = Math.sqrt(Math.max(0, variance))

        let noiseSum = 0
        let noiseCount = 0
        const w = canvas.width
        for (let y = 0; y < canvas.height - 1; y++) {
          for (let x = 0; x < w - 1; x++) {
            const idx = y * w + x
            noiseSum += Math.abs(lumas[idx] - lumas[idx + 1])
            noiseSum += Math.abs(lumas[idx] - lumas[idx + w])
            noiseCount += 2
          }
        }
        const noiseLevel = noiseCount > 0 ? noiseSum / noiseCount : 0

        let edgeSum = 0
        let edgeCount = 0
        for (let y = 1; y < canvas.height - 1; y++) {
          for (let x = 1; x < w - 1; x++) {
            const idx = y * w + x
            const gx = lumas[idx + 1] - lumas[idx - 1]
            const gy = lumas[idx + w] - lumas[idx - w]
            edgeSum += Math.sqrt(gx * gx + gy * gy)
            edgeCount++
          }
        }
        const edgeStrength = edgeSum / edgeCount

        const avgR = Math.round(rSum / pixels)
        const avgG = Math.round(gSum / pixels)
        const avgB = Math.round(bSum / pixels)

        const details: string[] = [
          `Dimensions: ${img.width} × ${img.height} px`,
          `Average brightness: ${avgBright.toFixed(1)} / 255`,
          `Contrast level: ${contrast.toFixed(1)}`,
          `Noise estimate: ${noiseLevel.toFixed(2)}`,
          `Edge density: ${edgeStrength.toFixed(2)}`,
          `Color balance: RGB(${avgR}, ${avgG}, ${avgB})`,
        ]

        let score = 0
        if (noiseLevel > 12) score += 2
        else if (noiseLevel > 7) score += 1
        if (contrast < 15 || contrast > 90) score += 1
        if (edgeStrength < 8 || edgeStrength > 60) score += 1
        if (Math.abs(avgR - avgG) > 40 || Math.abs(avgG - avgB) > 40) score += 1

        let verdict: 'safe' | 'suspicious' | 'dangerous'
        let summary: string
        if (score >= 4) {
          verdict = 'dangerous'
          summary = 'High probability of manipulation detected. Several anomalies found in pixel-level analysis.'
          details.push('Strong manipulation indicators present')
        } else if (score >= 2) {
          verdict = 'suspicious'
          summary = 'Some unusual patterns detected. We recommend reviewing this image carefully before trusting it.'
          details.push('Moderate anomalies detected — review recommended')
        } else {
          verdict = 'safe'
          summary = 'No significant manipulation indicators found. This image appears authentic.'
          details.push('No anomalies detected in pixel analysis')
        }

        resolve({ verdict, summary, details })
      }
      img.onerror = () => resolve({
        verdict: 'suspicious',
        summary: 'Could not fully analyze this image. Proceed with caution.',
        details: ['Image data could not be read for analysis'],
      })
      img.src = dataUrl
    })
  }

  const scan = async () => {
    if (!fileName || !preview) {
      setError('Please select an image first.')
      return
    }
    setLoading(true)
    setResult(null)
    const res = await analyzeImage(preview)
    setResult(res)
    setLoading(false)
    saveScan({ scanType: 'image', input: fileName, ...res })
  }

  return (
    <>
      <ScannerHero feature={feature} />
      <div className="fade-in-up" style={{ animationDelay: '100ms' }}>
        {/* Hidden file inputs */}
        <input
          ref={cameraInputRef}
          type="file"
          accept={ACCEPTED}
          capture="environment"
          onChange={onFileChange}
          style={{ position: 'absolute', width: 1, height: 1, opacity: 0, overflow: 'hidden', left: -9999, top: -9999 }}
        />
        <input
          ref={galleryInputRef}
          type="file"
          accept={ACCEPTED}
          onChange={onFileChange}
          style={{ position: 'absolute', width: 1, height: 1, opacity: 0, overflow: 'hidden', left: -9999, top: -9999 }}
        />

        {/* Camera + Gallery buttons — only shown when no image is selected */}
        {!preview && (
          <div style={{ display: 'flex', gap: 12 }}>
            <button
              className="btn-primary"
              style={{ flex: 1, display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 8 }}
              onClick={openCamera}
            >
              <Camera size={18} /> Camera
            </button>
            <button
              className="btn-secondary"
              style={{ flex: 1, display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 8 }}
              onClick={openGallery}
            >
              <GalleryIcon size={18} /> Gallery
            </button>
          </div>
        )}

        {/* Fallback message for sandboxed preview (Bolt Preview) */}
        {showFallback && !preview && (
          <div
            className="fade-in"
            style={{
              marginTop: 14,
              padding: '16px 16px',
              background: 'var(--surface-2)',
              borderRadius: 12,
              border: '1px solid var(--outline)',
              display: 'flex',
              gap: 12,
              alignItems: 'flex-start',
            }}
          >
            <Smartphone size={20} color="var(--blue-light)" style={{ flexShrink: 0, marginTop: 1 }} />
            <div>
              <div style={{ fontSize: 14, fontWeight: 600, color: 'var(--text)', marginBottom: 4 }}>
                {FALLBACK_MSG}
              </div>
              <div style={{ fontSize: 13, color: 'var(--text-2)', lineHeight: 1.5 }}>
                Camera and gallery access requires device permissions that are blocked in this preview environment.
              </div>
            </div>
          </div>
        )}

        {/* Image preview */}
        {preview && (
          <div className="fade-in" style={{ marginTop: 16 }}>
            <div style={{ position: 'relative', borderRadius: 16, overflow: 'hidden', border: '1px solid var(--outline)' }}>
              <img src={preview} alt="preview" style={{ width: '100%', maxHeight: 280, objectFit: 'contain', background: 'var(--surface)' }} />
              <button
                onClick={clearFile}
                style={{
                  position: 'absolute', top: 8, right: 8,
                  display: 'flex', alignItems: 'center', justifyContent: 'center',
                  width: 32, height: 32, borderRadius: 8,
                  background: 'rgba(0,0,0,0.6)', border: 'none', cursor: 'pointer',
                }}
              >
                <X size={18} color="#fff" />
              </button>
            </div>
          </div>
        )}

        {/* Selected file name */}
        {fileName && (
          <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginTop: 12, padding: '12px 14px', background: 'var(--surface)', borderRadius: 12, border: '1px solid var(--outline)' }} className="fade-in">
            <ImageIcon size={20} color="var(--blue-light)" />
            <span style={{ fontSize: 14, flex: 1, whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>{fileName}</span>
          </div>
        )}

        {/* Error message */}
        {error && (
          <div
            className="fade-in"
            style={{
              marginTop: 12,
              fontSize: 14,
              color: 'var(--error)',
              padding: '12px 14px',
              background: 'rgba(248,113,113,0.1)',
              borderRadius: 10,
              display: 'flex',
              gap: 10,
              alignItems: 'flex-start',
              lineHeight: 1.5,
            }}
          >
            <AlertCircle size={18} color="var(--error)" style={{ flexShrink: 0, marginTop: 1 }} />
            <span>{error}</span>
          </div>
        )}

        {/* Scan button — completely separate from upload, only appears after image is selected */}
        {preview && (
          <button className="btn-primary" style={{ marginTop: 14, width: '100%' }} onClick={scan} disabled={loading}>
            <Scan size={18} /> {loading ? 'Analyzing…' : 'Scan Image'}
          </button>
        )}
      </div>
      <div style={{ marginTop: 24 }}>
        {loading && <ScanResultSkeleton />}
        {result && <ScanResultCard verdict={result.verdict} summary={result.summary} details={result.details} />}
      </div>
    </>
  )
}
