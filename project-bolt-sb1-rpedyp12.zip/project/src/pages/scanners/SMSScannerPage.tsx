import { useState } from 'react'
import { MessageSquare, Scan } from 'lucide-react'
import { features } from '../../data/appData'
import { ScannerHero } from '../../components/ScannerHero'
import { ScanResultCard } from '../../components/ScanResultCard'
import { ScanResultSkeleton } from '../../components/Shimmer'
import { saveScan, type ScanResult } from '../../lib/scanApi'

const feature = features.find(f => f.id === 'sms')!

const scamPatterns = [
  { pattern: /urgent|immediately|act now|expires/i, label: 'Urgency pressure tactic' },
  { pattern: /won|winner|prize|lottery|claim now/i, label: 'Prize/lottery scam pattern' },
  { pattern: /bank|account|verify|suspended|locked/i, label: 'Bank account impersonation' },
  { pattern: /bit\.ly|tinyurl|t\.co|shorturl/i, label: 'Shortened URL (hides destination)' },
  { pattern: /click here|tap link|follow link/i, label: 'Suspicious link prompt' },
  { pattern: /delivery|package|customs|fee|pay/i, label: 'Fake delivery fee scam' },
  { pattern: /\+\d{6,}|00\d{6,}/i, label: 'International premium number' },
  { pattern: /otp|code|password|pin.*share|send/i, label: 'Credential harvesting attempt' },
]

export default function SMSScannerPage() {
  const [text, setText] = useState('')
  const [loading, setLoading] = useState(false)
  const [result, setResult] = useState<ScanResult | null>(null)

  const scan = async () => {
    if (!text.trim()) return
    setLoading(true)
    setResult(null)
    await new Promise(r => setTimeout(r, 1800))

    const matched = scamPatterns.filter(p => p.pattern.test(text))
    const score = matched.length

    const res: ScanResult =
      score >= 3
        ? {
            verdict: 'dangerous',
            summary: 'This message is almost certainly a scam. Do not click any links or share any information.',
            details: matched.map(m => m.label).concat([`Confidence: ${Math.min(95, 70 + score * 8)}%`]),
            confidence: Math.min(95, 70 + score * 8),
          }
        : score >= 1
        ? {
            verdict: 'suspicious',
            summary: 'This message shows some scam indicators. Be cautious and do not click links or share personal info.',
            details: matched.map(m => m.label).concat([`Confidence: ${65 + score * 5}%`]),
            confidence: 65 + score * 5,
          }
        : {
            verdict: 'safe',
            summary: 'No scam indicators detected in this message. It appears legitimate.',
            details: ['No urgency tactics', 'No suspicious links', 'No credential requests', 'Confidence: 90%'],
            confidence: 90,
          }

    setResult(res)
    setLoading(false)
    saveScan({ scanType: 'sms', input: text.slice(0, 200), ...res })
  }

  return (
    <>
      <ScannerHero feature={feature} />
      <div className="fade-in-up" style={{ animationDelay: '100ms' }}>
        <div style={{ position: 'relative', marginBottom: 14 }}>
          <MessageSquare size={20} color="var(--text-2)" style={{ position: 'absolute', left: 16, top: 18 }} />
          <textarea
            className="input-field"
            style={{ paddingLeft: 46, minHeight: 140 }}
            placeholder="Paste a text message to check for scams…"
            value={text}
            onChange={(e) => setText(e.target.value)}
          />
        </div>
        <button className="btn-primary" onClick={scan} disabled={loading}>
          <Scan size={18} /> {loading ? 'Analyzing…' : 'Scan Message'}
        </button>
      </div>
      <div style={{ marginTop: 24 }}>
        {loading && <ScanResultSkeleton />}
        {result && <ScanResultCard verdict={result.verdict} summary={result.summary} details={result.details} />}
      </div>
    </>
  )
}
