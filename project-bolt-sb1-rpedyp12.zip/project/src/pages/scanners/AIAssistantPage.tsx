import { useState, useRef, useEffect } from 'react'
import { Send, Bot, Shield, Lock, KeyRound, Eye, AlertTriangle, Globe, Smartphone, Zap } from 'lucide-react'
import { features } from '../../data/appData'
import { ScannerHero } from '../../components/ScannerHero'

const feature = features.find(f => f.id === 'ai')!

interface Msg { role: 'user' | 'ai'; text: string }

const suggestions = [
  { icon: Lock, text: 'How do I create a strong password?' },
  { icon: AlertTriangle, text: 'What is phishing and how to spot it?' },
  { icon: KeyRound, text: 'Should I use a password manager?' },
  { icon: Eye, text: 'How to detect deepfake images?' },
  { icon: Globe, text: 'Is this URL safe to click?' },
  { icon: Smartphone, text: 'How to secure my phone?' },
]

const aiReply = (q: string): string => {
  const lower = q.toLowerCase()
  if (lower.includes('phish'))
    return 'Phishing is a social engineering attack where attackers impersonate trusted entities (banks, services, colleagues) to steal credentials or personal data.\n\nHow to spot phishing:\n• Check the sender domain for lookalike characters (amaz0n.com vs amazon.com)\n• Hover over links before clicking — verify the destination\n• Look for urgency tactics ("act now", "account suspended")\n• Check for generic greetings ("Dear Customer")\n• Never enter credentials from an email link — go to the site directly\n\nUse the Email Scanner to check any suspicious sender.'
  if (lower.includes('password') && lower.includes('manager'))
    return 'Yes, you should absolutely use a password manager. Here\'s why:\n\n• Generates strong, unique passwords for every account\n• Stores them encrypted — you only remember one master password\n• Auto-fills login forms, reducing phishing risk\n• Many include breach monitoring (alert you if a password leaks)\n\nRecommended: Bitwarden (free/open-source), 1Password, or KeePassXC. Avoid storing passwords in browser autofill for sensitive accounts.'
  if (lower.includes('password'))
    return 'A strong password should be:\n\n• At least 12-16 characters long\n• A mix of uppercase, lowercase, numbers, and symbols\n• Unique — never reuse across accounts\n• A passphrase (e.g. "purple-elephant-dances-42!") is easier to remember and stronger\n\nAvoid:\n• Common words, names, or dates\n• Keyboard patterns (qwerty, 12345)\n• Anything found in breach databases\n\nUse the Password Leak Checker to verify your password hasn\'t been compromised.'
  if (lower.includes('deepfake') || lower.includes('image') || lower.includes('video'))
    return 'Deepfakes use AI to create synthetic media. Detection tips:\n\n• Look for unnatural blinking patterns or asymmetric eye movement\n• Check for inconsistent lighting and shadows\n• Audio-visual sync mismatches are common\n• Blurred boundaries around the face or hair\n• Unnatural skin texture or repeating artifacts\n\nUse the Image Scanner and Video Scanner tools for automated detection. For critical decisions, verify the source through multiple independent channels.'
  if (lower.includes('url') || lower.includes('link'))
    return 'To check if a URL is safe:\n\n• Look for HTTPS (padlock icon) — but note HTTPS doesn\'t mean safe\n• Check the domain spelling for lookalike characters\n• Be wary of shortened URLs (bit.ly, tinyurl) — expand them first\n• Check the domain age — newly registered domains are higher risk\n• Avoid URLs with excessive subdomains or random strings\n\nUse the Link Checker tool to scan any URL for phishing and malware in real time.'
  if (lower.includes('phone') || lower.includes('mobile') || lower.includes('android') || lower.includes('iphone'))
    return 'To secure your phone:\n\n• Enable biometric lock (fingerprint/face) + strong PIN\n• Install apps only from official stores (Play Store / App Store)\n• Keep OS and apps updated\n• Review app permissions regularly — revoke unnecessary ones\n• Enable "Find My Device" and remote wipe\n• Use a VPN on public Wi-Fi\n• Install a reputable mobile security app\n\nUse the APK Scanner to check Android app files before installing, and the SMS Scam Detector to check suspicious text messages.'
  if (lower.includes('qr'))
    return 'QR codes can be dangerous because you can\'t see where they lead before scanning. Tips:\n\n• Use a QR scanner that shows the URL before opening it\n• Never scan QR codes from unknown sources or printed flyers you didn\'t expect\n• Check for tampered QR codes (stickers placed over legitimate ones)\n• Avoid making payments through QR codes without verifying the recipient\n\nUse the QR Code Scanner tool — it shows the destination URL and checks it for threats before you open it.'
  if (lower.includes('2fa') || lower.includes('two-factor') || lower.includes('mfa'))
    return 'Two-factor authentication (2FA) adds a second verification step beyond your password. You should enable it on:\n\n• Email accounts\n• Banking and financial apps\n• Social media\n• Cloud storage\n• Any account with sensitive data\n\nPrefer authenticator apps (Authy, Google Authenticator) over SMS-based 2FA. For maximum security, use a hardware key (YubiKey).'
  if (lower.includes('breach') || lower.includes('leak') || lower.includes('dark web'))
    return 'A data breach is when a company\'s database is stolen and leaked online. Your email and password may be circulating on the dark web without you knowing.\n\nWhat to do:\n• Check your email with the Dark Web Breach Checker\n• Change passwords for any breached accounts immediately\n• Enable 2FA on all affected accounts\n• Monitor for unusual activity\n\nIf your password appears in a breach, assume it\'s compromised everywhere you used it — even if the breach was on a different service.'
  if (lower.includes('vpn'))
    return 'A VPN (Virtual Private Network) encrypts your internet traffic and hides your IP address. Use one when:\n\n• On public Wi-Fi (cafes, airports, hotels)\n• Accessing sensitive accounts away from home\n• You want to prevent ISP tracking\n\nChoose a reputable paid VPN (Mullvad, ProtonVPN, ExpressVPN). Free VPNs often sell your data. A VPN does NOT make you anonymous — it just shifts trust from your ISP to the VPN provider.'
  if (lower.includes('malware') || lower.includes('virus'))
    return 'Malware includes viruses, trojans, spyware, ransomware, and more. Protection tips:\n\n• Keep your OS and apps updated (patches fix security holes)\n• Don\'t install software from untrusted sources\n• Scan files before opening — use the APK Scanner for Android apps and the PDF Scanner for documents\n• Use reputable antivirus software\n• Be cautious with email attachments\n• Back up important data regularly (protection against ransomware)'
  return 'I\'m your AI Cyber Security Assistant. I can help with:\n\n• Phishing and email security\n• Password strength and leak checking\n• Deepfake and image verification\n• URL and QR code safety\n• Mobile and device security\n• Data breaches and dark web monitoring\n• 2FA, VPNs, and general cyber hygiene\n\nAsk me anything about staying safe online!'
}

export default function AIAssistantPage() {
  const [messages, setMessages] = useState<Msg[]>([])
  const [input, setInput] = useState('')
  const [typing, setTyping] = useState(false)
  const scrollRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    scrollRef.current?.scrollTo({ top: scrollRef.current.scrollHeight, behavior: 'smooth' })
  }, [messages, typing])

  const send = (text?: string) => {
    const msg = (text ?? input).trim()
    if (!msg) return
    const userMsg: Msg = { role: 'user', text: msg }
    setMessages((m) => [...m, userMsg])
    setInput('')
    setTyping(true)
    setTimeout(() => {
      setMessages((m) => [...m, { role: 'ai', text: aiReply(userMsg.text) }])
      setTyping(false)
    }, 1200)
  }

  return (
    <>
      <ScannerHero feature={feature} />
      {messages.length === 0 ? (
        <div className="fade-in-up" style={{ animationDelay: '100ms' }}>
          <div className="glass" style={{ padding: 28, textAlign: 'center', marginBottom: 20 }}>
            <div style={{ width: 56, height: 56, borderRadius: 16, margin: '0 auto 16px', background: `linear-gradient(135deg, ${feature.start}, ${feature.end})`, display: 'flex', alignItems: 'center', justifyContent: 'center' }} className="pulse-glow">
              <Bot size={28} color="white" />
            </div>
            <div style={{ fontSize: 17, fontWeight: 700, marginBottom: 6 }}>AI Cyber Security Assistant</div>
            <div style={{ fontSize: 14, color: 'var(--text-2)', lineHeight: 1.5 }}>Ask me about phishing, passwords, deepfakes, breaches, VPNs, and more.</div>
          </div>

          <div className="section-label">Suggested Questions</div>
          <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
            {suggestions.map((s, i) => (
              <button
                key={i}
                className="glass fade-in-up"
                style={{ padding: '14px 16px', display: 'flex', alignItems: 'center', gap: 12, textAlign: 'left', animationDelay: `${150 + i * 50}ms` }}
                onClick={() => send(s.text)}
              >
                <div style={{ width: 36, height: 36, borderRadius: 10, background: 'rgba(59,130,246,0.1)', display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0 }}>
                  <s.icon size={18} color="var(--blue-light)" />
                </div>
                <span style={{ fontSize: 14, fontWeight: 500 }}>{s.text}</span>
              </button>
            ))}
          </div>
        </div>
      ) : (
        <div ref={scrollRef} style={{ display: 'flex', flexDirection: 'column', gap: 12, maxHeight: 'calc(100vh - 340px)', overflowY: 'auto', paddingBottom: 12 }}>
          {messages.map((m, i) => (
            <div key={i} className={`chat-bubble ${m.role}`} style={{ whiteSpace: 'pre-wrap' }}>{m.text}</div>
          ))}
          {typing && (
            <div className="chat-bubble ai" style={{ display: 'flex', gap: 5, alignItems: 'center', padding: '14px 18px' }}>
              <span className="typing-dot" style={{ animationDelay: '0s' }} />
              <span className="typing-dot" style={{ animationDelay: '0.2s' }} />
              <span className="typing-dot" style={{ animationDelay: '0.4s' }} />
            </div>
          )}
        </div>
      )}

      <div style={{ position: 'fixed', bottom: 80, left: '50%', transform: 'translateX(-50%)', width: '100%', maxWidth: 440, padding: '0 20px', display: 'flex', gap: 10 }}>
        <input className="input-field" placeholder="Ask about cybersecurity…" value={input} onChange={(e) => setInput(e.target.value)} onKeyDown={(e) => e.key === 'Enter' && send()} style={{ flex: 1 }} />
        <button className="btn-primary" style={{ width: 56, padding: 0 }} onClick={() => send()} disabled={!input.trim()}>
          <Send size={18} />
        </button>
      </div>
    </>
  )
}
