import { supabase, type ScanRow, type SecurityScoreRow } from './supabase'

export type { ScanRow, SecurityScoreRow }

export type Verdict = 'safe' | 'suspicious' | 'dangerous'

export interface ScanResult {
  verdict: Verdict
  summary: string
  details: string[]
  confidence?: number
}

/**
 * Saves a scan record to Supabase. Silently fails if not authenticated
 * — callers don't need to handle errors since scans work without auth too.
 */
export async function saveScan(params: {
  scanType: string
  input: string
  verdict: Verdict
  summary: string
  details: string[]
  confidence?: number
  title?: string
  severity?: number
}): Promise<void> {
  try {
    const { data: { user } } = await supabase.auth.getUser()
    if (!user) return

    await supabase.from('scans').insert({
      scan_type: params.scanType,
      input: params.input,
      verdict: params.verdict,
      summary: params.summary,
      details: params.details,
      confidence: params.confidence ?? 0,
      title: params.title ?? null,
      severity: params.severity ?? 0,
    })
  } catch {
    // Silent fail — scan results still display even if save fails
  }
}

/**
 * Fetches scan history from Supabase. Returns empty array if not authenticated.
 */
export async function fetchScans(filter?: Verdict | 'all'): Promise<ScanRow[]> {
  try {
    const { data: { user } } = await supabase.auth.getUser()
    if (!user) return []

    let query = supabase
      .from('scans')
      .select('*')
      .order('created_at', { ascending: false })
      .limit(100)

    if (filter && filter !== 'all') {
      query = query.eq('verdict', filter)
    }

    const { data, error } = await query
    if (error) return []
    return data as ScanRow[]
  } catch {
    return []
  }
}

/**
 * Fetches the user's security score, creating a default row if none exists.
 */
export async function fetchSecurityScore(): Promise<SecurityScoreRow | null> {
  try {
    const { data: { user } } = await supabase.auth.getUser()
    if (!user) return null

    const { data } = await supabase
      .from('security_scores')
      .select('*')
      .eq('user_id', user.id)
      .maybeSingle()

    if (data) return data as SecurityScoreRow

    // Create default row
    const { data: created } = await supabase
      .from('security_scores')
      .insert({ user_id: user.id })
      .select('*')
      .maybeSingle()

    return created as SecurityScoreRow | null
  } catch {
    return null
  }
}

/**
 * Recalculates and updates the security score based on scan history.
 */
export async function updateSecurityScore(): Promise<SecurityScoreRow | null> {
  try {
    const { data: { user } } = await supabase.auth.getUser()
    if (!user) return null

    const { data: scans } = await supabase
      .from('scans')
      .select('verdict, scan_type')
      .order('created_at', { ascending: false })
      .limit(500)

    if (!scans) return null

    const total = scans.length
    const threats = scans.filter(s => s.verdict === 'dangerous').length
    const suspicious = scans.filter(s => s.verdict === 'suspicious').length

    // Calculate category scores based on scan results
    const typeScores: Record<string, { safe: number; total: number }> = {}
    for (const s of scans) {
      if (!typeScores[s.scan_type]) typeScores[s.scan_type] = { safe: 0, total: 0 }
      typeScores[s.scan_type].total++
      if (s.verdict === 'safe') typeScores[s.scan_type].safe++
    }

    const calcScore = (types: string[]): number => {
      const relevant = types.flatMap(t => typeScores[t] ? [typeScores[t]] : [])
      if (relevant.length === 0) return 50
      const safeRatio = relevant.reduce((sum, r) => sum + r.safe / r.total, 0) / relevant.length
      return Math.round(safeRatio * 100)
    }

    const password_score = calcScore(['password'])
    const email_score = calcScore(['email', 'darkweb', 'scam'])
    const browsing_score = calcScore(['link', 'qr', 'news', 'file'])
    const identity_score = calcScore(['image', 'video', 'pdf', 'apk', 'screenshot'])
    const device_score = calcScore(['sms', 'camera', 'apk', 'file'])

    const overall = Math.round(
      (password_score + email_score + browsing_score + identity_score + device_score) / 5
    )

    const { data: updated } = await supabase
      .from('security_scores')
      .update({
        overall_score: overall,
        password_score,
        email_score,
        browsing_score,
        identity_score,
        device_score,
        threats_blocked: threats,
        scans_run: total,
        updated_at: new Date().toISOString(),
      })
      .eq('user_id', user.id)
      .select('*')
      .maybeSingle()

    return updated as SecurityScoreRow | null
  } catch {
    return null
  }
}
