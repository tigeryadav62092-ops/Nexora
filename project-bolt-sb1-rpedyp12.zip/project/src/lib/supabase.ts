import { createClient } from '@supabase/supabase-js'

const url = import.meta.env.VITE_SUPABASE_URL as string
const anonKey = import.meta.env.VITE_SUPABASE_ANON_KEY as string

export const supabase = createClient(url, anonKey, {
  auth: {
    persistSession: true,
    autoRefreshToken: true,
  },
})

export type ScanRow = {
  id: string
  scan_type: string
  input: string
  verdict: 'safe' | 'suspicious' | 'dangerous'
  confidence: number
  summary: string | null
  details: string[] | null
  title: string | null
  severity: number | null
  created_at: string
}

export type SecurityScoreRow = {
  id: string
  overall_score: number
  password_score: number
  email_score: number
  browsing_score: number
  identity_score: number
  device_score: number
  threats_blocked: number
  scans_run: number
  updated_at: string
}
