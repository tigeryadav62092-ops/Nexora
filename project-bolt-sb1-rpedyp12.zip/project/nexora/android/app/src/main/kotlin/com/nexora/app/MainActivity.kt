package com.nexora.app

import io.flutter.app.FlutterActivity

class MainActivity : FlutterActivity()
