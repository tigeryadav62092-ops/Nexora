# Nexora — Development Roadmap

## Architecture

```
lib/
  core/
    constants/       # App-wide constants, color palette, feature definitions
    theme/           # Material 3 themes (dark + light), theme mode enum
    navigation/      # GoRouter configuration + route definitions
    providers/       # Riverpod providers, split by domain
      auth_provider.dart
      settings_provider.dart
      scan_provider.dart
  data/
    models/          # Domain models (ScanRecord, ScanSignal, etc.)
    repositories/    # Data access (ScanRepository)
    services/        # External service contracts (AiService, AuthService)
  features/
    auth/            # Login, Register screens
    splash/          # Splash screen
    home/            # Home dashboard
    scanner/         # All scanner tool screens
    history/         # Scan history
    profile/         # User profile
    settings/        # App settings
  shared/
    widgets/         # Reusable UI components
```

### Principles

- **Feature-first**: Each feature owns its screens. Shared widgets live in `shared/`.
- **Single responsibility**: Providers are split by domain (auth, settings, scan).
- **Dependency inversion**: Services are abstract interfaces; concrete implementations are injected via providers. This lets us swap Supabase for Firebase without touching UI or repository code.
- **Centralized navigation**: GoRouter owns all routes. No scattered `Navigator.push` calls.
- **Single color source**: One palette in `app_colors.dart`; themes and context extensions derive from it.

## Current state (v1.0)

- [x] Splash, Login, Register, Home, Scanner, History, Profile, Settings screens
- [x] 7 scanner tools (Link, News, Image, QR, Email, AI Assistant, Video placeholder)
- [x] Dark + light theme with Material 3
- [x] 5-language localization (EN, HI, AR, ES, FR)
- [x] Supabase auth + scan history persistence
- [x] Riverpod state management

## v1.1 — Architecture optimization (this phase)

- [ ] Deduplicate color system to single source of truth
- [ ] Split monolithic providers into domain-specific files
- [ ] Replace imperative navigation with GoRouter
- [ ] Create AuthService abstraction for Firebase migration
- [ ] Remove dead code, unused imports, unreachable routes
- [ ] Clean up pubspec (remove unused deps or wire them in)

## v1.2 — Firebase integration (next phase)

- [ ] Add firebase_core + firebase_auth packages
- [ ] Implement FirebaseAuthService behind AuthService interface
- [ ] Add Firestore repository alongside Supabase repository
- [ ] Feature-flag backend selection via build configuration
- [ ] Add Crashlytics for error reporting

## v1.3 — Real AI backend (future)

- [ ] Replace LocalAiService with API-backed implementation
- [ ] Add streaming results for AI Assistant
- [ ] Image analysis via ML model API
- [ ] Reverse image search integration

## v2.0 — Production hardening (future)

- [ ] Offline mode with local cache
- [ ] Push notifications for threat alerts
- [ ] Biometric authentication
- [ ] Onboarding flow
- [ ] Analytics + A/B testing
