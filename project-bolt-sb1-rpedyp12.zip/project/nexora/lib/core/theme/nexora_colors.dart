import 'package:flutter/material.dart';

import '../constants/app_colors.dart';

/// Theme-aware surface colors resolved from the current [BuildContext].
/// All values come from [AppColorScheme] — this extension adds no new
/// colors, it just makes them convenient to access in widget code.
extension NexoraColors on BuildContext {
  AppColorScheme get _scheme =>
      AppColorScheme.of(Theme.of(this).brightness);

  Color get bg => _scheme.background;
  Color get surface => _scheme.surface;
  Color get surfaceVariant => _scheme.surfaceVariant;
  Color get outline => _scheme.outline;
  Color get textPrimary => _scheme.textPrimary;
  Color get textSecondary => _scheme.textSecondary;
}
