import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../data/models/scan_record.dart';
import '../../data/repositories/scan_repository.dart';
import '../../data/services/ai_service.dart';
import 'auth_provider.dart';
import 'supabase_provider.dart';

final aiServiceProvider = Provider<AiService>((ref) {
  return LocalAiService(ref.watch(supabaseProvider));
});

final scanRepositoryProvider = Provider<ScanRepository>((ref) {
  return ScanRepository(ref.watch(supabaseProvider));
});

/// Loads the user's scan history from Supabase.
final scanHistoryProvider =
    FutureProvider<List<ScanRecord>>((ref) async {
  final auth = ref.watch(authProvider);
  if (!auth.isAuthenticated) return [];
  final repo = ref.watch(scanRepositoryProvider);
  return repo.recent();
});

/// Runs a scan, persists the result, and invalidates the history list.
final scanRunnerProvider = Provider<ScanRunner>((ref) {
  return ScanRunner(
    ref.watch(aiServiceProvider),
    ref.watch(scanRepositoryProvider),
    ref,
  );
});

class ScanRunner {
  final AiService _ai;
  final ScanRepository _repo;
  final Ref _ref;

  ScanRunner(this._ai, this._repo, this._ref);

  Future<ScanRecord> runLink(String url) => _run(() => _ai.scanLink(url));
  Future<ScanRecord> runNews(String text) => _run(() => _ai.scanNews(text));
  Future<ScanRecord> runImage(String path) => _run(() => _ai.scanImage(path));
  Future<ScanRecord> runQr(String content) => _run(() => _ai.scanQr(content));
  Future<ScanRecord> runEmail(String body) => _run(() => _ai.scanEmail(body));
  Future<ScanRecord> runVideo(String path) => _run(() => _ai.scanVideo(path));
  Future<ScanRecord> runPassword(String pwd) => _run(() => _ai.scanPassword(pwd));

  Future<ScanRecord> _run(Future<ScanRecord> Function() action) async {
    final record = await action();
    final saved = await _repo.save(record);
    _ref.invalidate(scanHistoryProvider);
    return saved;
  }
}
