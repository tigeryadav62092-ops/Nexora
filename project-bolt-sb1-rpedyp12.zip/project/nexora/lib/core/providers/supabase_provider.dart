import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

import '../../core/constants/app_constants.dart';
import '../../data/services/auth_service.dart';

/// Initializes the Supabase client once at app startup.
final supabaseInitProvider = FutureProvider<void>((ref) async {
  await Supabase.initialize(
    url: AppConstants.supabaseUrl,
    anonKey: AppConstants.supabaseAnonKey,
  );
});

final supabaseProvider = Provider<SupabaseClient>((ref) {
  return Supabase.instance.client;
});

/// Provides the [AuthService] implementation.
/// Swap this to [FirebaseAuthService] when migrating to Firebase.
final authServiceProvider = Provider<AuthService>((ref) {
  return SupabaseAuthService(ref.watch(supabaseProvider));
});
