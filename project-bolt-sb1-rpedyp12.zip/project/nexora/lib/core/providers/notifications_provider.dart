import 'package:flutter_riverpod/flutter_riverpod.dart';

/// A single in-app notification.
class NexoraNotification {
  final String id;
  final String title;
  final String body;
  final DateTime timestamp;
  final bool read;
  final NotificationType type;

  const NexoraNotification({
    required this.id,
    required this.title,
    required this.body,
    required this.timestamp,
    this.read = false,
    this.type = NotificationType.info,
  });

  NexoraNotification copyWith({bool? read}) => NexoraNotification(
        id: id,
        title: title,
        body: body,
        timestamp: timestamp,
        read: read ?? this.read,
        type: type,
      );
}

enum NotificationType { info, warning, threat, success }

class NotificationsState {
  final List<NexoraNotification> items;
  final bool loading;

  const NotificationsState({this.items = const [], this.loading = false});

  int get unreadCount => items.where((n) => !n.read).length;
}

class NotificationsNotifier extends StateNotifier<NotificationsState> {
  NotificationsNotifier() : super(const NotificationsState()) {
    _seed();
  }

  void _seed() {
    final now = DateTime.now();
    state = NotificationsState(items: [
      NexoraNotification(
        id: 'welcome',
        title: 'Welcome to Nexora',
        body: 'Your AI safety platform is ready. Run your first scan!',
        timestamp: now,
        type: NotificationType.success,
      ),
      NexoraNotification(
        id: 'tip-1',
        title: 'Security Tip',
        body: 'Use unique passwords for each account. Try the Password Strength tool.',
        timestamp: now.subtract(const Duration(minutes: 5)),
        type: NotificationType.info,
      ),
    ]);
  }

  void add(NexoraNotification n) {
    state = NotificationsState(items: [n, ...state.items]);
  }

  void markRead(String id) {
    state = NotificationsState(
      items: state.items.map((n) => n.id == id ? n.copyWith(read: true) : n).toList(),
    );
  }

  void markAllRead() {
    state = NotificationsState(
      items: state.items.map((n) => n.copyWith(read: true)).toList(),
    );
  }

  void clear() {
    state = const NotificationsState();
  }
}

final notificationsProvider =
    StateNotifierProvider<NotificationsNotifier, NotificationsState>((ref) {
  return NotificationsNotifier();
});
