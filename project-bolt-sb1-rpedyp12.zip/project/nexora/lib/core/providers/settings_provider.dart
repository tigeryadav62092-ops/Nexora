import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../theme/app_theme_mode.dart';

class SettingsState {
  final AppThemeMode themeMode;
  final Locale locale;

  const SettingsState({
    this.themeMode = AppThemeMode.system,
    this.locale = const Locale('en'),
  });

  SettingsState copyWith({AppThemeMode? themeMode, Locale? locale}) =>
      SettingsState(
        themeMode: themeMode ?? this.themeMode,
        locale: locale ?? this.locale,
      );
}

class SettingsNotifier extends StateNotifier<SettingsState> {
  static const _keyTheme = 'theme_mode';
  static const _keyLocale = 'locale';

  SettingsNotifier() : super(const SettingsState()) {
    _load();
  }

  Future<void> _load() async {
    final prefs = await SharedPreferences.getInstance();
    state = SettingsState(
      themeMode: AppThemeMode.fromString(prefs.getString(_keyTheme)),
      locale: Locale(prefs.getString(_keyLocale) ?? 'en'),
    );
  }

  Future<void> setThemeMode(AppThemeMode mode) async {
    state = state.copyWith(themeMode: mode);
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_keyTheme, mode.name);
  }

  Future<void> setLocale(Locale locale) async {
    state = state.copyWith(locale: locale);
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_keyLocale, locale.languageCode);
  }
}

final settingsProvider =
    StateNotifierProvider<SettingsNotifier, SettingsState>((ref) {
  return SettingsNotifier();
});
