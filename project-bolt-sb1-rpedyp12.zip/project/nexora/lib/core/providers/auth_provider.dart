import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../data/services/auth_service.dart';
import 'supabase_provider.dart';

class AuthState {
  final AuthUser? user;
  final bool loading;
  final String? error;

  const AuthState({this.user, this.loading = false, this.error});

  bool get isAuthenticated => user != null;
}

class AuthNotifier extends StateNotifier<AuthState> {
  final AuthService _service;

  AuthNotifier(this._service) : super(const AuthState()) {
    state = AuthState(user: _service.currentUser);
    _service.authStateChanges.listen((user) {
      state = AuthState(user: user);
    });
  }

  Future<void> signIn(String email, String password) async {
    state = const AuthState(loading: true);
    try {
      final user = await _service.signIn(email, password);
      state = AuthState(user: user);
    } catch (e) {
      state = AuthState(error: e.toString());
    }
  }

  Future<void> signUp(String email, String password, String name) async {
    state = const AuthState(loading: true);
    try {
      final user = await _service.signUp(email, password, name);
      state = AuthState(user: user);
    } catch (e) {
      state = AuthState(error: e.toString());
    }
  }

  Future<void> signOut() async {
    await _service.signOut();
    state = const AuthState();
  }
}

final authProvider = StateNotifierProvider<AuthNotifier, AuthState>((ref) {
  return AuthNotifier(ref.watch(authServiceProvider));
});
