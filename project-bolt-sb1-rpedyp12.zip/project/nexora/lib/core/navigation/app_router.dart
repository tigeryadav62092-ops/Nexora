import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import '../../core/providers/auth_provider.dart';
import '../../features/auth/presentation/login_page.dart';
import '../../features/auth/presentation/register_page.dart';
import '../../features/notifications/presentation/notifications_page.dart';
import '../../features/scanner/presentation/ai_assistant_page.dart';
import '../../features/scanner/presentation/email_scanner_page.dart';
import '../../features/scanner/presentation/fake_news_page.dart';
import '../../features/scanner/presentation/image_scanner_page.dart';
import '../../features/scanner/presentation/link_checker_page.dart';
import '../../features/scanner/presentation/password_checker_page.dart';
import '../../features/scanner/presentation/qr_scanner_page.dart';
import '../../features/scanner/presentation/video_scanner_page.dart';
import '../../shared/widgets/main_shell.dart';

/// Centralized GoRouter configuration.
/// All routes are declared here — no scattered Navigator.push calls.
final routerProvider = Provider<GoRouter>((ref) {
  final auth = ref.watch(authProvider);

  return GoRouter(
    initialLocation: '/',
    redirect: (context, state) {
      final isAuthenticated = auth.isAuthenticated;
      final isAuthRoute = state.matchedLocation == '/login' ||
          state.matchedLocation == '/register';

      if (!isAuthenticated && !isAuthRoute) return '/login';
      if (isAuthenticated && isAuthRoute) return '/';
      return null;
    },
    routes: [
      GoRoute(
        path: '/',
        pageBuilder: (context, state) => const NoTransitionPage(
          child: MainShell(),
        ),
      ),
      GoRoute(
        path: '/login',
        pageBuilder: (context, state) => _fadePage(
          child: LoginPage(
            onLoginSuccess: () => context.go('/'),
            goToRegister: () => context.push('/register'),
          ),
        ),
      ),
      GoRoute(
        path: '/register',
        pageBuilder: (context, state) => _fadePage(
          child: RegisterPage(
            onRegisterSuccess: () => context.go('/'),
            goToLogin: () => context.pop(),
          ),
        ),
      ),
      GoRoute(
        path: '/scanner/link',
        pageBuilder: (context, state) => _slidePage(const LinkCheckerPage()),
      ),
      GoRoute(
        path: '/scanner/news',
        pageBuilder: (context, state) => _slidePage(const FakeNewsPage()),
      ),
      GoRoute(
        path: '/scanner/image',
        pageBuilder: (context, state) => _slidePage(const ImageScannerPage()),
      ),
      GoRoute(
        path: '/scanner/qr',
        pageBuilder: (context, state) => _slidePage(const QrScannerPage()),
      ),
      GoRoute(
        path: '/scanner/email',
        pageBuilder: (context, state) => _slidePage(const EmailScannerPage()),
      ),
      GoRoute(
        path: '/scanner/ai',
        pageBuilder: (context, state) => _slidePage(const AiAssistantPage()),
      ),
      GoRoute(
        path: '/scanner/video',
        pageBuilder: (context, state) => _slidePage(const VideoScannerPage()),
      ),
      GoRoute(
        path: '/scanner/password',
        pageBuilder: (context, state) =>
            _slidePage(const PasswordCheckerPage()),
      ),
      GoRoute(
        path: '/notifications',
        pageBuilder: (context, state) => _slidePage(const NotificationsPage()),
      ),
    ],
  );
});

CustomTransitionPage _slidePage(Widget child) {
  return CustomTransitionPage(
    child: child,
    transitionDuration: const Duration(milliseconds: 300),
    reverseTransitionDuration: const Duration(milliseconds: 250),
    transitionsBuilder: (context, animation, secondaryAnimation, child) {
      return SlideTransition(
        position: Tween<Offset>(
          begin: const Offset(1.0, 0.0),
          end: Offset.zero,
        ).animate(CurvedAnimation(
          parent: animation,
          curve: Curves.easeOutCubic,
        )),
        child: FadeTransition(
          opacity: animation,
          child: child,
        ),
      );
    },
  );
}

CustomTransitionPage _fadePage(Widget child) {
  return CustomTransitionPage(
    child: child,
    transitionDuration: const Duration(milliseconds: 400),
    transitionsBuilder: (context, animation, secondaryAnimation, child) {
      return FadeTransition(
        opacity: CurvedAnimation(parent: animation, curve: Curves.easeIn),
        child: child,
      );
    },
  );
}
