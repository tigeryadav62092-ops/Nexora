/// App-wide constant values.
class AppConstants {
  AppConstants._();

  static const String appName = 'Nexora';
  static const String tagline = 'Think Smart. Stay Safe.';
  static const Duration splashDelay = Duration(seconds: 2);

  // Supabase credentials (bundled for mobile — anon key is public, protected by RLS)
  static const String supabaseUrl = String.fromEnvironment(
    'SUPABASE_URL',
    defaultValue: 'https://mpcubwitrcghodiufrcw.supabase.co',
  );
  static const String supabaseAnonKey = String.fromEnvironment(
    'SUPABASE_ANON_KEY',
    defaultValue: 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Im1wY3Vid2l0cmNnaG9kaXVmcmN3Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3ODUwNzU5MjAsImV4cCI6MjEwMDY1MTkyMH0.gHDVqYmQjhgqT6iijao73UqwvUjwAuk8CPs6r0tU6mI',
  );
}
