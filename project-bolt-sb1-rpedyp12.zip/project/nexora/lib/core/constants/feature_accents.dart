import 'package:flutter/material.dart';

/// Accent definition (color + icon + name) for each home feature card.
class FeatureAccent {
  final String name;
  final String description;
  final Color start;
  final Color end;
  final IconData icon;

  const FeatureAccent({
    required this.name,
    required this.description,
    required this.start,
    required this.end,
    required this.icon,
  );

  static const FeatureAccent linkChecker = FeatureAccent(
    name: 'Link Checker',
    description: 'Scan URLs for phishing and malware in real time.',
    start: Color(0xFF3B82F6),
    end: Color(0xFF1D4ED8),
    icon: Icons.link_rounded,
  );

  static const FeatureAccent fakeNews = FeatureAccent(
    name: 'Fake News Check',
    description: 'Detect misinformation with AI verification.',
    start: Color(0xFF8B5CF6),
    end: Color(0xFF6D28D9),
    icon: Icons.newspaper_rounded,
  );

  static const FeatureAccent imageScanner = FeatureAccent(
    name: 'Image Scanner',
    description: 'Spot deepfakes and manipulated media.',
    start: Color(0xFF22D3EE),
    end: Color(0xFF0891B2),
    icon: Icons.image_rounded,
  );

  static const FeatureAccent videoScanner = FeatureAccent(
    name: 'Video Scanner',
    description: 'Analyze videos for synthetic content.',
    start: Color(0xFFF472B6),
    end: Color(0xFFDB2777),
    icon: Icons.videocam_rounded,
  );

  static const FeatureAccent emailScanner = FeatureAccent(
    name: 'Email Scanner',
    description: 'Uncover phishing and spoofing attempts.',
    start: Color(0xFF34D399),
    end: Color(0xFF059669),
    icon: Icons.email_rounded,
  );

  static const FeatureAccent aiAssistant = FeatureAccent(
    name: 'AI Assistant',
    description: 'Ask anything about your digital safety.',
    start: Color(0xFFFBBF24),
    end: Color(0xFFD97706),
    icon: Icons.smart_toy_rounded,
  );

  static const FeatureAccent qrScanner = FeatureAccent(
    name: 'QR Code Scanner',
    description: 'Check if QR links are safe.',
    start: Color(0xFF6366F1),
    end: Color(0xFF4338CA),
    icon: Icons.qr_code_scanner_rounded,
  );

  static const FeatureAccent passwordChecker = FeatureAccent(
    name: 'Password Strength',
    description: 'Test how strong your passwords really are.',
    start: Color(0xFF10B981),
    end: Color(0xFF047857),
    icon: Icons.password_rounded,
  );

  static const List<FeatureAccent> all = [
    linkChecker,
    fakeNews,
    imageScanner,
    videoScanner,
    emailScanner,
    aiAssistant,
    qrScanner,
    passwordChecker,
  ];
}
