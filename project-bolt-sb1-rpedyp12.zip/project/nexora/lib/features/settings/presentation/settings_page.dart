import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../core/constants/app_colors.dart';
import '../../../core/providers/providers.dart';
import '../../../core/theme/app_theme_mode.dart';
import '../../../core/theme/nexora_colors.dart';
import '../../../shared/widgets/gradient_background.dart';

class SettingsPage extends ConsumerStatefulWidget {
  const SettingsPage({super.key});

  @override
  ConsumerState<SettingsPage> createState() => _SettingsPageState();
}

class _SettingsPageState extends ConsumerState<SettingsPage> {
  bool _notifications = true;
  bool _autoScan = true;
  bool _biometrics = false;

  @override
  Widget build(BuildContext context) {
    final settings = ref.watch(settingsProvider);

    return GradientBackground(
      child: CustomScrollView(
        slivers: [
          SliverAppBar(
            automaticallyImplyLeading: false,
            title: const Text('Settings'),
          ),
          SliverPadding(
            padding: const EdgeInsets.all(20),
            sliver: SliverList(
              delegate: SliverChildListDelegate([
                _SectionTitle('Theme'),
                _SettingsGroup(
                  items: [
                    for (final mode in AppThemeMode.values)
                      RadioListTile<AppThemeMode>(
                        value: mode,
                        groupValue: settings.themeMode,
                        onChanged: (v) =>
                            ref.read(settingsProvider.notifier).setThemeMode(v!),
                        title: Text(mode.label),
                        activeColor: AppColors.primaryBlue,
                      ),
                  ],
                ),
                const SizedBox(height: 24),
                _SectionTitle('Language'),
                _SettingsGroup(
                  items: [
                    for (final entry in _languages.entries)
                      RadioListTile<String>(
                        value: entry.key,
                        groupValue: settings.locale.languageCode,
                        onChanged: (v) => ref
                            .read(settingsProvider.notifier)
                            .setLocale(Locale(v!)),
                        title: Text(entry.value),
                        activeColor: AppColors.primaryBlue,
                      ),
                  ],
                ),
                const SizedBox(height: 24),
                _SectionTitle('Security'),
                _SettingsGroup(
                  items: [
                    _SwitchTile(
                      icon: Icons.fingerprint_rounded,
                      title: 'Biometric unlock',
                      value: _biometrics,
                      onChanged: (v) => setState(() => _biometrics = v),
                    ),
                    _SwitchTile(
                      icon: Icons.auto_awesome_rounded,
                      title: 'Auto-scan links',
                      value: _autoScan,
                      onChanged: (v) => setState(() => _autoScan = v),
                    ),
                  ],
                ),
                const SizedBox(height: 24),
                _SectionTitle('Preferences'),
                _SettingsGroup(
                  items: [
                    _SwitchTile(
                      icon: Icons.notifications_rounded,
                      title: 'Push notifications',
                      value: _notifications,
                      onChanged: (v) => setState(() => _notifications = v),
                    ),
                  ],
                ),
                const SizedBox(height: 24),
                _SectionTitle('About'),
                _SettingsGroup(
                  items: [
                    _NavTile(
                      icon: Icons.info_outline_rounded,
                      title: 'Version',
                      trailing: '1.0.0',
                      onTap: () => _showAbout(context, 'Nexora v1.0.0',
                          'Nexora — Think Smart. Stay Safe.\n\nYour AI-powered cyber security companion.'),
                    ),
                    _NavTile(
                      icon: Icons.privacy_tip_outlined,
                      title: 'Privacy policy',
                      onTap: () => _showAbout(context, 'Privacy Policy',
                          'Nexora does not sell your data. Scan results are stored securely in your account and never shared with third parties.'),
                    ),
                    _NavTile(
                      icon: Icons.description_outlined,
                      title: 'Terms of service',
                      onTap: () => _showAbout(context, 'Terms of Service',
                          'By using Nexora you agree to use the app for lawful purposes. AI verdicts are advisory — always use your own judgment.'),
                    ),
                  ],
                ),
                const SizedBox(height: 32),
              ]),
            ),
          ),
        ],
      ),
    );
  }

  void _showAbout(BuildContext context, String title, String body) {
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        title: Text(title),
        content: Text(body),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(ctx).pop(),
            child: const Text('Close'),
          ),
        ],
      ),
    );
  }
}

const _languages = {
  'en': 'English',
  'hi': 'हिन्दी',
  'ar': 'العربية',
  'es': 'Español',
  'fr': 'Français',
};

class _SectionTitle extends StatelessWidget {
  final String text;
  const _SectionTitle(this.text);

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(left: 4, bottom: 10),
      child: Text(
        text,
        style: TextStyle(
          fontSize: 13,
          fontWeight: FontWeight.w600,
          color: context.textSecondary,
          letterSpacing: 0.5,
        ),
      ),
    );
  }
}

class _SettingsGroup extends StatelessWidget {
  final List<Widget> items;
  const _SettingsGroup({required this.items});

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [context.surface, context.surfaceVariant],
        ),
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: context.outline.withOpacity(0.5)),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.04),
            blurRadius: 12,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: Column(
        children: [
          for (int i = 0; i < items.length; i++) ...[
            items[i],
            if (i < items.length - 1)
              Divider(height: 1, indent: 56, color: context.outline.withOpacity(0.4)),
          ],
        ],
      ),
    );
  }
}

class _SwitchTile extends StatelessWidget {
  final IconData icon;
  final String title;
  final bool value;
  final ValueChanged<bool> onChanged;

  const _SwitchTile({
    required this.icon,
    required this.title,
    required this.value,
    required this.onChanged,
  });

  @override
  Widget build(BuildContext context) {
    return SwitchListTile(
      secondary: Icon(icon, color: AppColors.primaryBlueLight),
      title: Text(title),
      value: value,
      onChanged: onChanged,
    );
  }
}

class _NavTile extends StatelessWidget {
  final IconData icon;
  final String title;
  final String? trailing;
  final VoidCallback? onTap;

  const _NavTile({
    required this.icon,
    required this.title,
    this.trailing,
    this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return ListTile(
      leading: Icon(icon, color: AppColors.primaryBlueLight),
      title: Text(title),
      trailing: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          if (trailing != null)
            Text(
              trailing!,
              style: TextStyle(color: context.textSecondary),
            ),
          const SizedBox(width: 6),
          Icon(Icons.chevron_right_rounded, color: context.textSecondary),
        ],
      ),
      onTap: onTap,
    );
  }
}
