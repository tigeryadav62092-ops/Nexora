import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../core/constants/app_colors.dart';
import '../../../core/providers/providers.dart';
import '../../../core/theme/nexora_colors.dart';
import '../../../data/models/scan_record.dart';
import '../../../shared/widgets/gradient_background.dart';
import '../../../shared/widgets/shimmer_loading.dart';

class HistoryPage extends ConsumerWidget {
  const HistoryPage({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final scansAsync = ref.watch(scanHistoryProvider);

    return GradientBackground(
      child: CustomScrollView(
        slivers: [
          SliverAppBar(
            automaticallyImplyLeading: false,
            title: const Text('History'),
          ),
          scansAsync.when(
            loading: () => SliverPadding(
              padding: const EdgeInsets.all(20),
              sliver: SliverList(
                delegate: SliverChildBuilderDelegate(
                  (context, index) => Padding(
                    padding: const EdgeInsets.only(bottom: 12),
                    child: ShimmerLoading(
                      child: Container(
                        padding: const EdgeInsets.all(16),
                        decoration: BoxDecoration(
                          color: context.surfaceVariant,
                          borderRadius: BorderRadius.circular(16),
                        ),
                        child: Row(
                          children: [
                            ShimmerBox(width: 44, height: 44, radius: 12),
                            const SizedBox(width: 14),
                            Expanded(
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  ShimmerBox(
                                      width: 180, height: 14, radius: 6),
                                  const SizedBox(height: 8),
                                  ShimmerBox(
                                      width: 100, height: 12, radius: 6),
                                ],
                              ),
                            ),
                            ShimmerBox(width: 60, height: 24, radius: 12),
                          ],
                        ),
                      ),
                    ),
                  ),
                  childCount: 6,
                ),
              ),
            ),
            error: (error, _) => SliverFillRemaining(
              child: Center(
                child: Padding(
                  padding: const EdgeInsets.all(24),
                  child: Text(
                    'Could not load history.\n$error',
                    textAlign: TextAlign.center,
                    style: TextStyle(color: context.textSecondary),
                  ),
                ),
              ),
            ),
            data: (scans) {
              if (scans.isEmpty) {
                return SliverFillRemaining(
                  child: Center(
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Icon(Icons.history_rounded,
                            size: 56, color: context.textSecondary),
                        const SizedBox(height: 16),
                        Text(
                          'No scans yet',
                          style: TextStyle(
                            fontSize: 18,
                            fontWeight: FontWeight.w600,
                            color: context.textPrimary,
                          ),
                        ),
                        const SizedBox(height: 8),
                        Text(
                          'Your scan history will appear here.',
                          style: TextStyle(color: context.textSecondary),
                        ),
                      ],
                    ),
                  ),
                );
              }
              return SliverPadding(
                padding: const EdgeInsets.fromLTRB(20, 8, 20, 24),
                sliver: SliverList(
                  delegate: SliverChildBuilderDelegate(
                    (context, index) {
                      return TweenAnimationBuilder<double>(
                        tween: Tween(begin: 0.0, end: 1.0),
                        duration: Duration(
                          milliseconds: 300 + (index * 60).clamp(0, 200),
                        ),
                        curve: Curves.easeOut,
                        builder: (context, value, child) {
                          return Opacity(
                            opacity: value.clamp(0.0, 1.0),
                            child: Transform.translate(
                              offset: Offset(0, 20 * (1 - value)),
                              child: child,
                            ),
                          );
                        },
                        child: _ScanTile(record: scans[index]),
                      );
                    },
                    childCount: scans.length,
                  ),
                ),
              );
            },
          ),
        ],
      ),
    );
  }
}

class _ScanTile extends StatelessWidget {
  final ScanRecord record;
  const _ScanTile({required this.record});

  @override
  Widget build(BuildContext context) {
    final verdictColor = _verdictColor(record.verdict);
    final time = record.createdAt != null
        ? _formatDate(record.createdAt!)
        : '';

    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [context.surface, context.surfaceVariant],
        ),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: context.outline.withOpacity(0.5)),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.04),
            blurRadius: 12,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: Row(
        children: [
          Container(
            width: 44,
            height: 44,
            decoration: BoxDecoration(
              color: verdictColor.withOpacity(0.15),
              borderRadius: BorderRadius.circular(12),
            ),
            child: Icon(_typeIcon(record.type), color: verdictColor),
          ),
          const SizedBox(width: 14),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  record.input,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: TextStyle(
                    fontSize: 14,
                    fontWeight: FontWeight.w600,
                    color: context.textPrimary,
                  ),
                ),
                const SizedBox(height: 4),
                Text(
                  '${record.type.label} • $time',
                  style: TextStyle(
                    fontSize: 12,
                    color: context.textSecondary,
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(width: 8),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
            decoration: BoxDecoration(
              color: verdictColor.withOpacity(0.15),
              borderRadius: BorderRadius.circular(12),
            ),
            child: Text(
              record.verdict.label,
              style: TextStyle(
                fontSize: 11,
                fontWeight: FontWeight.w600,
                color: verdictColor,
              ),
            ),
          ),
        ],
      ),
    );
  }

  Color _verdictColor(ScanVerdict v) => switch (v) {
        ScanVerdict.safe => AppColors.success,
        ScanVerdict.suspicious => AppColors.warning,
        ScanVerdict.dangerous => AppColors.error,
      };

  IconData _typeIcon(ScanType t) => switch (t) {
        ScanType.link => Icons.link_rounded,
        ScanType.news => Icons.newspaper_rounded,
        ScanType.image => Icons.image_rounded,
        ScanType.qr => Icons.qr_code_rounded,
        ScanType.email => Icons.email_rounded,
        ScanType.password => Icons.password_rounded,
        ScanType.video => Icons.videocam_rounded,
      };

  String _formatDate(DateTime dt) {
    final now = DateTime.now();
    final diff = now.difference(dt);
    if (diff.inHours < 24) {
      return 'Today, ${dt.hour.toString().padLeft(2, '0')}:${dt.minute.toString().padLeft(2, '0')}';
    }
    if (diff.inDays < 2) return 'Yesterday';
    return '${dt.day}/${dt.month}/${dt.year}';
  }
}
