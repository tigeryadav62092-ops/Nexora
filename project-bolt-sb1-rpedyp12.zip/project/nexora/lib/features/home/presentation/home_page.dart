import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import '../../../core/constants/feature_accents.dart';
import '../../../core/providers/notifications_provider.dart';
import '../../../core/theme/nexora_colors.dart';
import '../../../shared/widgets/feature_card.dart';
import '../../../shared/widgets/gradient_background.dart';
import '../../../shared/widgets/nexora_logo.dart';
import '../../../shared/widgets/nexora_search_bar.dart';

class HomePage extends ConsumerStatefulWidget {
  final ValueChanged<FeatureAccent> onOpenFeature;

  const HomePage({super.key, required this.onOpenFeature});

  @override
  ConsumerState<HomePage> createState() => _HomePageState();
}

class _HomePageState extends ConsumerState<HomePage>
    with SingleTickerProviderStateMixin {
  late final AnimationController _controller;

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 700),
    )..forward();
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  Animation<double> _interval(double start, double end) {
    return CurvedAnimation(
      parent: _controller,
      curve: Interval(start, end, curve: Curves.easeOut),
    );
  }

  @override
  Widget build(BuildContext context) {
    final unreadCount = ref.watch(
      notificationsProvider.select((s) => s.unreadCount),
    );

    return GradientBackground(
      child: CustomScrollView(
        slivers: [
          SliverAppBar(
            pinned: false,
            automaticallyImplyLeading: false,
            title: const NexoraLogo(size: 36),
            actions: [
              FadeTransition(
                opacity: _interval(0.0, 0.4),
                child: IconButton(
                  icon: Badge(
                    isLabelVisible: unreadCount > 0,
                    label: Text('$unreadCount'),
                    child: const Icon(Icons.notifications_none_rounded),
                  ),
                  onPressed: () => context.push('/notifications'),
                ),
              ),
              const SizedBox(width: 4),
            ],
          ),
          SliverPadding(
            padding: const EdgeInsets.fromLTRB(20, 8, 20, 24),
            sliver: SliverList(
              delegate: SliverChildListDelegate([
                FadeTransition(
                  opacity: _interval(0.1, 0.5),
                  child: SlideTransition(
                    position: Tween<Offset>(
                      begin: const Offset(0, 0.15),
                      end: Offset.zero,
                    ).animate(_interval(0.1, 0.5)),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          'Stay protected today',
                          style: Theme.of(context).textTheme.headlineMedium,
                        ),
                        const SizedBox(height: 6),
                        Text(
                          'Run a quick scan to verify links, news, images, and more.',
                          style: TextStyle(
                            color: context.textSecondary,
                            fontSize: 14,
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
                const SizedBox(height: 20),
                FadeTransition(
                  opacity: _interval(0.2, 0.6),
                  child: const NexoraSearchBar(),
                ),
                const SizedBox(height: 24),
                FadeTransition(
                  opacity: _interval(0.3, 0.7),
                  child: Row(
                    children: [
                      Text(
                        'Security Tools',
                        style: TextStyle(
                          fontSize: 16,
                          fontWeight: FontWeight.w600,
                          color: context.textPrimary,
                        ),
                      ),
                      const Spacer(),
                      Text(
                        '${FeatureAccent.all.length} tools',
                        style: TextStyle(
                          fontSize: 13,
                          color: context.textSecondary,
                        ),
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 16),
              ]),
            ),
          ),
          SliverPadding(
            padding: const EdgeInsets.fromLTRB(20, 0, 20, 32),
            sliver: SliverGrid(
              gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                crossAxisCount: 2,
                mainAxisSpacing: 16,
                crossAxisSpacing: 16,
                childAspectRatio: 0.86,
              ),
              delegate: SliverChildBuilderDelegate(
                (context, index) {
                  final f = FeatureAccent.all[index];
                  final anim = _interval(
                    0.35 + (index * 0.05).clamp(0.0, 0.3),
                    0.35 + (index * 0.05).clamp(0.0, 0.3) + 0.3,
                  );
                  return SlideTransition(
                    position: Tween<Offset>(
                      begin: const Offset(0, 0.2),
                      end: Offset.zero,
                    ).animate(anim),
                    child: FadeTransition(
                      opacity: anim,
                      child: FeatureCard(
                        feature: f,
                        description: f.description,
                        onTap: () => widget.onOpenFeature(f),
                      ),
                    ),
                  );
                },
                childCount: FeatureAccent.all.length,
              ),
            ),
          ),
        ],
      ),
    );
  }
}
