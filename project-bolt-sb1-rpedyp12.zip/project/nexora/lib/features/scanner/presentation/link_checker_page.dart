import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../core/constants/app_colors.dart';
import '../../../core/constants/feature_accents.dart';
import '../../../core/providers/providers.dart';
import '../../../core/theme/nexora_colors.dart';
import '../../../data/models/scan_record.dart';
import '../../../shared/widgets/gradient_background.dart';
import '../../../shared/widgets/gradient_button.dart';
import '../../../shared/widgets/scan_result_card.dart';
import '../../../shared/widgets/scanner_hero_banner.dart';
import '../../../shared/widgets/shimmer_loading.dart';

class LinkCheckerPage extends ConsumerStatefulWidget {
  const LinkCheckerPage({super.key});

  @override
  ConsumerState<LinkCheckerPage> createState() => _LinkCheckerPageState();
}

class _LinkCheckerPageState extends ConsumerState<LinkCheckerPage> {
  final _url = TextEditingController();
  bool _loading = false;
  ScanRecord? _result;
  String? _error;

  @override
  void dispose() {
    _url.dispose();
    super.dispose();
  }

  Future<void> _scan() async {
    final url = _url.text.trim();
    if (url.isEmpty) return;

    setState(() {
      _loading = true;
      _result = null;
      _error = null;
    });

    try {
      final record = await ref.read(scanRunnerProvider).runLink(url);
      if (mounted) setState(() => _result = record);
    } catch (e) {
      if (mounted) setState(() => _error = e.toString());
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return GradientBackground(
      child: Column(
        children: [
          AppBar(
            leading: IconButton(
              icon: const Icon(Icons.arrow_back_rounded),
              onPressed: () => Navigator.of(context).maybePop(),
            ),
            title: const Text('Link Checker'),
          ),
          Expanded(
            child: SingleChildScrollView(
              padding: const EdgeInsets.all(24),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const ScannerHeroBanner(feature: FeatureAccent.linkChecker),
                  const SizedBox(height: 24),
                  TextField(
                    controller: _url,
                    keyboardType: TextInputType.url,
                    autocorrect: false,
                    decoration: const InputDecoration(
                      labelText: 'Paste a URL',
                      hintText: 'https://example.com',
                      prefixIcon: Icon(Icons.link_rounded),
                    ),
                  ),
                  const SizedBox(height: 16),
                  GradientButton(
                    label: 'Scan link',
                    icon: Icons.shield_rounded,
                    loading: _loading,
                    onPressed: _scan,
                  ),
                  if (_error != null) ...[
                    const SizedBox(height: 16),
                    Text(_error!, style: const TextStyle(color: AppColors.error)),
                  ],
                  if (_loading) ...[
                    const SizedBox(height: 28),
                    Container(
                      padding: const EdgeInsets.all(20),
                      decoration: BoxDecoration(
                        color: context.surface,
                        borderRadius: BorderRadius.circular(20),
                        border: Border.all(color: context.outline.withOpacity(0.5)),
                      ),
                      child: const ScanResultSkeleton(),
                    ),
                  ],
                  if (_result != null) ...[
                    const SizedBox(height: 28),
                    ScanResultCard(record: _result!),
                  ],
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}
