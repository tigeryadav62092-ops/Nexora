import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../core/constants/app_colors.dart';
import '../../../core/constants/feature_accents.dart';
import '../../../core/providers/providers.dart';
import '../../../core/theme/nexora_colors.dart';
import '../../../data/models/scan_record.dart';
import '../../../shared/widgets/gradient_background.dart';
import '../../../shared/widgets/gradient_button.dart';
import '../../../shared/widgets/scan_result_card.dart';
import '../../../shared/widgets/scanner_hero_banner.dart';
import '../../../shared/widgets/shimmer_loading.dart';

class EmailScannerPage extends ConsumerStatefulWidget {
  const EmailScannerPage({super.key});

  @override
  ConsumerState<EmailScannerPage> createState() => _EmailScannerPageState();
}

class _EmailScannerPageState extends ConsumerState<EmailScannerPage> {
  final _text = TextEditingController();
  bool _loading = false;
  ScanRecord? _result;
  String? _error;
  Set<String> _suspiciousWords = {};

  static const _flagWords = [
    'urgent', 'immediate action', 'final notice', 'account suspended',
    'verify now', 'within 24 hours', 'wire transfer', 'lottery', 'prize',
    'inheritance', 'bitcoin', 'gift card', 'refund', 'password', 'ssn',
    'social security', 'credit card', 'otp', 'pin code',
  ];

  @override
  void dispose() {
    _text.dispose();
    super.dispose();
  }

  Future<void> _analyze() async {
    final body = _text.text.trim();
    if (body.isEmpty) return;

    final lower = body.toLowerCase();
    final found = _flagWords.where(lower.contains).toSet();

    setState(() {
      _loading = true;
      _result = null;
      _error = null;
      _suspiciousWords = found;
    });

    try {
      final record = await ref.read(scanRunnerProvider).runEmail(body);
      if (mounted) setState(() => _result = record);
    } catch (e) {
      if (mounted) setState(() => _error = e.toString());
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return GradientBackground(
      child: Column(
        children: [
          AppBar(
            leading: IconButton(
              icon: const Icon(Icons.arrow_back_rounded),
              onPressed: () => Navigator.of(context).maybePop(),
            ),
            title: const Text('Email Scanner'),
          ),
          Expanded(
            child: SingleChildScrollView(
              padding: const EdgeInsets.all(24),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const ScannerHeroBanner(feature: FeatureAccent.emailScanner),
                  const SizedBox(height: 24),
                  TextField(
                    controller: _text,
                    maxLines: 8,
                    minLines: 5,
                    decoration: const InputDecoration(
                      labelText: 'Email body',
                      hintText: 'Paste the email content here...',
                      alignLabelWithHint: true,
                      prefixIcon: Padding(
                        padding: EdgeInsets.only(bottom: 90),
                        child: Icon(Icons.email_rounded),
                      ),
                    ),
                  ),
                  if (_suspiciousWords.isNotEmpty) ...[
                    const SizedBox(height: 16),
                    _HighlightedWords(words: _suspiciousWords),
                  ],
                  const SizedBox(height: 16),
                  GradientButton(
                    label: 'Analyze email',
                    icon: Icons.shield_rounded,
                    loading: _loading,
                    onPressed: _analyze,
                  ),
                  if (_error != null) ...[
                    const SizedBox(height: 16),
                    Text(_error!, style: const TextStyle(color: AppColors.error)),
                  ],
                  if (_loading) ...[
                    const SizedBox(height: 28),
                    Container(
                      padding: const EdgeInsets.all(20),
                      decoration: BoxDecoration(
                        color: context.surface,
                        borderRadius: BorderRadius.circular(20),
                        border: Border.all(color: context.outline.withOpacity(0.5)),
                      ),
                      child: const ScanResultSkeleton(),
                    ),
                  ],
                  if (_result != null) ...[
                    const SizedBox(height: 28),
                    ScanResultCard(record: _result!),
                  ],
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _HighlightedWords extends StatelessWidget {
  final Set<String> words;
  const _HighlightedWords({required this.words});

  @override
  Widget build(BuildContext context) {
    return Wrap(
      spacing: 8,
      runSpacing: 8,
      children: words.map((w) {
        return Container(
          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
          decoration: BoxDecoration(
            color: AppColors.error.withOpacity(0.15),
            borderRadius: BorderRadius.circular(20),
            border: Border.all(color: AppColors.error.withOpacity(0.4)),
          ),
          child: Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              const Icon(Icons.flag_rounded,
                  color: AppColors.error, size: 14),
              const SizedBox(width: 6),
              Text(
                w,
                style: const TextStyle(
                  color: AppColors.error,
                  fontSize: 12,
                  fontWeight: FontWeight.w600,
                ),
              ),
            ],
          ),
        );
      }).toList(),
    );
  }
}
