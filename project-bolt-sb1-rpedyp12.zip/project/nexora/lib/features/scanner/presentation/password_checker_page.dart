import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../core/constants/app_colors.dart';
import '../../../core/constants/feature_accents.dart';
import '../../../core/providers/providers.dart';
import '../../../core/theme/nexora_colors.dart';
import '../../../data/models/scan_record.dart';
import '../../../shared/widgets/gradient_background.dart';
import '../../../shared/widgets/gradient_button.dart';
import '../../../shared/widgets/scan_result_card.dart';
import '../../../shared/widgets/scanner_hero_banner.dart';
import '../../../shared/widgets/shimmer_loading.dart';

class PasswordCheckerPage extends ConsumerStatefulWidget {
  const PasswordCheckerPage({super.key});

  @override
  ConsumerState<PasswordCheckerPage> createState() =>
      _PasswordCheckerPageState();
}

class _PasswordCheckerPageState extends ConsumerState<PasswordCheckerPage> {
  final _password = TextEditingController();
  bool _obscure = true;
  bool _loading = false;
  ScanRecord? _result;
  String? _error;
  int _liveStrength = 0;

  @override
  void initState() {
    super.initState();
    _password.addListener(_updateLiveStrength);
  }

  @override
  void dispose() {
    _password.removeListener(_updateLiveStrength);
    _password.dispose();
    super.dispose();
  }

  void _updateLiveStrength() {
    final p = _password.text;
    int s = 0;
    if (p.length >= 8) s++;
    if (p.length >= 12) s++;
    if (p.contains(RegExp(r'[A-Z]')) && p.contains(RegExp(r'[a-z]'))) s++;
    if (p.contains(RegExp(r'[0-9]'))) s++;
    if (p.contains(RegExp(r'[^a-zA-Z0-9]'))) s++;
    if (s > 4) s = 4;
    setState(() => _liveStrength = p.isEmpty ? 0 : s);
  }

  Future<void> _check() async {
    final pwd = _password.text;
    if (pwd.isEmpty) return;

    setState(() {
      _loading = true;
      _result = null;
      _error = null;
    });

    try {
      final record = await ref.read(scanRunnerProvider).runPassword(pwd);
      if (mounted) setState(() => _result = record);
    } catch (e) {
      if (mounted) setState(() => _error = e.toString());
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return GradientBackground(
      child: Column(
        children: [
          AppBar(
            leading: IconButton(
              icon: const Icon(Icons.arrow_back_rounded),
              onPressed: () => Navigator.of(context).maybePop(),
            ),
            title: const Text('Password Strength'),
          ),
          Expanded(
            child: SingleChildScrollView(
              padding: const EdgeInsets.all(24),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const ScannerHeroBanner(
                    feature: FeatureAccent.passwordChecker,
                    subtitle:
                        'Check how strong your password is and get tips to improve it.',
                  ),
                  const SizedBox(height: 24),
                  TextField(
                    controller: _password,
                    obscureText: _obscure,
                    decoration: InputDecoration(
                      labelText: 'Enter password',
                      prefixIcon: const Icon(Icons.lock_outline),
                      suffixIcon: IconButton(
                        icon: Icon(
                          _obscure
                              ? Icons.visibility_off_outlined
                              : Icons.visibility_outlined,
                        ),
                        onPressed: () =>
                            setState(() => _obscure = !_obscure),
                      ),
                    ),
                  ),
                  const SizedBox(height: 16),
                  _StrengthMeter(strength: _liveStrength),
                  const SizedBox(height: 20),
                  GradientButton(
                    label: 'Check strength',
                    icon: Icons.shield_rounded,
                    loading: _loading,
                    onPressed: _check,
                  ),
                  if (_error != null) ...[
                    const SizedBox(height: 16),
                    Text(_error!, style: const TextStyle(color: AppColors.error)),
                  ],
                  if (_loading) ...[
                    const SizedBox(height: 28),
                    Container(
                      padding: const EdgeInsets.all(20),
                      decoration: BoxDecoration(
                        color: context.surface,
                        borderRadius: BorderRadius.circular(20),
                        border: Border.all(color: context.outline.withOpacity(0.5)),
                      ),
                      child: const ScanResultSkeleton(),
                    ),
                  ],
                  if (_result != null) ...[
                    const SizedBox(height: 28),
                    ScanResultCard(record: _result!),
                  ],
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _StrengthMeter extends StatelessWidget {
  final int strength;
  const _StrengthMeter({required this.strength});

  @override
  Widget build(BuildContext context) {
    final labels = ['Empty', 'Weak', 'Fair', 'Good', 'Strong'];
    final colors = [
      context.outline,
      AppColors.error,
      AppColors.warning,
      const Color(0xFF60A5FA),
      AppColors.success,
    ];

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          children: List.generate(4, (i) {
            final active = i < strength;
            return Expanded(
              child: AnimatedContainer(
                duration: const Duration(milliseconds: 300),
                margin: EdgeInsets.only(right: i < 3 ? 6 : 0),
                height: 8,
                decoration: BoxDecoration(
                  color: active
                      ? colors[strength]
                      : context.outline.withOpacity(0.3),
                  borderRadius: BorderRadius.circular(4),
                ),
              ),
            );
          }),
        ),
        const SizedBox(height: 8),
        AnimatedSwitcher(
          duration: const Duration(milliseconds: 200),
          child: Text(
            labels[strength.clamp(0, 4)],
            key: ValueKey(strength),
            style: TextStyle(
              fontSize: 13,
              fontWeight: FontWeight.w600,
              color: colors[strength.clamp(0, 4)],
            ),
          ),
        ),
      ],
    );
  }
}
