import 'dart:io';

import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:image_picker/image_picker.dart';
import 'package:video_player/video_player.dart';

import '../../../core/constants/app_colors.dart';
import '../../../core/constants/feature_accents.dart';
import '../../../core/providers/providers.dart';
import '../../../core/theme/nexora_colors.dart';
import '../../../data/models/scan_record.dart';
import '../../../shared/widgets/gradient_background.dart';
import '../../../shared/widgets/gradient_button.dart';
import '../../../shared/widgets/scan_result_card.dart';
import '../../../shared/widgets/scanner_hero_banner.dart';
import '../../../shared/widgets/shimmer_loading.dart';

class VideoScannerPage extends ConsumerStatefulWidget {
  const VideoScannerPage({super.key});

  @override
  ConsumerState<VideoScannerPage> createState() => _VideoScannerPageState();
}

class _VideoScannerPageState extends ConsumerState<VideoScannerPage> {
  final _picker = ImagePicker();
  XFile? _video;
  VideoPlayerController? _videoController;
  bool _loading = false;
  ScanRecord? _result;
  String? _error;

  @override
  void dispose() {
    _videoController?.dispose();
    super.dispose();
  }

  Future<void> _pickVideo() async {
    try {
      final picked = await _picker.pickVideo(source: ImageSource.gallery);
      if (picked != null) {
        final controller = VideoPlayerController.file(File(picked.path));
        await controller.initialize();
        controller.setLooping(true);
        setState(() {
          _video = picked;
          _videoController = controller;
        });
      }
    } catch (e) {
      if (mounted) setState(() => _error = e.toString());
    }
  }

  Future<void> _analyze() async {
    if (_video == null) return;
    setState(() {
      _loading = true;
      _result = null;
      _error = null;
    });

    try {
      final record = await ref.read(scanRunnerProvider).runVideo(_video!.path);
      if (mounted) setState(() => _result = record);
    } catch (e) {
      if (mounted) setState(() => _error = e.toString());
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return GradientBackground(
      child: Column(
        children: [
          AppBar(
            leading: IconButton(
              icon: const Icon(Icons.arrow_back_rounded),
              onPressed: () => Navigator.of(context).maybePop(),
            ),
            title: const Text('Video Deepfake Scanner'),
          ),
          Expanded(
            child: SingleChildScrollView(
              padding: const EdgeInsets.all(24),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const ScannerHeroBanner(
                    feature: FeatureAccent.videoScanner,
                    subtitle:
                        'Upload a video to detect deepfake manipulation and synthetic content.',
                  ),
                  const SizedBox(height: 24),
                  GestureDetector(
                    onTap: _pickVideo,
                    child: AnimatedContainer(
                      duration: const Duration(milliseconds: 200),
                      width: double.infinity,
                      height: 240,
                      decoration: BoxDecoration(
                        color: context.surfaceVariant,
                        borderRadius: BorderRadius.circular(20),
                        border: Border.all(
                          color: _video != null
                              ? AppColors.primaryBlueLight.withOpacity(0.5)
                              : context.outline,
                        ),
                      ),
                      child: _videoController == null ||
                              !_videoController!.value.isInitialized
                          ? Column(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                Icon(Icons.video_library_outlined,
                                    size: 48, color: context.textSecondary),
                                const SizedBox(height: 12),
                                Text(
                                  'Upload video',
                                  style: TextStyle(
                                    color: context.textSecondary,
                                    fontWeight: FontWeight.w600,
                                  ),
                                ),
                              ],
                            )
                          : ClipRRect(
                              borderRadius: BorderRadius.circular(20),
                              child: Stack(
                                fit: StackFit.expand,
                                children: [
                                  AspectRatio(
                                    aspectRatio:
                                        _videoController!.value.aspectRatio,
                                    child: VideoPlayer(_videoController!),
                                  ),
                                  Center(
                                    child: GestureDetector(
                                      onTap: () {
                                        setState(() {
                                          _videoController!.value.isPlaying
                                              ? _videoController!.pause()
                                              : _videoController!.play();
                                        });
                                      },
                                      child: Container(
                                        width: 56,
                                        height: 56,
                                        decoration: BoxDecoration(
                                          color: Colors.black54,
                                          shape: BoxShape.circle,
                                        ),
                                        child: Icon(
                                          _videoController!.value.isPlaying
                                              ? Icons.pause_rounded
                                              : Icons.play_arrow_rounded,
                                          color: Colors.white,
                                          size: 32,
                                        ),
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                    ),
                  ),
                  const SizedBox(height: 16),
                  GradientButton(
                    label: 'Analyze video',
                    icon: Icons.search_rounded,
                    loading: _loading,
                    onPressed: _video == null ? null : _analyze,
                  ),
                  if (_error != null) ...[
                    const SizedBox(height: 16),
                    Text(_error!, style: const TextStyle(color: AppColors.error)),
                  ],
                  if (_loading) ...[
                    const SizedBox(height: 28),
                    Container(
                      padding: const EdgeInsets.all(20),
                      decoration: BoxDecoration(
                        color: context.surface,
                        borderRadius: BorderRadius.circular(20),
                        border: Border.all(color: context.outline.withOpacity(0.5)),
                      ),
                      child: const ScanResultSkeleton(),
                    ),
                  ],
                  if (_result != null) ...[
                    const SizedBox(height: 28),
                    ScanResultCard(record: _result!),
                  ],
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}
