import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:image_picker/image_picker.dart';
import 'dart:io';

import '../../../core/constants/app_colors.dart';
import '../../../core/constants/feature_accents.dart';
import '../../../core/providers/providers.dart';
import '../../../core/theme/nexora_colors.dart';
import '../../../data/models/scan_record.dart';
import '../../../shared/widgets/gradient_background.dart';
import '../../../shared/widgets/gradient_button.dart';
import '../../../shared/widgets/scan_result_card.dart';
import '../../../shared/widgets/scanner_hero_banner.dart';
import '../../../shared/widgets/shimmer_loading.dart';

class ImageScannerPage extends ConsumerStatefulWidget {
  const ImageScannerPage({super.key});

  @override
  ConsumerState<ImageScannerPage> createState() => _ImageScannerPageState();
}

class _ImageScannerPageState extends ConsumerState<ImageScannerPage> {
  final _picker = ImagePicker();
  XFile? _image;
  bool _loading = false;
  ScanRecord? _result;
  String? _error;

  Future<void> _pickImage() async {
    try {
      final picked = await _picker.pickImage(source: ImageSource.gallery);
      if (picked != null) setState(() => _image = picked);
    } catch (e) {
      if (mounted) setState(() => _error = e.toString());
    }
  }

  Future<void> _analyze() async {
    if (_image == null) return;
    setState(() {
      _loading = true;
      _result = null;
      _error = null;
    });

    try {
      final record = await ref.read(scanRunnerProvider).runImage(_image!.path);
      if (mounted) setState(() => _result = record);
    } catch (e) {
      if (mounted) setState(() => _error = e.toString());
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return GradientBackground(
      child: Column(
        children: [
          AppBar(
            leading: IconButton(
              icon: const Icon(Icons.arrow_back_rounded),
              onPressed: () => Navigator.of(context).maybePop(),
            ),
            title: const Text('Image Scanner'),
          ),
          Expanded(
            child: SingleChildScrollView(
              padding: const EdgeInsets.all(24),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const ScannerHeroBanner(feature: FeatureAccent.imageScanner),
                  const SizedBox(height: 24),
                  GestureDetector(
                    onTap: _pickImage,
                    child: AnimatedContainer(
                      duration: const Duration(milliseconds: 200),
                      width: double.infinity,
                      height: 220,
                      decoration: BoxDecoration(
                        color: context.surfaceVariant,
                        borderRadius: BorderRadius.circular(20),
                        border: Border.all(
                          color: _image != null
                              ? AppColors.primaryBlueLight.withOpacity(0.5)
                              : context.outline,
                        ),
                      ),
                      child: _image == null
                          ? Column(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                Icon(Icons.add_photo_alternate_outlined,
                                    size: 48, color: context.textSecondary),
                                const SizedBox(height: 12),
                                Text(
                                  'Upload image',
                                  style: TextStyle(
                                    color: context.textSecondary,
                                    fontWeight: FontWeight.w600,
                                  ),
                                ),
                              ],
                            )
                          : ClipRRect(
                              borderRadius: BorderRadius.circular(20),
                              child: Image.file(
                                File(_image!.path),
                                fit: BoxFit.cover,
                              ),
                            ),
                    ),
                  ),
                  const SizedBox(height: 16),
                  GradientButton(
                    label: 'Analyze image',
                    icon: Icons.search_rounded,
                    loading: _loading,
                    onPressed: _image == null ? null : _analyze,
                  ),
                  if (_error != null) ...[
                    const SizedBox(height: 16),
                    Text(_error!, style: const TextStyle(color: AppColors.error)),
                  ],
                  if (_loading) ...[
                    const SizedBox(height: 28),
                    Container(
                      padding: const EdgeInsets.all(20),
                      decoration: BoxDecoration(
                        color: context.surface,
                        borderRadius: BorderRadius.circular(20),
                        border: Border.all(color: context.outline.withOpacity(0.5)),
                      ),
                      child: const ScanResultSkeleton(),
                    ),
                  ],
                  if (_result != null) ...[
                    const SizedBox(height: 28),
                    ScanResultCard(record: _result!),
                  ],
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}
