import 'package:flutter/material.dart';

import '../core/theme/nexora_colors.dart';

/// A single shimmering placeholder box.
class ShimmerBox extends StatelessWidget {
  final double width;
  final double height;
  final double radius;

  const ShimmerBox({
    super.key,
    required this.width,
    required this.height,
    this.radius = 8,
  });

  @override
  Widget build(BuildContext context) {
    return ShimmerLoading(
      child: Container(
        width: width,
        height: height,
        decoration: BoxDecoration(
          color: context.surfaceVariant,
          borderRadius: BorderRadius.circular(radius),
        ),
      ),
    );
  }
}

/// Wraps a child in an animated shimmer gradient sweep.
class ShimmerLoading extends StatefulWidget {
  final Widget child;

  const ShimmerLoading({super.key, required this.child});

  @override
  State<ShimmerLoading> createState() => _ShimmerLoadingState();
}

class _ShimmerLoadingState extends State<ShimmerLoading>
    with SingleTickerProviderStateMixin {
  late final AnimationController _controller;

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1200),
    )..repeat();
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final base = isDark ? const Color(0xFF1A2238) : const Color(0xFFE2E8F0);
    final highlight = isDark ? const Color(0xFF2A3450) : const Color(0xFFF8FAFC);

    return AnimatedBuilder(
      animation: _controller,
      builder: (context, child) {
        return ShaderMask(
          blendMode: BlendMode.srcATop,
          shaderCallback: (bounds) {
            final slide = (bounds.width + 60) * _controller.value - 30;
            return LinearGradient(
              begin: Alignment.topLeft,
              end: Alignment.topRight,
              colors: [base, highlight, base],
              stops: const [0.0, 0.5, 1.0],
            ).createShader(
              Rect.fromLTWH(slide, 0, bounds.width, bounds.height),
            );
          },
          child: child,
        );
      },
      child: widget.child,
    );
  }
}

/// A full skeleton placeholder that mimics the [ScanResultCard] layout.
class ScanResultSkeleton extends StatelessWidget {
  const ScanResultSkeleton({super.key});

  @override
  Widget build(BuildContext context) {
    return ShimmerLoading(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              ShimmerBox(width: 28, height: 28, radius: 14),
              const SizedBox(width: 12),
              ShimmerBox(width: 120, height: 18, radius: 6),
              const Spacer(),
              ShimmerBox(width: 80, height: 24, radius: 12),
            ],
          ),
          const SizedBox(height: 16),
          ShimmerBox(width: double.infinity, height: 14, radius: 6),
          const SizedBox(height: 8),
          FractionallySizedBox(
            widthFactor: 0.7,
            alignment: Alignment.centerLeft,
            child: ShimmerBox(width: double.infinity, height: 14, radius: 6),
          ),
          const SizedBox(height: 20),
          ShimmerBox(width: 80, height: 14, radius: 6),
          const SizedBox(height: 12),
          for (int i = 0; i < 3; i++) ...[
            Row(
              children: [
                ShimmerBox(width: 20, height: 20, radius: 10),
                const SizedBox(width: 10),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      ShimmerBox(width: 140, height: 14, radius: 6),
                      const SizedBox(height: 6),
                      ShimmerBox(width: double.infinity, height: 12, radius: 6),
                    ],
                  ),
                ),
              ],
            ),
            if (i < 2) const SizedBox(height: 14),
          ],
        ],
      ),
    );
  }
}
