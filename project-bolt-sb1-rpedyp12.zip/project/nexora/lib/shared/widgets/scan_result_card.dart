import 'package:flutter/material.dart';

import '../../../core/constants/app_colors.dart';
import '../../../core/theme/nexora_colors.dart';
import '../../../data/models/scan_record.dart';

/// Shared result card shown by every scanner page after analysis completes.
/// Features an entrance animation and verdict-colored glow.
class ScanResultCard extends StatefulWidget {
  final ScanRecord record;

  const ScanResultCard({super.key, required this.record});

  @override
  State<ScanResultCard> createState() => _ScanResultCardState();
}

class _ScanResultCardState extends State<ScanResultCard>
    with SingleTickerProviderStateMixin {
  late final AnimationController _controller;
  late final Animation<double> _fade;
  late final Animation<Offset> _slide;

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 500),
    );
    _fade = Tween(begin: 0.0, end: 1.0).animate(
      CurvedAnimation(parent: _controller, curve: Curves.easeOut),
    );
    _slide = Tween<Offset>(
      begin: const Offset(0, 0.2),
      end: Offset.zero,
    ).animate(
      CurvedAnimation(parent: _controller, curve: Curves.easeOutCubic),
    );
    _controller.forward();
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final verdictColor = _verdictColor(widget.record.verdict);
    return FadeTransition(
      opacity: _fade,
      child: SlideTransition(
        position: _slide,
        child: Container(
          padding: const EdgeInsets.all(20),
          decoration: BoxDecoration(
            color: context.surface,
            borderRadius: BorderRadius.circular(20),
            border: Border.all(color: verdictColor.withOpacity(0.3)),
            boxShadow: [
              BoxShadow(
                color: verdictColor.withOpacity(0.12),
                blurRadius: 20,
                offset: const Offset(0, 8),
              ),
            ],
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  Container(
                    width: 44,
                    height: 44,
                    decoration: BoxDecoration(
                      color: verdictColor.withOpacity(0.15),
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: Icon(widget.record.verdict.icon,
                        color: verdictColor, size: 26),
                  ),
                  const SizedBox(width: 12),
                  Text(
                    widget.record.verdict.label,
                    style: TextStyle(
                      fontSize: 18,
                      fontWeight: FontWeight.bold,
                      color: verdictColor,
                    ),
                  ),
                  const Spacer(),
                  _ConfidenceBadge(confidence: widget.record.confidence),
                ],
              ),
              if (widget.record.summary != null) ...[
                const SizedBox(height: 14),
                Text(
                  widget.record.summary!,
                  style: TextStyle(
                      fontSize: 13,
                      color: context.textSecondary,
                      height: 1.5),
                ),
              ],
              const SizedBox(height: 12),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
                decoration: BoxDecoration(
                  color: context.surfaceVariant,
                  borderRadius: BorderRadius.circular(8),
                ),
                child: Text(
                  widget.record.input,
                  maxLines: 2,
                  overflow: TextOverflow.ellipsis,
                  style: TextStyle(
                      fontSize: 12, color: context.textSecondary),
                ),
              ),
              if (widget.record.signals.isNotEmpty) ...[
                const Divider(height: 28),
                Text(
                  'Signals',
                  style: TextStyle(
                    fontSize: 13,
                    fontWeight: FontWeight.w600,
                    color: context.textSecondary,
                  ),
                ),
                const SizedBox(height: 12),
                for (final s in widget.record.signals) ...[
                  _SignalRow(signal: s),
                  if (s != widget.record.signals.last)
                    const SizedBox(height: 12),
                ],
              ],
            ],
          ),
        ),
      ),
    );
  }

  Color _verdictColor(ScanVerdict v) => switch (v) {
        ScanVerdict.safe => AppColors.success,
        ScanVerdict.suspicious => AppColors.warning,
        ScanVerdict.dangerous => AppColors.error,
      };
}

extension on ScanVerdict {
  IconData get icon => switch (this) {
        ScanVerdict.safe => Icons.verified_rounded,
        ScanVerdict.suspicious => Icons.warning_amber_rounded,
        ScanVerdict.dangerous => Icons.dangerous_rounded,
      };
}

class _ConfidenceBadge extends StatelessWidget {
  final int confidence;
  const _ConfidenceBadge({required this.confidence});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
      decoration: BoxDecoration(
        color: context.surfaceVariant,
        borderRadius: BorderRadius.circular(20),
      ),
      child: Text(
        '$confidence% confidence',
        style: TextStyle(
          fontSize: 12,
          fontWeight: FontWeight.w600,
          color: context.textSecondary,
        ),
      ),
    );
  }
}

class _SignalRow extends StatelessWidget {
  final ScanSignal signal;
  const _SignalRow({required this.signal});

  @override
  Widget build(BuildContext context) {
    return Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Icon(
          signal.passed ? Icons.check_circle_rounded : Icons.cancel_rounded,
          color: signal.passed ? AppColors.success : AppColors.error,
          size: 20,
        ),
        const SizedBox(width: 10),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                signal.label,
                style: TextStyle(
                  fontSize: 14,
                  fontWeight: FontWeight.w500,
                  color: context.textPrimary,
                ),
              ),
              const SizedBox(height: 2),
              Text(
                signal.detail,
                style: TextStyle(
                  fontSize: 12,
                  color: context.textSecondary,
                  height: 1.4,
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }
}
