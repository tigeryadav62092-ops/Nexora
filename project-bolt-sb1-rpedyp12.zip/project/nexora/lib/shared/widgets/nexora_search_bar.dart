import 'package:flutter/material.dart';

import '../core/constants/app_colors.dart';
import '../core/theme/nexora_colors.dart';

/// A search field styled to match the Nexora premium theme.
class NexoraSearchBar extends StatelessWidget {
  final ValueChanged<String>? onChanged;
  final String hint;

  const NexoraSearchBar({
    super.key,
    this.onChanged,
    this.hint = 'Search tools, scans, reports...',
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        color: context.surfaceVariant,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: context.outline.withOpacity(0.6)),
      ),
      child: TextField(
        onChanged: onChanged,
        style: TextStyle(color: context.textPrimary, fontSize: 15),
        decoration: InputDecoration(
          hintText: hint,
          hintStyle: TextStyle(color: context.textSecondary),
          prefixIcon:
              Icon(Icons.search_rounded, color: context.textSecondary),
          suffixIcon:
              Icon(Icons.mic_rounded, color: context.textSecondary),
          border: InputBorder.none,
          contentPadding: const EdgeInsets.symmetric(vertical: 16),
        ),
      ),
    );
  }
}
