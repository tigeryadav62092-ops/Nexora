import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import '../../core/constants/app_colors.dart';
import '../../core/constants/feature_accents.dart';
import '../../core/providers/providers.dart';
import '../../core/theme/nexora_colors.dart';
import '../../features/history/presentation/history_page.dart';
import '../../features/home/presentation/home_page.dart';
import '../../features/profile/presentation/profile_page.dart';
import '../../features/settings/presentation/settings_page.dart';
import 'gradient_background.dart';

const _featureRoutes = <FeatureAccent, String>{
  FeatureAccent.linkChecker: '/scanner/link',
  FeatureAccent.fakeNews: '/scanner/news',
  FeatureAccent.imageScanner: '/scanner/image',
  FeatureAccent.emailScanner: '/scanner/email',
  FeatureAccent.aiAssistant: '/scanner/ai',
  FeatureAccent.qrScanner: '/scanner/qr',
  FeatureAccent.videoScanner: '/scanner/video',
  FeatureAccent.passwordChecker: '/scanner/password',
};

class MainShell extends ConsumerStatefulWidget {
  const MainShell({super.key});

  @override
  ConsumerState<MainShell> createState() => _MainShellState();
}

class _MainShellState extends ConsumerState<MainShell> {
  int _index = 0;
  late final List<Widget> _pages;

  @override
  void initState() {
    super.initState();
    _pages = [
      HomePage(onOpenFeature: _openFeature),
      const HistoryPage(),
      _ScannerHubPage(onOpenFeature: _openFeature),
      const ProfilePage(),
      const SettingsPage(),
    ];
  }

  void _openFeature(FeatureAccent feature) {
    final route = _featureRoutes[feature];
    if (route != null) context.push(route);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: IndexedStack(
        index: _index,
        children: _pages,
      ),
      bottomNavigationBar: NavigationBar(
        selectedIndex: _index,
        onDestinationSelected: (i) => setState(() => _index = i),
        destinations: const [
          NavigationDestination(
            icon: Icon(Icons.home_outlined),
            selectedIcon: Icon(Icons.home_rounded),
            label: 'Home',
          ),
          NavigationDestination(
            icon: Icon(Icons.history_rounded),
            selectedIcon: Icon(Icons.history_rounded),
            label: 'History',
          ),
          NavigationDestination(
            icon: Icon(Icons.qr_code_scanner_rounded),
            selectedIcon: Icon(Icons.qr_code_scanner_rounded),
            label: 'Scanner',
          ),
          NavigationDestination(
            icon: Icon(Icons.person_outline_rounded),
            selectedIcon: Icon(Icons.person_rounded),
            label: 'Profile',
          ),
          NavigationDestination(
            icon: Icon(Icons.settings_outlined),
            selectedIcon: Icon(Icons.settings_rounded),
            label: 'Settings',
          ),
        ],
      ),
    );
  }
}

class _ScannerHubPage extends StatelessWidget {
  final ValueChanged<FeatureAccent> onOpenFeature;

  const _ScannerHubPage({required this.onOpenFeature});

  @override
  Widget build(BuildContext context) {
    return GradientBackground(
      child: CustomScrollView(
        slivers: [
          SliverAppBar(
            automaticallyImplyLeading: false,
            title: const Text('Scanner'),
          ),
          SliverPadding(
            padding: const EdgeInsets.all(20),
            sliver: SliverList(
              delegate: SliverChildListDelegate([
                Text(
                  'Pick a tool to start a scan',
                  style: TextStyle(color: context.textSecondary),
                ),
                const SizedBox(height: 20),
                for (int i = 0; i < FeatureAccent.all.length; i++) ...[
                  TweenAnimationBuilder<double>(
                    tween: Tween(begin: 0.0, end: 1.0),
                    duration: Duration(
                      milliseconds: 250 + (i * 50).clamp(0, 200),
                    ),
                    curve: Curves.easeOut,
                    builder: (context, value, child) {
                      return Opacity(
                        opacity: value,
                        child: Transform.translate(
                          offset: Offset(0, 16 * (1 - value)),
                          child: child,
                        ),
                      );
                    },
                    child: _ScannerTile(
                      feature: FeatureAccent.all[i],
                      onTap: () => onOpenFeature(FeatureAccent.all[i]),
                    ),
                  ),
                  const SizedBox(height: 8),
                ],
              ]),
            ),
          ),
        ],
      ),
    );
  }
}

class _ScannerTile extends StatelessWidget {
  final FeatureAccent feature;
  final VoidCallback onTap;

  const _ScannerTile({required this.feature, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.only(bottom: 4),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [context.surface, context.surfaceVariant],
        ),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: context.outline.withOpacity(0.5)),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.04),
            blurRadius: 10,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: ListTile(
        contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
        leading: Container(
          width: 44,
          height: 44,
          decoration: BoxDecoration(
            gradient: LinearGradient(colors: [feature.start, feature.end]),
            borderRadius: BorderRadius.circular(12),
            boxShadow: [
              BoxShadow(
                color: feature.start.withOpacity(0.3),
                blurRadius: 10,
                offset: const Offset(0, 4),
              ),
            ],
          ),
          child: Icon(feature.icon, color: Colors.white, size: 22),
        ),
        title: Text(
          feature.name,
          style: TextStyle(
            fontWeight: FontWeight.w600,
            color: context.textPrimary,
          ),
        ),
        subtitle: Text(
          feature.description,
          maxLines: 1,
          overflow: TextOverflow.ellipsis,
          style: TextStyle(color: context.textSecondary),
        ),
        trailing:
            Icon(Icons.chevron_right_rounded, color: context.textSecondary),
        onTap: onTap,
      ),
    );
  }
}
