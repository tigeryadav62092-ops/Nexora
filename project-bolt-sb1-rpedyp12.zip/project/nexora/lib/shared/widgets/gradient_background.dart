import 'package:flutter/material.dart';

import '../core/constants/app_colors.dart';
import '../core/theme/nexora_colors.dart';

/// Paints the shared premium gradient background used across all screens.
/// Adapts to the current theme brightness.
class GradientBackground extends StatelessWidget {
  final Widget child;
  final bool showTopGlow;

  const GradientBackground({
    super.key,
    required this.child,
    this.showTopGlow = true,
  });

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;

    return Container(
      decoration: BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
          colors: isDark
              ? const [
                  Color(0xFF0A0E1A),
                  Color(0xFF0F1424),
                  AppColors.darkBackground,
                ]
              : const [
                  Color(0xFFF5F7FB),
                  Color(0xFFEEF2F8),
                  Color(0xFFE8EEF6),
                ],
        ),
      ),
      child: Stack(
        children: [
          if (showTopGlow)
            Positioned(
              top: -120,
              left: -80,
              right: -80,
              height: 320,
              child: Container(
                decoration: BoxDecoration(
                  gradient: RadialGradient(
                    center: Alignment.topCenter,
                    radius: 0.9,
                    colors: [
                      AppColors.primaryBlue.withOpacity(0.35),
                      AppColors.primaryPurple.withOpacity(0.15),
                      Colors.transparent,
                    ],
                  ),
                ),
              ),
            ),
          SafeArea(child: child),
        ],
      ),
    );
  }
}
