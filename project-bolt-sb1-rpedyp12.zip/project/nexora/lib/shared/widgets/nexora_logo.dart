import 'package:flutter/material.dart';

import '../core/constants/app_colors.dart';

/// Nexora wordmark + glyph used in the app bar and splash.
class NexoraLogo extends StatelessWidget {
  final double size;
  final bool showWordmark;
  final Color? color;

  const NexoraLogo({
    super.key,
    this.size = 40,
    this.showWordmark = true,
    this.color,
  });

  @override
  Widget build(BuildContext context) {
    final mark = Container(
      width: size,
      height: size,
      decoration: BoxDecoration(
        gradient: AppColors.brandGradient,
        borderRadius: BorderRadius.circular(size * 0.28),
        boxShadow: [
          BoxShadow(
            color: AppColors.primaryBlue.withOpacity(0.45),
            blurRadius: 18,
            offset: const Offset(0, 6),
          ),
        ],
      ),
      child: Center(
        child: Icon(
          Icons.shield_rounded,
          color: Colors.white,
          size: size * 0.55,
        ),
      ),
    );

    if (!showWordmark) return mark;

    return Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        mark,
        const SizedBox(width: 10),
        Text(
          'Nexora',
          style: TextStyle(
            fontSize: size * 0.5,
            fontWeight: FontWeight.bold,
            color: color ?? AppColors.darkTextPrimary,
            letterSpacing: 0.5,
          ),
        ),
      ],
    );
  }
}
