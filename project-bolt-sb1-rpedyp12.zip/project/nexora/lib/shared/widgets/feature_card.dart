import 'package:flutter/material.dart';

import '../core/constants/feature_accents.dart';
import '../core/theme/nexora_colors.dart';

/// A large, tappable feature card on the home dashboard with glassmorphism,
/// gradient icon glow, and press/hover micro-interactions.
class FeatureCard extends StatefulWidget {
  final FeatureAccent feature;
  final String description;
  final VoidCallback onTap;

  const FeatureCard({
    super.key,
    required this.feature,
    required this.description,
    required this.onTap,
  });

  @override
  State<FeatureCard> createState() => _FeatureCardState();
}

class _FeatureCardState extends State<FeatureCard>
    with SingleTickerProviderStateMixin {
  bool _hover = false;
  bool _pressed = false;

  @override
  Widget build(BuildContext context) {
    final f = widget.feature;
    final isDark = Theme.of(context).brightness == Brightness.dark;

    return MouseRegion(
      onEnter: (_) => setState(() => _hover = true),
      onExit: (_) => setState(() => _hover = false),
      child: GestureDetector(
        onTapDown: (_) => setState(() => _pressed = true),
        onTapUp: (_) => setState(() => _pressed = false),
        onTapCancel: () => setState(() => _pressed = false),
        onTap: widget.onTap,
        child: AnimatedScale(
          scale: _pressed ? 0.96 : 1.0,
          duration: const Duration(milliseconds: 150),
          curve: Curves.easeOut,
          child: AnimatedContainer(
            duration: const Duration(milliseconds: 280),
            curve: Curves.easeOut,
            transform: Matrix4.translationValues(0, _hover ? -6 : 0, 0),
            padding: const EdgeInsets.all(20),
            decoration: BoxDecoration(
              gradient: LinearGradient(
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
                colors: isDark
                    ? [context.surface, context.surfaceVariant]
                    : [context.surface, context.surface.withOpacity(0.96)],
              ),
              borderRadius: BorderRadius.circular(22),
              border: Border.all(
                color: _hover
                    ? f.start.withOpacity(0.6)
                    : (isDark
                        ? Colors.white.withOpacity(0.08)
                        : Colors.black.withOpacity(0.06)),
                width: 1.4,
              ),
              boxShadow: [
                BoxShadow(
                  color: Colors.black.withOpacity(isDark ? 0.3 : 0.04),
                  blurRadius: 16,
                  offset: const Offset(0, 6),
                ),
                if (_hover)
                  BoxShadow(
                    color: f.start.withOpacity(0.2),
                    blurRadius: 24,
                    offset: const Offset(0, 10),
                  ),
              ],
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                AnimatedContainer(
                  duration: const Duration(milliseconds: 280),
                  width: 52,
                  height: 52,
                  decoration: BoxDecoration(
                    gradient: LinearGradient(
                      begin: Alignment.topLeft,
                      end: Alignment.bottomRight,
                      colors: [f.start, f.end],
                    ),
                    borderRadius: BorderRadius.circular(14),
                    boxShadow: [
                      BoxShadow(
                        color: f.start.withOpacity(_hover ? 0.5 : 0.35),
                        blurRadius: _hover ? 16 : 10,
                        offset: const Offset(0, 4),
                      ),
                    ],
                  ),
                  child: Icon(f.icon, color: Colors.white, size: 26),
                ),
                const SizedBox(height: 16),
                Text(
                  f.name,
                  style: TextStyle(
                    fontSize: 17,
                    fontWeight: FontWeight.w600,
                    color: context.textPrimary,
                  ),
                ),
                const SizedBox(height: 4),
                Text(
                  widget.description,
                  style: TextStyle(
                    fontSize: 13,
                    color: context.textSecondary,
                    height: 1.4,
                  ),
                  maxLines: 2,
                  overflow: TextOverflow.ellipsis,
                ),
                const SizedBox(height: 16),
                Row(
                  children: [
                    Text(
                      'Open',
                      style: TextStyle(
                        fontSize: 13,
                        fontWeight: FontWeight.w600,
                        color: f.start,
                      ),
                    ),
                    const SizedBox(width: 4),
                    AnimatedSlide(
                      offset: _hover ? const Offset(0.15, 0) : Offset.zero,
                      duration: const Duration(milliseconds: 280),
                      curve: Curves.easeOut,
                      child: Icon(
                        Icons.arrow_forward_rounded,
                        size: 16,
                        color: f.start,
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
