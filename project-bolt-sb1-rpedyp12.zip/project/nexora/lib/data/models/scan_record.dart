/// Type of scan a user ran. Maps to the `scan_type` column in Supabase.
enum ScanType {
  link,
  news,
  image,
  qr,
  email,
  video,
  password;

  String get label => switch (this) {
        ScanType.link => 'Link Checker',
        ScanType.news => 'Fake News',
        ScanType.image => 'Image Scanner',
        ScanType.qr => 'QR Scanner',
        ScanType.email => 'Email Scanner',
        ScanType.video => 'Video Scanner',
        ScanType.password => 'Password Check',
      };

  static ScanType fromString(String? value) => switch (value) {
        'news' => ScanType.news,
        'image' => ScanType.image,
        'qr' => ScanType.qr,
        'email' => ScanType.email,
        'video' => ScanType.video,
        'password' => ScanType.password,
        _ => ScanType.link,
      };
}

/// Final verdict for any scan.
enum ScanVerdict {
  safe,
  suspicious,
  dangerous;

  String get label => switch (this) {
        ScanVerdict.safe => 'Safe',
        ScanVerdict.suspicious => 'Suspicious',
        ScanVerdict.dangerous => 'Dangerous',
      };

  static ScanVerdict fromString(String? value) => switch (value) {
        'suspicious' => ScanVerdict.suspicious,
        'dangerous' => ScanVerdict.dangerous,
        _ => ScanVerdict.safe,
      };
}

/// A single signal/finding inside a scan result.
class ScanSignal {
  final String label;
  final bool passed;
  final String detail;

  const ScanSignal({
    required this.label,
    required this.passed,
    required this.detail,
  });

  factory ScanSignal.fromJson(Map<String, dynamic> json) => ScanSignal(
        label: json['label'] as String? ?? '',
        passed: json['passed'] as bool? ?? false,
        detail: json['detail'] as String? ?? '',
      );

  Map<String, dynamic> toJson() => {
        'label': label,
        'passed': passed,
        'detail': detail,
      };
}

/// The full result of one scan, persisted to Supabase and shown in History.
class ScanRecord {
  final String? id;
  final ScanType type;
  final String input;
  final ScanVerdict verdict;
  final int confidence;
  final String? summary;
  final List<ScanSignal> signals;
  final DateTime? createdAt;

  const ScanRecord({
    this.id,
    required this.type,
    required this.input,
    required this.verdict,
    required this.confidence,
    this.summary,
    this.signals = const [],
    this.createdAt,
  });

  factory ScanRecord.fromJson(Map<String, dynamic> json) {
    final details = json['details'] as Map<String, dynamic>?;
    final signalsJson = details?['signals'] as List<dynamic>? ?? [];
    return ScanRecord(
      id: json['id'] as String?,
      type: ScanType.fromString(json['scan_type'] as String?),
      input: json['input'] as String? ?? '',
      verdict: ScanVerdict.fromString(json['verdict'] as String?),
      confidence: (json['confidence'] as num?)?.toInt() ?? 0,
      summary: json['summary'] as String?,
      signals: signalsJson
          .map((s) => ScanSignal.fromJson(s as Map<String, dynamic>))
          .toList(),
      createdAt: json['created_at'] != null
          ? DateTime.parse(json['created_at'] as String)
          : null,
    );
  }

  Map<String, dynamic> toInsertJson() => {
        'scan_type': type.name,
        'input': input,
        'verdict': verdict.name,
        'confidence': confidence,
        'summary': summary,
        'details': {
          'signals': signals.map((s) => s.toJson()).toList(),
        },
      };
}
