import 'package:supabase_flutter/supabase_flutter.dart';

import '../models/scan_record.dart';

/// Persists and retrieves [ScanRecord]s from the Supabase `scans` table.
class ScanRepository {
  final SupabaseClient _client;

  ScanRepository(this._client);

  /// Saves a scan to the database. The `user_id` column defaults to
  /// `auth.uid()` server-side, so the caller does not need to pass it.
  Future<ScanRecord> save(ScanRecord record) async {
    final json = record.toInsertJson();
    final response =
        await _client.from('scans').insert(json).select().single();
    return ScanRecord.fromJson(response);
  }

  /// Loads the most recent scans for the signed-in user.
  Future<List<ScanRecord>> recent({int limit = 50}) async {
    final response = await _client
        .from('scans')
        .select()
        .order('created_at', ascending: false)
        .limit(limit);

    return (response as List<dynamic>)
        .map((row) => ScanRecord.fromJson(row as Map<String, dynamic>))
        .toList();
  }

  /// Deletes a scan by id.
  Future<void> delete(String id) async {
    await _client.from('scans').delete().eq('id', id);
  }
}
