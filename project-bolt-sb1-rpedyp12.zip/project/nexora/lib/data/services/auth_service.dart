import 'package:supabase_flutter/supabase_flutter.dart';

/// Abstract authentication contract.
///
/// The UI and providers depend on this interface, not on any specific
/// backend. To migrate to Firebase, implement [FirebaseAuthService] and
/// swap the provider — no UI or repository changes needed.
abstract class AuthService {
  Future<AuthUser> signIn(String email, String password);
  Future<AuthUser> signUp(String email, String password, String name);
  Future<void> signOut();
  AuthUser? get currentUser;
  Stream<AuthUser?> get authStateChanges;
}

/// Backend-agnostic user representation.
class AuthUser {
  final String id;
  final String email;
  final String? name;

  const AuthUser({required this.id, required this.email, this.name});
}

/// Supabase implementation of [AuthService].
class SupabaseAuthService implements AuthService {
  final SupabaseClient _client;

  SupabaseAuthService(this._client);

  @override
  Future<AuthUser> signIn(String email, String password) async {
    final res = await _client.auth
        .signInWithPassword(email: email, password: password);
    return _fromUser(res.user);
  }

  @override
  Future<AuthUser> signUp(String email, String password, String name) async {
    final res = await _client.auth.signUp(
      email: email,
      password: password,
      data: {'full_name': name},
    );
    return _fromUser(res.user);
  }

  @override
  Future<void> signOut() => _client.auth.signOut();

  @override
  AuthUser? get currentUser => _fromUser(_client.auth.currentUser);

  @override
  Stream<AuthUser?> get authStateChanges =>
      _client.auth.onAuthStateChange.map((e) => _fromUser(e.session?.user));

  AuthUser _fromUser(User? user) {
    if (user == null) {
      throw AuthException('No authenticated user');
    }
    return AuthUser(
      id: user.id,
      email: user.email ?? '',
      name: user.userMetadata?['full_name'] as String?,
    );
  }
}
