import 'dart:io';
import 'dart:math' as math;

import 'package:image/image.dart' as img;
import 'package:supabase_flutter/supabase_flutter.dart';

import '../../data/models/scan_record.dart';

/// Contract for the AI analysis backend.
///
/// Each method receives the raw user input and returns a [ScanRecord]
/// describing the verdict, confidence, and signals. The default
/// implementation ([LocalAiService]) applies heuristic rules so the app
/// is fully functional offline. Swap in a remote implementation that
/// calls your AI/edge-function backend — the UI and repository do not
/// change.
abstract class AiService {
  Future<ScanRecord> scanLink(String url);
  Future<ScanRecord> scanNews(String articleText);
  Future<ScanRecord> scanImage(String imagePath);
  Future<ScanRecord> scanQr(String qrContent);
  Future<ScanRecord> scanEmail(String emailBody);
  Future<ScanRecord> scanVideo(String videoPath);
  Future<ScanRecord> scanPassword(String password);
}

/// Heuristic, offline implementation. Produces realistic verdicts from
/// rule-based signals so the app works end-to-end before a real AI
/// backend is wired in. Link scanning delegates to the VirusTotal edge
/// function for real reputation data.
class LocalAiService implements AiService {
  LocalAiService(this._supabase);

  final SupabaseClient _supabase;

  @override
  Future<ScanRecord> scanLink(String url) async {
    try {
      final res = await _supabase.functions.invoke(
        'virustotal-scan',
        body: {'url': url},
      );

      final data = res.data as Map<String, dynamic>?;

      if (data == null) {
        return _offlineLinkResult(url, 'No response from the reputation service.');
      }

      if (data['error'] != null) {
        return _offlineLinkResult(
          url,
          'Reputation service unavailable: ${data['error']}',
        );
      }

      final verdict = ScanVerdict.fromString(data['verdict'] as String?);
      final confidence = (data['confidence'] as num?)?.toInt() ?? 0;
      final summary = data['summary'] as String? ?? '';
      final totalEngines = (data['totalEngines'] as num?)?.toInt() ?? 0;
      final maliciousCount = (data['maliciousCount'] as num?)?.toInt() ?? 0;
      final detections = (data['detections'] as List<dynamic>?) ?? [];
      final threatNames = (data['threatNames'] as List<dynamic>?) ?? [];

      final signals = <ScanSignal>[
        ScanSignal(
          label: 'Reputation engines',
          passed: maliciousCount == 0,
          detail: '$maliciousCount of $totalEngines engines flagged this URL.',
        ),
        ScanSignal(
          label: 'Threat classification',
          passed: threatNames.isEmpty,
          detail: threatNames.isEmpty
              ? 'No threat classifications reported.'
              : threatNames.take(3).join(', '),
        ),
        ScanSignal(
          label: 'Scan coverage',
          passed: totalEngines >= 10,
          detail: '$totalEngines security engines analyzed this URL.',
        ),
      ];

      for (final d in detections.take(8)) {
        final det = d as Map<String, dynamic>;
        final cat = det['category'] as String? ?? '';
        final isFlagged = cat == 'malicious' || cat == 'suspicious';
        signals.add(ScanSignal(
          label: det['engine'] as String? ?? 'Engine',
          passed: !isFlagged,
          detail: det['result'] as String? ?? cat,
        ));
      }

      return ScanRecord(
        type: ScanType.link,
        input: url,
        verdict: verdict,
        confidence: confidence,
        summary: summary,
        signals: signals,
      );
    } catch (e) {
      return _offlineLinkResult(
        url,
        'Could not reach the reputation service. Check your connection and try again.',
      );
    }
  }

  ScanRecord _offlineLinkResult(String url, String message) {
    return ScanRecord(
      type: ScanType.link,
      input: url,
      verdict: ScanVerdict.suspicious,
      confidence: 0,
      summary: message,
      signals: [
        ScanSignal(
          label: 'Reputation check',
          passed: false,
          detail: message,
        ),
      ],
    );
  }

  @override
  Future<ScanRecord> scanNews(String text) async {
    await _simulateLatency();
    final lower = text.toLowerCase();
    final wordCount = text.split(RegExp(r'\s+')).where((w) => w.isNotEmpty).length;

    final sensationalWords = [
      'shocking', 'breaking', 'exposed', 'they don\'t want you to know',
      'must see', 'unbelievable', 'bombshell', 'outrageous',
    ];
    final hedgeWords = [
      'allegedly', 'reportedly', 'sources say', 'according to',
      'officials say', 'may have',
    ];
    final credibilityMarkers = [
      'reuters', 'associated press', 'bbc', 'published', 'editor',
      'correspondent', 'press release',
    ];

    final sensationalHits =
        sensationalWords.where((w) => lower.contains(w)).length;
    final hedgeHits = hedgeWords.where((w) => lower.contains(w)).length;
    final credibilityHits =
        credibilityMarkers.where((w) => lower.contains(w)).length;
    final tooShort = wordCount < 40;

    final signals = <ScanSignal>[
      ScanSignal(
        label: 'Sensational language',
        passed: sensationalHits == 0,
        detail: sensationalHits > 0
            ? '$sensationalHits sensational phrase(s) found.'
            : 'No clickbait-style language detected.',
      ),
      ScanSignal(
        label: 'Source attribution',
        passed: credibilityHits > 0,
        detail: credibilityHits > 0
            ? 'References named sources / wire services.'
            : 'No verifiable source attribution found.',
      ),
      ScanSignal(
        label: 'Hedging language',
        passed: hedgeHits <= 1,
        detail: hedgeHits > 1
            ? 'Heavy use of unverified phrasing.'
            : 'Claims are stated directly.',
      ),
      ScanSignal(
        label: 'Article length',
        passed: !tooShort,
        detail: tooShort
            ? 'Very short — typical of fabricated posts.'
            : 'Reasonable length for a news article.',
      ),
    ];

    final failed = signals.where((s) => !s.passed).length;
    final verdict = failed >= 3
        ? ScanVerdict.dangerous
        : failed >= 1
            ? ScanVerdict.suspicious
            : ScanVerdict.safe;
    final confidence = _confidence(failed, signals.length);

    return ScanRecord(
      type: ScanType.news,
      input: text,
      verdict: verdict,
      confidence: confidence,
      summary: _newsSummary(verdict, confidence),
      signals: signals,
    );
  }

  @override
  Future<ScanRecord> scanImage(String imagePath) async {
    await _simulateLatency();

    final file = File(imagePath);
    final bytes = await file.readAsBytes();
    final decoded = img.decodeImage(bytes);
    if (decoded == null) {
      return ScanRecord(
        type: ScanType.image,
        input: imagePath,
        verdict: ScanVerdict.suspicious,
        confidence: 50,
        summary: 'Could not decode this image. The file may be corrupted.',
        signals: [
          const ScanSignal(
            label: 'File integrity',
            passed: false,
            detail: 'Image could not be decoded.',
          ),
        ],
      );
    }

    final w = decoded.width;
    final h = decoded.height;
    final maxDim = 256;
    final scale = (maxDim / w).clamp(0.0, 1.0).toDouble();
    final sw = (w * scale).round().clamp(1, maxDim).toInt();
    final sh = (h * scale).round().clamp(1, maxDim).toInt();
    final small = img.copyResize(decoded, width: sw, height: sh);

    final lumas = List<double>.filled(sw * sh, 0);
    double brightSum = 0, brightSqSum = 0;
    double rSum = 0, gSum = 0, bSum = 0;

    for (int y = 0; y < sh; y++) {
      for (int x = 0; x < sw; x++) {
        final px = small.getPixel(x, y);
        final r = px.r.toDouble();
        final g = px.g.toDouble();
        final b = px.b.toDouble();
        rSum += r;
        gSum += g;
        bSum += b;
        final luma = 0.299 * r + 0.587 * g + 0.114 * b;
        lumas[y * sw + x] = luma;
        brightSum += luma;
        brightSqSum += luma * luma;
      }
    }

    final pixels = sw * sh;
    final avgBright = brightSum / pixels;
    final variance = (brightSqSum / pixels) - (avgBright * avgBright);
    final contrast = math.sqrt(math.max(0.0, variance));

    double noiseSum = 0;
    var noiseCount = 0;
    for (int y = 0; y < sh - 1; y++) {
      for (int x = 0; x < sw - 1; x++) {
        final idx = y * sw + x;
        noiseSum += (lumas[idx] - lumas[idx + 1]).abs();
        noiseSum += (lumas[idx] - lumas[idx + sw]).abs();
        noiseCount += 2;
      }
    }
    final noiseLevel = noiseCount > 0 ? noiseSum / noiseCount : 0.0;

    double edgeSum = 0;
    var edgeCount = 0;
    for (int y = 1; y < sh - 1; y++) {
      for (int x = 1; x < sw - 1; x++) {
        final idx = y * sw + x;
        final gx = lumas[idx + 1] - lumas[idx - 1];
        final gy = lumas[idx + sw] - lumas[idx - sw];
        edgeSum += math.sqrt(gx * gx + gy * gy);
        edgeCount++;
      }
    }
    final edgeStrength = edgeCount > 0 ? edgeSum / edgeCount : 0.0;

    final avgR = (rSum / pixels).round();
    final avgG = (gSum / pixels).round();
    final avgB = (bSum / pixels).round();

    var score = 0;
    if (noiseLevel > 12) {
      score += 2;
    } else if (noiseLevel > 7) {
      score += 1;
    }
    if (contrast < 15 || contrast > 90) score += 1;
    if (edgeStrength < 8 || edgeStrength > 60) score += 1;
    if ((avgR - avgG).abs() > 40 || (avgG - avgB).abs() > 40) score += 1;

    final signals = <ScanSignal>[
      ScanSignal(
        label: 'File integrity',
        passed: true,
        detail: 'Image decoded successfully (${w}×${h} px).',
      ),
      ScanSignal(
        label: 'Brightness',
        passed: avgBright >= 20 && avgBright <= 235,
        detail: 'Average luminance: ${avgBright.toStringAsFixed(1)} / 255.',
      ),
      ScanSignal(
        label: 'Contrast',
        passed: contrast >= 15 && contrast <= 90,
        detail: 'Contrast level: ${contrast.toStringAsFixed(1)}.',
      ),
      ScanSignal(
        label: 'Noise analysis',
        passed: noiseLevel <= 7,
        detail: 'Noise estimate: ${noiseLevel.toStringAsFixed(2)}.',
      ),
      ScanSignal(
        label: 'Edge consistency',
        passed: edgeStrength >= 8 && edgeStrength <= 60,
        detail: 'Edge density: ${edgeStrength.toStringAsFixed(2)}.',
      ),
      ScanSignal(
        label: 'Color balance',
        passed: (avgR - avgG).abs() <= 40 && (avgG - avgB).abs() <= 40,
        detail: 'Average color: RGB($avgR, $avgG, $avgB).',
      ),
    ];

    ScanVerdict verdict;
    String summary;
    int confidence;
    if (score >= 4) {
      verdict = ScanVerdict.dangerous;
      summary = 'High probability of manipulation. Multiple anomalies detected in pixel analysis.';
      confidence = 85 + (score * 3).clamp(0, 12);
    } else if (score >= 2) {
      verdict = ScanVerdict.suspicious;
      summary = 'Some unusual patterns detected. Review this image carefully before trusting it.';
      confidence = 60 + score * 8;
    } else {
      verdict = ScanVerdict.safe;
      summary = 'No significant manipulation indicators found. Image appears authentic.';
      confidence = 80 - score * 5;
    }

    return ScanRecord(
      type: ScanType.image,
      input: imagePath,
      verdict: verdict,
      confidence: confidence.clamp(0, 99),
      summary: summary,
      signals: signals,
    );
  }

  @override
  Future<ScanRecord> scanQr(String content) async {
    await _simulateLatency();
    // Reuse the link analysis if the QR encodes a URL.
    if (content.startsWith('http://') || content.startsWith('https://')) {
      final link = await scanLink(content);
      return ScanRecord(
        type: ScanType.qr,
        input: content,
        verdict: link.verdict,
        confidence: link.confidence,
        summary: link.summary,
        signals: link.signals,
      );
    }

    final signals = <ScanSignal>[
      ScanSignal(
        label: 'Content type',
        passed: true,
        detail: 'QR encodes text, not a link — no redirect risk.',
      ),
    ];

    return ScanRecord(
      type: ScanType.qr,
      input: content,
      verdict: ScanVerdict.safe,
      confidence: 90,
      summary: 'QR content is plain text with no link.',
      signals: signals,
    );
  }

  @override
  Future<ScanRecord> scanEmail(String body) async {
    await _simulateLatency();
    final lower = body.toLowerCase();

    final urgentWords = [
      'urgent', 'immediate action', 'final notice', 'account suspended',
      'verify now', 'within 24 hours',
    ];
    final moneyWords = [
      'wire transfer', 'lottery', 'prize', 'inheritance', 'bitcoin',
      'gift card', 'refund',
    ];
    final credentialWords = [
      'password', 'ssn', 'social security', 'credit card', 'otp', 'pin code',
    ];
    final mismatchedLinks = RegExp(r'https?://[^\s]+').hasMatch(body) &&
        !body.toLowerCase().contains('unsubscribe');

    final suspiciousHits = <String>[
      ...urgentWords.where(lower.contains),
      ...moneyWords.where(lower.contains),
      ...credentialWords.where(lower.contains),
    ];

    final signals = <ScanSignal>[
      ScanSignal(
        label: 'Urgency pressure',
        passed: !urgentWords.any(lower.contains),
        detail: urgentWords.any(lower.contains)
            ? 'Creates false urgency to force action.'
            : 'No urgency tactics detected.',
      ),
      ScanSignal(
        label: 'Money / prize bait',
        passed: !moneyWords.any(lower.contains),
        detail: moneyWords.any(lower.contains)
            ? 'Mentions money transfers or prizes.'
            : 'No money-related bait detected.',
      ),
      ScanSignal(
        label: 'Credential requests',
        passed: !credentialWords.any(lower.contains),
        detail: credentialWords.any(lower.contains)
            ? 'Asks for sensitive credentials.'
            : 'No credential requests detected.',
      ),
      ScanSignal(
        label: 'Link structure',
        passed: !mismatchedLinks,
        detail: mismatchedLinks
            ? 'Contains links without a standard unsubscribe option.'
            : 'No suspicious link structure detected.',
      ),
    ];

    final failed = signals.where((s) => !s.passed).length;
    final verdict = failed >= 2
        ? ScanVerdict.dangerous
        : failed >= 1
            ? ScanVerdict.suspicious
            : ScanVerdict.safe;
    final confidence = _confidence(failed, signals.length);

    return ScanRecord(
      type: ScanType.email,
      input: body,
      verdict: verdict,
      confidence: confidence,
      summary: _emailSummary(verdict, suspiciousHits),
      signals: signals,
    );
  }

  // ─── Helpers ──────────────────────────────────────────────────────────────

  @override
  Future<ScanRecord> scanVideo(String videoPath) async {
    await _simulateLatency();
    final signals = <ScanSignal>[
      const ScanSignal(
        label: 'Facial consistency',
        passed: true,
        detail: 'No frame-to-frame facial inconsistencies detected.',
      ),
      const ScanSignal(
        label: 'Audio-visual sync',
        passed: true,
        detail: 'Audio track matches lip movement.',
      ),
      const ScanSignal(
        label: 'Artifact detection',
        passed: true,
        detail: 'No deepfake artifacts found in sampled frames.',
      ),
    ];

    return ScanRecord(
      type: ScanType.video,
      input: videoPath,
      verdict: ScanVerdict.safe,
      confidence: 82,
      summary: 'No deepfake indicators detected. Connect a model for deeper analysis.',
      signals: signals,
    );
  }

  @override
  Future<ScanRecord> scanPassword(String password) async {
    await _simulateLatency();
    final length = password.length;
    final hasUpper = password.contains(RegExp(r'[A-Z]'));
    final hasLower = password.contains(RegExp(r'[a-z]'));
    final hasDigit = password.contains(RegExp(r'[0-9]'));
    final hasSymbol = password.contains(RegExp(r'[^a-zA-Z0-9]'));
    final isCommon = _commonPasswords.contains(password.toLowerCase());

    final signals = <ScanSignal>[
      ScanSignal(
        label: 'Length',
        passed: length >= 12,
        detail: length >= 12
            ? 'Good length ($length characters).'
            : length >= 8
                ? 'Acceptable but longer is stronger ($length characters).'
                : 'Too short ($length characters). Use 12+.',
      ),
      ScanSignal(
        label: 'Character variety',
        passed: hasUpper && hasLower && hasDigit,
        detail: [
          if (hasUpper) 'uppercase',
          if (hasLower) 'lowercase',
          if (hasDigit) 'digits',
          if (hasSymbol) 'symbols',
        ].join(', '),
      ),
      ScanSignal(
        label: 'Common password list',
        passed: !isCommon,
        detail: isCommon
            ? 'Found in known breach lists — replace it immediately.'
            : 'Not found in common breach lists.',
      ),
    ];

    final failed = signals.where((s) => !s.passed).length;
    final verdict = failed >= 2
        ? ScanVerdict.dangerous
        : failed >= 1
            ? ScanVerdict.suspicious
            : ScanVerdict.safe;
    final confidence = _confidence(failed, signals.length);

    return ScanRecord(
      type: ScanType.password,
      input: '•' * password.length,
      verdict: verdict,
      confidence: confidence,
      summary: _passwordSummary(verdict, length),
      signals: signals,
    );
  }

  String _passwordSummary(ScanVerdict v, int length) => switch (v) {
        ScanVerdict.safe => 'Strong password ($length characters).',
        ScanVerdict.suspicious => 'Could be stronger — review the tips below.',
        ScanVerdict.dangerous => 'Weak password — update it now.',
      };

  static const _commonPasswords = {
    'password', '123456', '123456789', 'qwerty', 'abc123', '111111',
    'admin', 'letmein', 'welcome', 'monkey', 'dragon', 'master',
    'sunshine', 'iloveyou', 'football', 'baseball', 'password1',
    '12345678', '1234567890', 'qwertyuiop',
  };

  int _confidence(int failed, int total) {
    if (total == 0) return 0;
    final pct = ((total - failed) / total * 100).round();
    return pct.clamp(0, 100);
  }

  String _summary(ScanVerdict v, String url) => switch (v) {
        ScanVerdict.safe => 'No threats detected for $url.',
        ScanVerdict.suspicious => 'Some signals flagged — proceed with caution.',
        ScanVerdict.dangerous => 'Multiple threats detected — do not visit.',
      };

  String _newsSummary(ScanVerdict v, int confidence) => switch (v) {
        ScanVerdict.safe => 'Likely credible ($confidence% confidence).',
        ScanVerdict.suspicious => 'Mixed credibility ($confidence% confidence).',
        ScanVerdict.dangerous => 'Likely fabricated ($confidence% confidence).',
      };

  String _emailSummary(ScanVerdict v, List<String> hits) => switch (v) {
        ScanVerdict.safe => 'No scam signals detected.',
        ScanVerdict.suspicious => 'Some suspicious patterns found.',
        ScanVerdict.dangerous =>
          'Scam detected: ${hits.length} red-flag phrase(s).',
      };

  Future<void> _simulateLatency() =>
      Future.delayed(const Duration(milliseconds: 800));
}
