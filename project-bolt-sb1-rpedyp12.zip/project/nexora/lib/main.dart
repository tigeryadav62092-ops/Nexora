import 'package:flutter/material.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import 'core/navigation/app_router.dart';
import 'core/providers/providers.dart';
import 'core/theme/app_theme.dart';
import 'features/splash/presentation/splash_page.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const ProviderScope(child: NexoraApp()));
}

class NexoraApp extends ConsumerStatefulWidget {
  const NexoraApp({super.key});

  @override
  ConsumerState<NexoraApp> createState() => _NexoraAppState();
}

class _NexoraAppState extends ConsumerState<NexoraApp> {
  bool _showSplash = true;

  @override
  void initState() {
    super.initState();
    ref.read(supabaseInitProvider);
  }

  void _onSplashDone() => setState(() => _showSplash = false);

  @override
  Widget build(BuildContext context) {
    final settings = ref.watch(settingsProvider);
    final router = ref.watch(routerProvider);

    final supportedLocales = const [
      Locale('en'),
      Locale('hi'),
      Locale('ar'),
      Locale('es'),
      Locale('fr'),
    ];
    const localizationDelegates = [
      GlobalMaterialLocalizations.delegate,
      GlobalWidgetsLocalizations.delegate,
      GlobalCupertinoLocalizations.delegate,
    ];

    if (_showSplash) {
      return MaterialApp(
        title: 'Nexora',
        debugShowCheckedModeBanner: false,
        theme: AppTheme.light,
        darkTheme: AppTheme.dark,
        themeMode: settings.themeMode.toMaterial(),
        locale: settings.locale,
        supportedLocales: supportedLocales,
        localizationsDelegates: localizationDelegates,
        home: SplashPage(onComplete: _onSplashDone),
      );
    }

    return MaterialApp.router(
      title: 'Nexora',
      debugShowCheckedModeBanner: false,
      theme: AppTheme.light,
      darkTheme: AppTheme.dark,
      themeMode: settings.themeMode.toMaterial(),
      locale: settings.locale,
      supportedLocales: supportedLocales,
      localizationsDelegates: localizationDelegates,
      routerConfig: router,
    );
  }
}
