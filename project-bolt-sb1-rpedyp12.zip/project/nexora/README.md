# Nexora

**Think Smart. Stay Safe.** — A premium, AI-powered cyber security companion built with Flutter and Material Design 3.

## Features

- Splash screen with animated glow
- Email/password + Google sign-in (Supabase Auth)
- Home dashboard with six AI security tools
- Bottom navigation: Home, History, Scanner, Profile, Settings
- Dark theme with blue + purple gradient system

## Getting started

```bash
flutter pub get
flutter run
```

## Configuration

Supabase credentials are injected at build time via `--dart-define`:

```bash
flutter run \
  --dart-define=SUPABASE_URL=YOUR_URL \
  --dart-define=SUPABASE_ANON_KEY=YOUR_KEY
```

## Structure

```
lib/
  core/        # theme, routes, constants, utils
  data/        # models, repositories
  features/    # feature-first screens (auth, home, scanner, ...)
  shared/      # reusable widgets
```
