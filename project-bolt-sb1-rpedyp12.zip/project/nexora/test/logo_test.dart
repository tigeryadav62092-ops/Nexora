import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';

import 'package:nexora/core/constants/app_constants.dart';
import 'package:nexora/shared/widgets/nexora_logo.dart';

void main() {
  testWidgets('NexoraLogo renders glyph and wordmark', (tester) async {
    await tester.pumpWidget(
      const MaterialApp(home: Scaffold(body: NexoraLogo(size: 40))),
    );
    expect(find.text('Nexora'), findsOneWidget);
    expect(find.byIcon(Icons.shield_rounded), findsOneWidget);
  });

  test('AppConstants hold expected values', () {
    expect(AppConstants.appName, 'Nexora');
    expect(AppConstants.tagline, 'Think Smart. Stay Safe.');
  });
}
