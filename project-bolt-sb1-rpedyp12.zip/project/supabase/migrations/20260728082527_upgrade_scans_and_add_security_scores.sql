/*
# Upgrade scans table and add security_scores table

## Purpose
Extends the existing `scans` table to support new scan types (pdf, apk, sms,
darkweb, camera) and adds a new `security_scores` table for the Security Score
Dashboard feature.

## Changes to `scans` table
- Added `confidence` column already exists (int 0-100).
- The `scan_type` column is text and already supports any value, so new types
  (pdf, apk, sms, darkweb, camera) work without schema changes.
- Added `title` column (text) for a short display label per scan.
- Added `severity` column (int 0-100) for threat severity score.

## New Tables
- `security_scores`
  - `id` (uuid, primary key)
  - `user_id` (uuid, not null, defaults to authenticated user)
  - `overall_score` (int, 0-100) — overall security score
  - `password_score` (int, 0-100)
  - `email_score` (int, 0-100)
  - `browsing_score` (int, 0-100)
  - `identity_score` (int, 0-100)
  - `device_score` (int, 0-100)
  - `threats_blocked` (int, default 0) — total threats blocked
  - `scans_run` (int, default 0) — total scans run
  - `updated_at` (timestamptz, defaults to now())

## Security
- RLS enabled on `security_scores`.
- Owner-scoped CRUD: each authenticated user can only access their own score.
- Existing `scans` table RLS policies remain unchanged.

## Notes
1. Both tables are multi-user (the app has login), so policies are scoped
   `TO authenticated` with `auth.uid()` ownership checks.
2. `security_scores` has one row per user (enforced by unique user_id).
3. The `scans` table additions use `IF NOT EXISTS` checks to be safe on re-run.
*/

-- Add new columns to scans table if they don't exist
DO $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns
    WHERE table_name = 'scans' AND column_name = 'title') THEN
    ALTER TABLE scans ADD COLUMN title text;
  END IF;
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns
    WHERE table_name = 'scans' AND column_name = 'severity') THEN
    ALTER TABLE scans ADD COLUMN severity int DEFAULT 0 CHECK (severity >= 0 AND severity <= 100);
  END IF;
END $$;

-- Create security_scores table
CREATE TABLE IF NOT EXISTS security_scores (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL DEFAULT auth.uid() REFERENCES auth.users(id) ON DELETE CASCADE,
  overall_score int NOT NULL DEFAULT 0 CHECK (overall_score >= 0 AND overall_score <= 100),
  password_score int NOT NULL DEFAULT 50 CHECK (password_score >= 0 AND password_score <= 100),
  email_score int NOT NULL DEFAULT 50 CHECK (email_score >= 0 AND email_score <= 100),
  browsing_score int NOT NULL DEFAULT 50 CHECK (browsing_score >= 0 AND browsing_score <= 100),
  identity_score int NOT NULL DEFAULT 50 CHECK (identity_score >= 0 AND identity_score <= 100),
  device_score int NOT NULL DEFAULT 50 CHECK (device_score >= 0 AND device_score <= 100),
  threats_blocked int NOT NULL DEFAULT 0,
  scans_run int NOT NULL DEFAULT 0,
  updated_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE(user_id)
);

ALTER TABLE security_scores ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "select_own_security_scores" ON security_scores;
CREATE POLICY "select_own_security_scores" ON security_scores FOR SELECT
  TO authenticated USING (auth.uid() = user_id);

DROP POLICY IF EXISTS "insert_own_security_scores" ON security_scores;
CREATE POLICY "insert_own_security_scores" ON security_scores FOR INSERT
  TO authenticated WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "update_own_security_scores" ON security_scores;
CREATE POLICY "update_own_security_scores" ON security_scores FOR UPDATE
  TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "delete_own_security_scores" ON security_scores;
CREATE POLICY "delete_own_security_scores" ON security_scores FOR DELETE
  TO authenticated USING (auth.uid() = user_id);
