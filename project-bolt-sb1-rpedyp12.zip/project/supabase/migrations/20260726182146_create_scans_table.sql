/*
# Create scans table for Nexora scan history

## Purpose
Stores every AI scan a user runs (link risk, fake news, image, QR, email)
so the History page can show past results across devices and sessions.

## New Tables
- `scans`
  - `id` (uuid, primary key)
  - `user_id` (uuid, not null, defaults to authenticated user — owner scope)
  - `scan_type` (text, not null) — one of: link, news, image, qr, email
  - `input` (text, not null) — the URL / article text / image ref / email body the user submitted
  - `verdict` (text, not null) — safe | suspicious | dangerous
  - `confidence` (int, 0–100) — AI confidence score
  - `summary` (text) — short human-readable result summary
  - `details` (jsonb) — structured signal breakdown for the detail view
  - `created_at` (timestptz, defaults to now())

## Security
- RLS enabled on `scans`.
- Owner-scoped CRUD: each authenticated user can only read/insert/update/delete
  their own scans. `user_id` defaults to `auth.uid()` so inserts that omit it
  still satisfy the WITH CHECK policy.

## Notes
1. This is a multi-user table (the app has login), so policies are scoped
   `TO authenticated` with `auth.uid()` ownership checks.
2. `details` is jsonb so each scan type can store its own signal structure
   without schema churn.
3. Index on `(user_id, created_at desc)` powers the History list query.
*/

CREATE TABLE IF NOT EXISTS scans (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL DEFAULT auth.uid() REFERENCES auth.users(id) ON DELETE CASCADE,
  scan_type text NOT NULL,
  input text NOT NULL,
  verdict text NOT NULL,
  confidence int NOT NULL DEFAULT 0 CHECK (confidence >= 0 AND confidence <= 100),
  summary text,
  details jsonb,
  created_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE scans ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "select_own_scans" ON scans;
CREATE POLICY "select_own_scans" ON scans FOR SELECT
  TO authenticated USING (auth.uid() = user_id);

DROP POLICY IF EXISTS "insert_own_scans" ON scans;
CREATE POLICY "insert_own_scans" ON scans FOR INSERT
  TO authenticated WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "update_own_scans" ON scans;
CREATE POLICY "update_own_scans" ON scans FOR UPDATE
  TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "delete_own_scans" ON scans;
CREATE POLICY "delete_own_scans" ON scans FOR DELETE
  TO authenticated USING (auth.uid() = user_id);

CREATE INDEX IF NOT EXISTS idx_scans_user_created
  ON scans (user_id, created_at DESC);
