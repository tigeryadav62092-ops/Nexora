import "jsr:@supabase/functions-js/edge-runtime.d.ts";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET, POST, PUT, DELETE, OPTIONS",
  "Access-Control-Allow-Headers":
    "Content-Type, Authorization, X-Client-Info, Apikey",
};

const VT_BASE = "https://www.virustotal.com/api/v3";

Deno.serve(async (req: Request) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { status: 200, headers: corsHeaders });
  }

  try {
    const apiKey = Deno.env.get("VIRUSTOTAL_API_KEY");
    if (!apiKey) {
      return new Response(
        JSON.stringify({
          error:
            "VirusTotal API key not configured. Add VIRUSTOTAL_API_KEY as an edge function secret.",
        }),
        {
          status: 503,
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        },
      );
    }

    const body = await req.json();
    const url: string | undefined = body?.url;
    if (!url || typeof url !== "string") {
      return new Response(
        JSON.stringify({ error: "Missing 'url' in request body." }),
        {
          status: 400,
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        },
      );
    }

    const normalized = normalizeUrl(url);

    // Submit the URL for scanning (idempotent — VT returns existing scan if cached).
    const submitRes = await fetch(`${VT_BASE}/urls`, {
      method: "POST",
      headers: {
        "x-apikey": apiKey,
        "Content-Type": "application/x-www-form-urlencoded",
      },
      body: `url=${encodeURIComponent(normalized)}`,
    });

    if (!submitRes.ok) {
      const errText = await submitRes.text();
      return new Response(
        JSON.stringify({
          error: `VirusTotal submit failed (${submitRes.status}): ${errText}`,
        }),
        {
          status: 502,
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        },
      );
    }

    const submitData = await submitRes.json();
    const analysisId: string | undefined = submitData?.data?.id;

    // Retrieve the full URL report (contains all engine detections).
    const urlId = urlIdFor(normalized);
    const reportRes = await fetch(`${VT_BASE}/urls/${urlId}`, {
      headers: { "x-apikey": apiKey },
    });

    let report: Record<string, unknown> | null = null;
    if (reportRes.ok) {
      report = await reportRes.json();
    }

    // If the report isn't ready yet, poll the analysis endpoint.
    let analysis: Record<string, unknown> | null = null;
    if (analysisId) {
      const analysisRes = await fetch(`${VT_BASE}/analyses/${analysisId}`, {
        headers: { "x-apikey": apiKey },
      });
      if (analysisRes.ok) {
        analysis = await analysisRes.json();
      }
    }

    const parsed = parseResults(report, analysis, normalized);

    return new Response(JSON.stringify(parsed), {
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  } catch (err) {
    return new Response(
      JSON.stringify({ error: err instanceof Error ? err.message : "Unknown error" }),
      {
        status: 500,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      },
    );
  }
});

function normalizeUrl(input: string): string {
  let u = input.trim();
  if (!/^https?:\/\//i.test(u)) {
    u = "https://" + u;
  }
  return u;
}

function urlIdFor(url: string): string {
  const encoded = btoa(url);
  return encoded.replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/, "");
}

interface EngineDetection {
  engine: string;
  category: string;
  result: string | null;
}

interface ParsedResult {
  verdict: "safe" | "suspicious" | "dangerous";
  confidence: number;
  summary: string;
  url: string;
  totalEngines: number;
  maliciousCount: number;
  detections: EngineDetection[];
  threatNames: string[];
}

function parseResults(
  report: Record<string, unknown> | null,
  analysis: Record<string, unknown> | null,
  url: string,
): ParsedResult {
  const detections: EngineDetection[] = [];
  let totalEngines = 0;
  let maliciousCount = 0;
  const threatNames: string[] = [];

  // Extract from the URL report's last_analysis_results.
  const reportAttrs = (report?.data as Record<string, unknown>)?.attributes as
    | Record<string, unknown>
    | undefined;
  const lastAnalysisResults = reportAttrs?.last_analysis_results as
    | Record<string, unknown>
    | undefined;

  if (lastAnalysisResults && typeof lastAnalysisResults === "object") {
    for (const [engineName, data] of Object.entries(lastAnalysisResults)) {
      const d = data as Record<string, unknown>;
      totalEngines++;
      const category = (d.category as string) ?? "harmless";
      const result = (d.result as string) ?? null;

      detections.push({
        engine: engineName,
        category,
        result,
      });

      if (category === "malicious" || category === "suspicious") {
        maliciousCount++;
        if (result) threatNames.push(result);
      }
    }
  }

  // Fallback: extract from the analysis endpoint if report wasn't ready.
  if (totalEngines === 0 && analysis) {
    const analysisAttrs = (analysis.data as Record<string, unknown>)
      ?.attributes as Record<string, unknown> | undefined;
    const stats = analysisAttrs?.stats as Record<string, unknown> | undefined;
    if (stats) {
      totalEngines =
        ((stats.malicious as number) ?? 0) +
        ((stats.suspicious as number) ?? 0) +
        ((stats.undetected as number) ?? 0) +
        ((stats.harmless as number) ?? 0);
      maliciousCount =
        ((stats.malicious as number) ?? 0) + ((stats.suspicious as number) ?? 0);
    }
  }

  totalEngines = Math.max(totalEngines, 1);

  let verdict: "safe" | "suspicious" | "dangerous";
  let confidence: number;

  if (maliciousCount >= 3) {
    verdict = "dangerous";
    confidence = Math.min(95, 70 + maliciousCount * 5);
  } else if (maliciousCount >= 1) {
    verdict = "suspicious";
    confidence = Math.min(85, 55 + maliciousCount * 10);
  } else {
    verdict = "safe";
    confidence = Math.max(80, 95 - 1);
  }

  let summary: string;
  if (verdict === "dangerous") {
    summary = `${maliciousCount} of ${totalEngines} security engines flagged this URL as malicious.`;
  } else if (verdict === "suspicious") {
    summary = `${maliciousCount} of ${totalEngines} security engines flagged this URL. Exercise caution.`;
  } else {
    summary = `No threats detected. ${totalEngines} security engines scanned this URL and found no malicious activity.`;
  }

  return {
    verdict,
    confidence,
    summary,
    url,
    totalEngines,
    maliciousCount,
    detections: detections.slice(0, 15),
    threatNames: [...new Set(threatNames)],
  };
}
